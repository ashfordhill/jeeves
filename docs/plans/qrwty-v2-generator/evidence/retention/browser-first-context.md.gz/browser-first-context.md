# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: receipt-consumer.spec.ts >> RG18 edits the receipt delivery horizon by mouse and exports guarded consumer operations
- Location: jeeves/apps/web/e2e/receipt-consumer.spec.ts:10:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: apiRequestContext.delete: Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f2e2]:
  - banner [ref=f2e3]:
    - generic [ref=f2e4]: Jeeves
    - tablist "Views" [ref=f2e6]:
      - tab "Design" [selected] [ref=f2e7] [cursor=pointer]
      - tab "Settings" [ref=f2e8] [cursor=pointer]
    - generic [ref=f2e9]:
      - button "Export diagram" [ref=f2e11] [cursor=pointer]
      - generic [ref=f2e16]:
        - button "Undo" [ref=f2e17] [cursor=pointer]
        - button "Redo" [disabled] [ref=f2e21]
        - button "Open chat" [ref=f2e25] [cursor=pointer]
        - button "Collapse inspector" [pressed] [ref=f2e28] [cursor=pointer]
        - button "Generate project" [ref=f2e31] [cursor=pointer]
    - 'button "Project: E2E RG18 receipts" [ref=f2e33] [cursor=pointer]':
      - generic [ref=f2e34]: E2E RG18 receipts
  - main [ref=f2e37]:
    - tabpanel "Design" [ref=f2e38]:
      - generic [ref=f2e39]:
        - generic [ref=f2e40]:
          - generic [ref=f2e41]:
            - application [ref=f2e43]:
              - generic [ref=f2e45]:
                - generic:
                  - generic:
                    - img:
                      - group "Source to Events" [ref=f2e46] [cursor=pointer]
                    - img:
                      - group "Events to Event consumer (Counter)" [ref=f2e48] [cursor=pointer]
                    - img:
                      - group "User to Consume" [ref=f2e52] [cursor=pointer]
                    - img:
                      - group "Consume to Source" [ref=f2e54] [cursor=pointer]
                    - img:
                      - group "Data access (Counter) to Totals" [ref=f2e56] [cursor=pointer]
                    - img:
                      - group "Events to Event consumer (Projector)" [ref=f2e58] [cursor=pointer]
                    - img:
                      - group "Event consumer (Projector) to Items" [ref=f2e62] [cursor=pointer]
                  - generic:
                    - group "User" [ref=f2e64]
                    - group "Consume" [ref=f2e74]
                    - group "Source" [ref=f2e83]:
                      - generic [ref=f2e86]:
                        - generic [ref=f2e96]:
                          - generic [ref=f2e97]: Source
                          - generic [ref=f2e98]: Service
                        - list "Modules"
                        - button "Add module" [ref=f2e99]
                    - group "Events" [ref=f2e101]:
                      - generic [ref=f2e104]:
                        - generic [ref=f2e113]: Events
                        - generic [ref=f2e114]: Topic
                    - group "Counter" [ref=f2e115]:
                      - generic [ref=f2e118]:
                        - generic [ref=f2e127]:
                          - generic [ref=f2e128]: Counter
                          - generic [ref=f2e129]: Worker
                        - list "Modules":
                          - listitem "Event consumer" [ref=f2e130]:
                            - button "Open Event consumer in Counter" [ref=f2e131]:
                              - generic [ref=f2e139]: Event consumer
                          - listitem "Event counter" [ref=f2e141]:
                            - button "Open Event counter in Counter" [ref=f2e142]:
                              - generic [ref=f2e150]: Event counter
                          - listitem "Data access" [ref=f2e152]:
                            - button "Open Data access in Counter" [ref=f2e153]:
                              - generic [ref=f2e160]: Data access
                        - button "Add module" [ref=f2e162]
                    - group "Projector" [ref=f2e164]:
                      - generic [ref=f2e165]:
                        - generic [ref=f2e167]:
                          - generic [ref=f2e176]:
                            - generic [ref=f2e177]: Projector
                            - generic [ref=f2e178]: Worker
                          - list "Modules":
                            - listitem "Event consumer" [ref=f2e179]:
                              - button "Open Event consumer in Projector" [active] [ref=f2e180]:
                                - generic [ref=f2e188]: Event consumer
                          - button "Add module" [ref=f2e190]
                        - button "Add linked tile" [ref=f2e192]
                    - group "Totals" [ref=f2e197]:
                      - generic [ref=f2e200]:
                        - generic [ref=f2e208]: Totals
                        - generic [ref=f2e209]: Database
                        - 'img "Warning: Nothing reads Totals: only its declared writer Counter links to it. Link the service or API that reads it." [ref=f2e210]'
                    - group "Items" [ref=f2e213]:
                      - generic [ref=f2e216]:
                        - generic [ref=f2e224]: Items
                        - generic [ref=f2e225]: Database
                        - 'img "Warning: Nothing reads Items: only its declared writer Projector links to it. Link the service or API that reads it." [ref=f2e226]'
              - link "React Flow attribution" [ref=f2e230] [cursor=pointer]:
                - /url: https://reactflow.dev/attribution
                - text: React Flow
            - note "Line guide": Async
          - toolbar "Canvas tools" [ref=f2e232]:
            - button "Pointer" [pressed] [ref=f2e233] [cursor=pointer]
            - button "Connect" [ref=f2e236] [cursor=pointer]
            - button "Fit" [ref=f2e241] [cursor=pointer]
            - group "View" [ref=f2e248]:
              - button "Detailed" [pressed] [ref=f2e249] [cursor=pointer]
              - button "Simple" [ref=f2e250] [cursor=pointer]
        - separator "Inspector width" [ref=f2e251]
        - complementary "Inspector rail" [ref=f2e252]:
          - generic [ref=f2e253]:
            - strong [ref=f2e254]: Inspector
            - button "Close inspector" [ref=f2e255] [cursor=pointer]
          - generic [ref=f2e259]:
            - button "Back to Projector" [ref=f2e260] [cursor=pointer]:
              - generic [ref=f2e271]: Projector
            - form "Event consumer settings" [ref=f2e272]:
              - generic [ref=f2e273]:
                - generic [ref=f2e282]:
                  - generic [ref=f2e283]: Name
                  - textbox "Name" [ref=f2e284]: Event consumer
                - paragraph [ref=f2e285]: Event consumer
                - paragraph [ref=f2e286]:
                  - strong [ref=f2e287]: You write it
                  - generic [ref=f2e288]: No Generated module in Projector uses it, so you write it.
              - generic [ref=f2e289]:
                - generic [ref=f2e290]: Description
                - textbox "Description" [ref=f2e291]
              - button "Remove module" [ref=f2e293] [cursor=pointer]
  - contentinfo "Status" [ref=f2e294]:
    - status [ref=f2e295]: Server healthy
    - button "Dark mode" [ref=f2e298] [cursor=pointer]
```

# Test source

```ts
  11  |   page,
  12  |   tinyurl,
  13  | }, testInfo) => {
  14  |   await expect(tile(page, "Redirect service")).toBeVisible();
  15  |   const id = await createStudy(page, "E2E RG18 receipts", "blank");
  16  |   try {
  17  |     const original = receiptDesign();
  18  |     const link = original.architecture?.studio?.componentConnections?.find(
  19  |       (c) => c.from === "apply-item" && c.to.id === "items",
  20  |     );
  21  |     if (!link) throw Error("Missing state connection");
  22  |     const disconnected = applyOperations(
  23  |       original,
  24  |       buildStudioCommand(original, { type: "disconnectModule", link: link.id }).ops,
  25  |     );
  26  |     if (!disconnected.ok) throw Error("Cannot disconnect fixture");
  27  |     const source = disconnected.design;
  28  |     const generation = designGeneration(source);
  29  |     if (!generation) throw Error("Missing generation");
  30  |     const ops = studioStudySeedOperations(source);
  31  |     ops.push({ op: "setGeneration", generation });
  32  |     const seeded = await page.request.post(`/api/projects/${id}/operations`, {
  33  |       data: { baseRevision: 0, source: "api", ops },
  34  |     });
  35  |     expect(seeded.ok(), await seeded.text()).toBe(true);
  36  |     await page.reload();
  37  |     await ready(page);
  38  |     await page.getByRole("button", { name: "Collapse chat", exact: true }).click();
  39  |     await stillBoard(page);
  40  |     await page.getByRole("button", { name: "Connect", exact: true }).click();
  41  |     await stillBoard(page);
  42  |     await dragOnto(
  43  |       page,
  44  |       page.locator('.board .lane-container-row[data-module="apply-item"] .lane-container-row-dot'),
  45  |       tile(page, "Items"),
  46  |     );
  47  |     await page.mouse.up();
  48  |     await expect
  49  |       .poll(async () =>
  50  |         (
  51  |           (await design(page, id)).architecture?.studio as unknown as {
  52  |             componentConnections?: { from: string; to: { id: string } }[];
  53  |           }
  54  |         )?.componentConnections?.some((c) => c.from === "apply-item" && c.to.id === "items"),
  55  |       )
  56  |       .toBe(true);
  57  |     await page.getByRole("button", { name: "Pointer", exact: true }).click();
  58  |     await stillBoard(page);
  59  |     await page
  60  |       .locator('.board .lane-container-row[data-module="count-events"]')
  61  |       .getByRole("button")
  62  |       .first()
  63  |       .click();
  64  |     const inspector = page.locator(".studio-inspector");
  65  |     await expect(inspector.locator(".lane-module-status")).toHaveText("GeneratedEvent counter");
  66  |     await inspector.getByLabel("Maximum replay delay (seconds)", { exact: true }).fill("86400");
  67  |     await inspector.getByLabel("Name", { exact: true }).click();
  68  |     await expect
  69  |       .poll(async () => JSON.stringify(await design(page, id)))
  70  |       .toContain('"deliveryHorizonSeconds":86400');
  71  |     await page.screenshot({
  72  |       path: testInfo.outputPath("mouse-receipt-horizon.png"),
  73  |       fullPage: true,
  74  |     });
  75  |     const blueprint = await (
  76  |       await page.request.get(`/api/projects/${id}/blueprint?version=3`)
  77  |     ).json();
  78  |     expect(JSON.stringify(blueprint)).toContain('"deliveryHorizonSeconds":86400');
  79  |     await expect(inspector.getByLabel("Keep counted IDs (days)", { exact: true })).toHaveCount(0);
  80  |     await page
  81  |       .locator('.board .lane-container-row[data-module="apply-item"]')
  82  |       .getByRole("button")
  83  |       .first()
  84  |       .click();
  85  |     await inspector.getByLabel("Maximum replay delay (days)", { exact: true }).fill("31");
  86  |     await inspector.getByLabel("Name", { exact: true }).click();
  87  |     await expect
  88  |       .poll(async () => JSON.stringify(await design(page, id)))
  89  |       .toContain('"replayDays":31');
  90  |     await inspector.getByLabel("Keep counted IDs (days)", { exact: true }).fill("35");
  91  |     await inspector.getByLabel("Name", { exact: true }).click();
  92  |     await expect
  93  |       .poll(async () => JSON.stringify(await design(page, id)))
  94  |       .toContain('"receiptDays":35');
  95  |     await page.screenshot({
  96  |       path: testInfo.outputPath("mouse-consumer-retention.png"),
  97  |       fullPage: true,
  98  |     });
  99  |     await page.getByRole("button", { name: "Generate project", exact: true }).click();
  100 |     const preview = page.waitForResponse((r) =>
  101 |       r.url().endsWith("/experimental-generation/preview"),
  102 |     );
  103 |     await page.getByRole("button", { name: "Preview scaffold", exact: true }).click();
  104 |     const result = await (await preview).json();
  105 |     expect(result.report.findings).toEqual([]);
  106 |     const download = page.waitForEvent("download");
  107 |     await page.getByRole("button", { name: "Download project ZIP", exact: true }).click();
  108 |     expect((await download).suggestedFilename()).toMatch(/\.zip$/);
  109 |     expect(tinyurl).not.toBe(id);
  110 |   } finally {
> 111 |     await page.request.delete(`/api/projects/${id}`);
      |                              ^ Error: apiRequestContext.delete: Test timeout of 30000ms exceeded.
  112 |   }
  113 | });
  114 | 
```