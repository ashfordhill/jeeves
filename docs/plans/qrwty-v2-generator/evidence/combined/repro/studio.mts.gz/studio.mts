import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { chromium, expect } from '/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs';
import { stillBoard, showView, ready, tile } from '/home/ash/github/jeeves/jeeves/apps/web/e2e/studio.ts';
import { canonicalJson, sha256 } from '/home/ash/github/jeeves/jeeves-generator/src/json.ts';
const dir = new URL('.', import.meta.url).pathname;
const id = 'f742d1a4-d195-4418-b30f-a0cc15851ecf';
const original = '8994962f-abc4-4903-a609-616d9c8b7409';
const before = JSON.parse(await readFile(dir + '../derived-before.json', 'utf8'));
const store = async (name, data) => writeFile(dir + name, JSON.stringify(data, null, 2) + '\n');
const browser = await chromium.launch();
const page = await browser.newPage({ baseURL: 'http://127.0.0.1:4300', viewport: { width: 1920, height: 1200 }, acceptDownloads: true });
page.setDefaultTimeout(12_000);
const get = async (path) => {
  const response = await page.request.get('/api/projects/' + path);
  assert.ok(response.ok(), path + ' ' + response.status() + ' ' + await response.text());
  return response.json();
};
const getDesign = async () => (await get(id + '/design')).design;
const elements = (d) => d.architecture.studio.elements;
const components = (d) => d.architecture.studio.components;
const element = (d, name) => elements(d).find((row) => row.element === name);
const component = (d, name) => components(d).find((row) => row.id === name);
const inspector = page.locator('.studio-inspector');
const field = (label) => inspector.getByLabel(label, { exact: true });
const poll = (read, expected) => expect.poll(async () => read(await getDesign()), { timeout: 10000 }).toEqual(expected);
const setSelect = async (label, display, read, expected) => {
  if ((await field(label).inputValue()) !== expected) await field(label).selectOption({ label: display });
  await poll(read, expected);
  console.log(label, expected);
};
const setText = async (label, value, read, expected) => {
  if ((await field(label).inputValue()) !== value) {
    await field(label).fill(value);
    await field('Name').click();
  }
  await poll(read, expected);
  console.log(label, expected);
};
const openModule = async (id) => {
  await stillBoard(page);
  await page.locator('.board .lane-container-row[data-module="' + id + '"]').getByRole('button').first().click();
};
const screenshot = (name) => page.screenshot({ path: dir + name + '.png', animations: 'disabled' });
const copyInitial = JSON.parse(await readFile(dir + '../reviewed.json', 'utf8'));
const expected = structuredClone(copyInitial);
const descriptions = {
  identity: 'Auth0 issues the tokens that identify users and services.',
  'verified-payment-event': "Verifies Stripe's signature and saves the payment notice before replying.",
  'analytics-retention': 'Deletes expired daily totals and breakdowns even when no new clicks arrive. The click consumer expires counted IDs separately.',
};
expected.elements.find((row) => row.id === 'identity').description = descriptions.identity;
element(expected, 'identity').settings.provider = 'auth0';
for (const [name, settings] of Object.entries({
  'verified-payment-event': { signatureFormat: 'stripe', bodyLimitBytes: '262144' },
  'analytics-worker-click-aggregator': { replayDays: 31, receiptDays: 35 },
  'analytics-retention': { keepDailyTotalsMonths: 13 },
})) {
  const row = component(expected, name);
  if (descriptions[name]) row.description = descriptions[name];
  Object.assign(row.settings, settings);
}
const origBefore = (await get(original + '/design')).design;
try {
  const liveBefore = await getDesign();
  assert.deepEqual({ ...before, revision: 4 }, copyInitial);
  if (liveBefore.revision !== 1) {
    const strip = (d) => {
      d = structuredClone(d);
      d.revision = 4;
      d.elements.find((row) => row.id === 'identity').description = copyInitial.elements.find((row) => row.id === 'identity').description;
      element(d, 'identity').settings.provider = element(copyInitial, 'identity').settings.provider;
      for (const name of ['verified-payment-event', 'analytics-worker-click-aggregator', 'analytics-retention']) Object.assign(component(d, name), structuredClone(component(copyInitial, name)));
      return d;
    };
    assert.deepEqual(canonicalJson(strip(liveBefore)), canonicalJson(copyInitial), 'Existing edits outside review scope');
  } else {
    assert.equal(canonicalJson(liveBefore), canonicalJson(before), 'Derived project differs from coordinator seed');
  }
  await page.goto('/?project=' + id);
  await ready(page);
  const collapse = page.getByRole('button', { name: 'Collapse chat', exact: true });
  if (await collapse.isVisible()) await collapse.click();
  await showView(page, 'Simple');
  await tile(page, 'Identity').click();
  await setSelect('Identity provider', 'Auth0', (d) => element(d, 'identity').settings.provider, 'auth0');
  const identityDescription = (d) => d.elements.find((row) => row.id === 'identity').description;
  await setText('Description', descriptions.identity, identityDescription, descriptions.identity);
  await screenshot('mouse-simple-identity');
  await page.locator('.studio-inspector [aria-label="Close inspector"]').click({timeout: 1000}).catch(() => undefined);
  await stillBoard(page);
  await screenshot('view-simple');
  await showView(page, 'Detailed');
  const receiver = 'verified-payment-event';
  await openModule(receiver);
  await setSelect('Signature format', 'Stripe', (d) => component(d, receiver).settings.signatureFormat, 'stripe');
  await setSelect('Body limit', '256 KiB', (d) => component(d, receiver).settings.bodyLimitBytes, '262144');
  await setText('Description', descriptions[receiver], (d) => component(d, receiver).description, descriptions[receiver]);
  const aggregator = 'analytics-worker-click-aggregator';
  await openModule(aggregator);
  await setText('Maximum replay delay (days)', '31', (d) => component(d, aggregator).settings.replayDays, 31);
  await setText('Keep counted IDs (days)', '35', (d) => component(d, aggregator).settings.receiptDays, 35);
  const retention = 'analytics-retention';
  await openModule(retention);
  await setText('Keep daily totals (months)', '13', (d) => component(d, retention).settings.keepDailyTotalsMonths, 13);
  await setText('Description', descriptions[retention], (d) => component(d, retention).description, descriptions[retention]);
  await page.reload();
  await ready(page);
  if (await collapse.isVisible()) await collapse.click();
  await showView(page, 'Simple');
  await tile(page, 'Identity').click();
  await expect(field('Identity provider')).toHaveValue('auth0');
  await expect(field('Description')).toHaveValue(descriptions.identity);
  await showView(page, 'Detailed');
  await openModule(receiver);
  await expect(field('Signature format')).toHaveValue('stripe');
  await expect(field('Body limit')).toHaveValue('262144');
  await expect(field('Signature window (seconds)')).toHaveValue('300');
  await screenshot('mouse-detailed-stripe');
  await openModule(aggregator);
  await expect(field('Maximum replay delay (days)')).toHaveValue('31');
  await expect(field('Keep counted IDs (days)')).toHaveValue('35');
  await screenshot('mouse-detailed-receipt');
  await openModule(retention);
  await expect(field('Keep daily totals (months)')).toHaveValue('13');
  await expect(field('Interval (seconds)')).toHaveValue('60');
  await screenshot('mouse-detailed-calendar');
  await openModule('browser-session');
  await expect(field('Sign-in')).toHaveValue('optional');
  await expect(field('Refresh the login automatically')).toHaveValue('enabled');
  await expect(field('Remember guest visitors')).toHaveValue('enabled');
  await page.locator('.studio-inspector [aria-label="Close inspector"]').click({timeout: 1000}).catch(() => undefined);
  await stillBoard(page);
  await screenshot('view-detailed');
  const saved = await getDesign();
  expected.revision = saved.revision;
  await store('expected.json', expected);
  await store('saved-pretty.json', saved);
  assert.equal(canonicalJson(saved), canonicalJson(expected), 'Only the reviewed changes were allowed');
  const designBytes = canonicalJson(saved);
  await writeFile(dir + 'design.json', designBytes);
  const bp = await page.request.get('/api/projects/' + id + '/blueprint?version=3');
  assert.ok(bp.ok());
  const blueprint = await bp.body();
  await writeFile(dir + 'blueprint-v3.json', blueprint);
  assert.equal(JSON.parse(blueprint).services.find((row) => row.id === 'identity').settings.provider, 'auth0');
  await page.getByRole('button', { name: 'Generate project', exact: true }).click();
  const previewReady = page.waitForResponse((r) => r.url().endsWith('/experimental-generation/preview'));
  await page.getByRole('button', { name: 'Preview scaffold', exact: true }).click();
  const previewResponse = await previewReady;
  const preview = await previewResponse.json();
  await store('preview.json', preview);
  assert.ok(previewResponse.ok(), JSON.stringify(preview));
  assert.deepEqual(preview.report.findings, []);
  const readyDownload = page.waitForEvent('download');
  const zipResponse = page.waitForResponse((r) => r.url().endsWith('/experimental-generation/download'));
  await page.getByRole('button', { name: 'Download project ZIP', exact: true }).click();
  const [download, zipped] = await Promise.all([readyDownload, zipResponse]);
  assert.ok(zipped.ok());
  await download.saveAs(dir + 'studio.zip');
  const headers = await zipped.allHeaders();
  assert.equal(headers['x-source-sha256'], sha256(designBytes));
  assert.equal(headers['x-source-project'], id);
  assert.equal(headers['x-source-revision'], String(saved.revision));
  assert.equal(headers['x-archive-sha256'], sha256(await readFile(dir + 'studio.zip')));
  const origAfter = (await get(original + '/design')).design;
  assert.deepEqual(origAfter, origBefore);
  console.log('Saved', id, saved.revision, sha256(designBytes), headers['x-archive-sha256'], 'Original revision', origAfter.revision);
  await store('download-facts.json', { revision: saved.revision, sourceSha256: headers['x-source-sha256'], studioZipSha256: headers['x-archive-sha256'], manifestSha256: headers['x-manifest-sha256'], originalBeforeAfterRevision: origAfter.revision, originalBeforeAfterCanonicalSha256: sha256(canonicalJson(origAfter)), at: new Date().toISOString() });
} catch (error) {
  await screenshot('browser-failed');
  throw error;
} finally {
  await browser.close();
}
