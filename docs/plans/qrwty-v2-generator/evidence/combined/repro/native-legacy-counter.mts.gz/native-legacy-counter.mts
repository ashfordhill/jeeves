import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { mkdir, mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const harness = (name) => import(pathToFileURL(join(root, 'jeeves-generator/integration/harness', name + '.ts')).href);
const { brokerProbe } = await harness('activity');
const { withApplication } = await harness('application');
const { cleanupRun } = await harness('cleanup');
const { poll, sourceSnapshot, writeJson } = await harness('process');

const artifacts = resolve(process.argv[2] ?? '');
assert.notEqual(artifacts, root, 'Supply a fresh absolute artifact directory');
await mkdir(artifacts);
const runPath = join(artifacts, 'run.json');
const temporary = await mkdtemp(join(tmpdir(), 'jeeves-system-qr-legacy-counter-'));
await writeJson(runPath, { version: 1, id: 'gs-' + randomUUID(), suite: 'qr-legacy-counter-review', temporary, stacks: [] });
await writeJson(join(artifacts, 'source.json'), await sourceSnapshot());
process.env.JEEVES_SYSTEM_RECORD = runPath;

try {
  await withApplication(
    'qr-legacy-counter-review',
    ['module-stub', 'event-counter', 'module-stub'],
    async (app) => {
      const event = { aggregateKey: 'Activity:A', eventId: 'activity:one' };
      for (let publication = 0; publication < 2; publication++) {
        const reply = await app.request('/api/activity-api/modules/submit', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(event),
        });
        assert.deepEqual(reply, { status: 202, body: event });
      }
      const receipt = () => app.sql("SELECT scope_key||'|'||event_id||'|'||(result->>'value')||'|'||extract(epoch FROM retain_until-completed_at)::int FROM increment.receipts ORDER BY event_id");
      const row = 'event-counter-v2|activity:one|true|604800';
      await poll('one receipt stores the original seven-day policy', receipt, (value) => value === row, 30_000);
      await poll('both deliveries are settled', () => brokerProbe(app, 'state'), (value) => value.messageCount === 0 && value.unacknowledged === 0, 30_000);
      assert.equal(await app.sql("SELECT aggregate_key||'|'||total FROM increment.totals ORDER BY aggregate_key"), 'Activity:A|1');
      assert.equal(await receipt(), row);
      app.record({ name: 'older Event counter receipt and duplicate', publishStatuses: [202, 202], count: 1, persistedReceipt: row });
    },
  );
} finally {
  await cleanupRun(runPath);
}
