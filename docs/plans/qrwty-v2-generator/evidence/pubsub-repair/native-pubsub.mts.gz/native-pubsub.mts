import assert from 'node:assert/strict';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const harness = (name) => import(pathToFileURL(join(root, 'jeeves-generator/integration/harness', name + '.ts')).href);
const { default: Stripe } = await import(pathToFileURL(join(root, 'jeeves-generator/node_modules/stripe/esm/stripe.esm.node.js')).href);
const { healthyCopies, controlContainer } = await harness('activity');
const { withApplication } = await harness('application');
const { prepareAuth0, auth0Login, auth0Stats } = await harness('auth0');
const { processStates, assertNoProcessExited } = await harness('faults');
const { cleanupRun } = await harness('cleanup');
const { rememberSecrets } = await harness('evidence');
const { poll, sourceSnapshot, writeJson } = await harness('process');
const { pullNow } = await harness('pubsub');
const { native, finish } = await harness('rg-foundations');

const artifacts = resolve(process.argv[2] ?? '');
assert.notEqual(artifacts, root, 'Supply a fresh absolute artifact directory');
await mkdir(artifacts);
const runPath = join(artifacts, 'run.json');
const temporary = await mkdtemp(join(tmpdir(), 'jeeves-system-qr-combined-'));
await writeJson(runPath, { version: 1, id: 'gs-' + randomUUID(), suite: 'qr-combined-review', temporary, stacks: [] });
await writeJson(join(artifacts, 'source.json'), await sourceSnapshot());
process.env.JEEVES_SYSTEM_RECORD = runPath;

const browser = 'app-browser-api';
const receiver = 'app-payment-inbox';
const worker = 'app-click-processor';
const stripeRoute = '/modules/verified-payment-event';
const edge = '/api/payment-inbox' + stripeRoute;
const stripeSecret = 'whsec_' + randomBytes(32).toString('hex');
const products = 'p_click_processor_owner';
const click = { day: '2026-12-31', agent: 'mobile' };
const receiptSeconds = '3024000';
const sql = (app, statement) => app.sql(statement, 'd_analytics');
const billing = (app, statement) => app.sql(statement, 'd_billing');
const waitFor = (label, probe, value, ms = 35_000) => poll(label, probe, (seen) => seen === value, ms);
const clock = (app, instant) => sql(app, "UPDATE test_clock.time SET instant='" + instant + "'::timestamptz");
const receipt = (app, id) => sql(app, "SELECT extract(epoch FROM retain_until-completed_at)::int FROM jeeves.consumer_receipts WHERE event_id='" + id + "'");
const count = (app) => sql(app, "SELECT (SELECT total FROM " + products + ".daily WHERE day='2026-12-31')||'|'||(SELECT total FROM " + products + ".breakdowns WHERE day='2026-12-31' AND agent='mobile')");
const cutoff = (app) => sql(app, 'SELECT interval_seconds||\'|\'||months||\'|\'||cutoff_day FROM ' + products + '.sweeps ORDER BY observed_at DESC LIMIT 1');
const compact = (value) => JSON.stringify(value);

async function provision(app) {
  await prepareAuth0(app);
  await rememberSecrets(app.directory, stripeSecret);
  const stripeFile = join(app.directory, '../stripe-endpoint');
  await writeFile(stripeFile, stripeSecret, { mode: 0o644 });
  const overridePath = join(app.directory, 'compose.override.yaml');
  const override = JSON.parse(await readFile(overridePath, 'utf8'));
  override.services[receiver] = {
    environment: { JEEVES_SECRET_JEEVES_WEBHOOK_VERIFIED_PAYMENT_EVENT_STRIPE_SECRET_FILE: '/fixture-endpoint-secret' },
    volumes: ['../stripe-endpoint:/fixture-endpoint-secret:ro'],
  };
  await writeFile(overridePath, compact(override));
}

function readAccount(app, cookie, copyId) {
  return native(app, browser, `
const response=await fetch('http://127.0.0.1:3000/modules/account',{headers:{cookie:${compact(cookie)}}});
${finish("{status:response.status,body:await response.json()}")}
`, copyId);
}

async function verifyIdentity(app) {
  const [first, second] = await healthyCopies(app, browser, 2);
  const session = await auth0Login(app, 'alice');
  const expected = { status: 200, body: { subject: 'auth0|alice', plan: 'fixture' } };
  assert.equal(session.subject, 'auth0|alice');
  assert.deepEqual(await readAccount(app, session.cookie, first.Id), expected);
  const guard = await native(app, browser, `
const tokens=await(await fetch('http://auth0-issuer:9080/checks')).json();
async function billing(machine,user) {
  const headers={
    ...(machine?{'x-jeeves-workload':'Bearer '+machine}:{}),
    ...(user?{authorization:'Bearer '+user}:{})
  };
  const response=await fetch('http://app-billing-api:3000/internal/modules/billing-data',{headers});
  await response.arrayBuffer();return response.status;
}
const statuses={
  both:await billing(tokens.allowedMachine,tokens.user),
  onlyUser:await billing(null,tokens.user),
  onlyMachine:await billing(tokens.allowedMachine,null),
  undeclaredCaller:await billing(tokens.wrongCaller,tokens.user),
};
${finish("statuses")}
`, first.Id);
  assert.deepEqual(guard, { both: 200, onlyUser: 401, onlyMachine: 401, undeclaredCaller: 403 });
  await app.sql("UPDATE jeeves.browser_sessions SET access_expires_at=clock_timestamp()-interval '1 second' WHERE subject='auth0|alice' AND revoked_at IS NULL", 'd_sessions');
  const before = await auth0Stats(app);
  const results = await Promise.all([first, second].map(({ Id }) => readAccount(app, session.cookie, Id)));
  assert.deepEqual(results, [expected, expected]);
  const after = await auth0Stats(app);
  assert.equal(after.refreshes - before.refreshes, 1);
  assert.equal(after.rotations - before.rotations, 1);
  const generation = await app.sql("SELECT refresh_generation||'|'||refresh_uncertain FROM jeeves.browser_sessions WHERE subject='auth0|alice'", 'd_sessions');
  assert.equal(generation, '1|false');
  await controlContainer(app, browser, second.Id, 'stop');
  await controlContainer(app, browser, second.Id, 'start');
  await healthyCopies(app, browser, 2);
  assert.deepEqual(await readAccount(app, session.cookie, second.Id), expected);
  assert.equal((await auth0Stats(app)).refreshes, after.refreshes);
  app.record({ name: 'Auth0 Browser → Account → Billing', succeeded: expected, guard, browserCopies: [first.Id, second.Id], refreshes: 1, rotations: 1, generation, restartedCopyStatus: 200 });
}

const stripeEvent = (id, status, created) => compact({
  object: 'event', id, type: 'customer.subscription.updated', livemode: false, created,
  data: { object: { object: 'subscription', id: 'sub_fixture', customer: 'cus_fixture', status } },
});
function headers(payload) {
  return {
    'content-type': 'application/json',
    'stripe-signature': Stripe.webhooks.generateTestHeaderString({ payload, secret: stripeSecret }),
  };
}
function directStripe(app, payload, copyId) {
  return native(app, receiver, `
import {createHmac} from 'node:crypto';
const path=${compact(stripeRoute)}, seconds=String(Math.floor(Date.now()/1000));
const stamp='v1.'+seconds+'.'+createHmac('sha256',process.env.JEEVES_EDGE_STAMP_KEY).update(seconds+'.POST.'+path).digest('hex');
const response=await fetch('http://127.0.0.1:3000'+path,{method:'POST',headers:{... ${compact(headers(payload))},'x-edge-stamp':stamp},body:${compact(payload)}});
const value=await response.json();
${finish("{status:response.status,id:value.id}")}
`, copyId);
}

async function verifyStripe(app) {
  const id = 'evt_combined_active';
  const payload = stripeEvent(id, 'active', 200);
  const [first, second] = await healthyCopies(app, receiver, 2);
  const ingress = await app.request(edge, { method: 'POST', body: payload, headers: headers(payload) });
  assert.equal(ingress.status, 202);
  const hash = createHash('sha256').update(payload).digest('hex');
  assert.equal(await billing(app, "SELECT input->'value'->>'contentHash' FROM jeeves.work_records WHERE work_key='" + id + "'"), hash);
  const duplicate = await directStripe(app, payload, second.Id);
  assert.deepEqual(duplicate, { status: 202, id });
  await controlContainer(app, receiver, first.Id, 'stop');
  await controlContainer(app, receiver, first.Id, 'start');
  await healthyCopies(app, receiver, 2);
  const retries = await Promise.all([first, second].map(({ Id }) => directStripe(app, payload, Id)));
  assert.deepEqual(retries, [{ status: 202, id }, { status: 202, id }]);
  const row = () => billing(app, "SELECT state||'|'||retention_seconds||'|'||round(extract(epoch from expires_at-completed_at)) FROM jeeves.work_records WHERE work_key='" + id + "'");
  await waitFor('verified event completed for exactly 35 days', row, 'completed|3024000|3024000');
  const effect = () => billing(app, "SELECT (SELECT count(*) FROM p_payment_inbox_owner.subscription_events WHERE event_id='" + id + "')||'|'||status||'|'||event_created FROM p_payment_inbox_owner.subscriptions");
  assert.equal(await effect(), '1|active|200');
  const changed = stripeEvent(id, 'incomplete', 201);
  const conflict = await app.request(edge, { method: 'POST', body: changed, headers: headers(changed) });
  assert.equal(conflict.status, 409);
  const failed = 'evt_combined_failed';
  const failure = stripeEvent(failed, 'fixture-failure', 210);
  assert.equal((await app.request(edge, { method: 'POST', body: failure, headers: headers(failure) })).status, 202);
  await waitFor('failed Stripe event has no retention deadline', () => billing(app, "SELECT state||'|'||attempts||'|'||(expires_at IS NULL) FROM jeeves.work_records WHERE work_key='" + failed + "'"), 'failed|4|true');
  await billing(app, "WITH observed AS (SELECT clock_timestamp() AS now) UPDATE jeeves.work_records SET completed_at=observed.now-interval '35 days',expires_at=observed.now FROM observed WHERE work_key='" + id + "'");
  await waitFor('idle sweep expires completed Stripe row', row, '');
  assert.equal(await billing(app, "SELECT state FROM jeeves.work_records WHERE work_key='" + failed + "'"), 'failed');
  assert.equal(await effect(), '1|active|200');
  app.record({ name: 'Stripe ingress, cross-copy retries and idle expiry', firstStatus: ingress.status, digest: hash, receiverCopies: [first.Id, second.Id], duplicate, retries, conflict: conflict.status, retainedSeconds: 3024000, completedAtBoundaryRemoved: true, failedStillPresent: true, countedProductEffects: '1|active|200' });
}

function publishClick(app, copyId, id, payload, checkMetadata = false) {
  return native(app, worker, `
import {setTimeout as delay} from 'node:timers/promises';
import {pubsubPublisher} from './dist/runtime/module-clients.js';
const stops=[], owned=[], ready=[];
const scope={
  signal:new AbortController().signal,
  admission:stop=>stops.push(stop),
  own:close=>owned.push(close),
  dependencyReady:(_, state)=>ready.push(state)
};
const logger=Object.assign(()=>{}, {tile:'pubsub-smoke'});
const publisher=await pubsubPublisher(scope, logger, {topic:'click-events'});
try {
  if (${checkMetadata}) await delay(16500);
  const started=performance.now();
  await publisher.publish(Buffer.from(${compact(compact(payload))}),{messageId:${compact(id)}});
  ${finish("{published: true, ready, elapsedMs: Math.round(performance.now()-started)}")}
} finally {
  for(const stop of stops) stop();
  await Promise.all(owned.map(close=>close()));
}
`, copyId, 25_000);
}

async function verifyClicks(app) {
  await sql(app, `
CREATE SCHEMA test_clock;
CREATE TABLE test_clock.time(instant timestamptz NOT NULL);
INSERT INTO test_clock.time VALUES('2026-12-31T23:59:00Z');
CREATE FUNCTION test_clock.clock_timestamp() RETURNS timestamptz
  LANGUAGE sql STABLE AS 'SELECT instant FROM test_clock.time';
GRANT USAGE ON SCHEMA test_clock TO PUBLIC;
GRANT SELECT ON test_clock.time TO PUBLIC;
ALTER DATABASE d_analytics SET search_path = test_clock, pg_catalog, public;
ALTER DATABASE d_analytics SET TimeZone = 'Pacific/Kiritimati';
ALTER TABLE jeeves.work_records ALTER COLUMN next_attempt_at SET DEFAULT test_clock.clock_timestamp();
`);
  await app.compose(['restart', worker]);
  const [first] = await healthyCopies(app, worker, 1);
  await waitFor('month-end UTC clipping', () => cutoff(app), '60|13|2025-11-30');
  const submit = async (copy, id, payload, checkMetadata) => {
    const result = await publishClick(app, copy, id, payload, checkMetadata);
    assert.equal(result.published, true);
    assert(result.elapsedMs < 2000);
    if (checkMetadata) assert.deepEqual(result.ready, [true, true, true]);
    app.record({ name: 'Generated Pub/Sub publisher received broker confirmation', id, ...result });
  };
  const workers = (instant) => sql(app, "SELECT worker_id FROM jeeves.consumer_receipts_workers WHERE last_progress_at='" + instant + "'::timestamptz");
  await submit(first.Id, 'click-combined', click);
  await waitFor('receipt and aggregate commit before replay', () => receipt(app, 'click-combined'), receiptSeconds);
  assert.equal(await count(app), '1|1');
  const firstWorker = await workers('2026-12-31T23:59:00Z');
  assert.match(firstWorker, /^[a-f0-9-]{36}$/);
  await app.compose(['up', '-d', '--no-deps', '--scale', worker + '=2', worker]);
  const copies = await healthyCopies(app, worker, 2);
  const second = copies.find(({ Id }) => Id !== first.Id);
  assert(second);
  await controlContainer(app, worker, first.Id, 'stop');
  await clock(app, '2026-12-31T23:59:01Z');
  await submit(second.Id, 'click-combined', click);
  const secondWorker = await poll('second consumer committed replay path', () => workers('2026-12-31T23:59:01Z'), (id) => /^[a-f0-9-]{36}$/.test(id), 35_000);
  assert.notEqual(firstWorker, secondWorker);
  assert.equal(await count(app), '1|1');

  await sql(app, `
INSERT INTO ${products}.daily(day,total) VALUES('2025-11-30',10),('2025-12-01',10),('2025-12-02',10);
INSERT INTO ${products}.breakdowns(day,agent,total) VALUES('2025-11-30','idle',10),('2025-12-01','idle',10),('2025-12-02','idle',10);
`);
  await clock(app, '2027-01-01T00:00:00Z');
  await waitFor('idle UTC year-boundary sweep', () => cutoff(app), '60|13|2025-12-01');
  for (const table of ['daily', 'breakdowns'])
    assert.equal(await sql(app, "SELECT string_agg(to_char(day,'YYYY-MM-DD'),',' ORDER BY day) FROM " + products + '.' + table), '2025-12-01,2025-12-02,2026-12-31');
  assert.equal(await receipt(app, 'click-combined'), receiptSeconds);

  await clock(app, '2027-01-31T23:59:00Z');
  await waitFor('day 31 cutoff', () => cutoff(app), '60|13|2025-12-31');
  await submit(second.Id, 'click-combined', click);
  await waitFor('second consumer committed day-31 replay', () => workers('2027-01-31T23:59:00Z'), secondWorker);
  assert.equal(await count(app), '1|1');
  await submit(second.Id, 'click-exact-window', { day: '2027-01-31', agent: 'web', verifiedAgeSeconds: 2678400 });
  await waitFor('exact replay horizon accepted', () => receipt(app, 'click-exact-window'), receiptSeconds);
  await controlContainer(app, worker, first.Id, 'start');
  await healthyCopies(app, worker, 2);
  const before = await processStates(app);
  await submit(second.Id, 'click-smoke-publisher-probes', { day: '2027-01-31', agent: 'web' }, true);
  await waitFor('publisher probe witness counted', () => receipt(app, 'click-smoke-publisher-probes'), receiptSeconds);
  await assertNoProcessExited(app, before, 'two Pub/Sub consumers and three periodic probe cycles');
  await healthyCopies(app, worker, 2);
  await submit(second.Id, 'click-over-window', { day: '2027-01-31', agent: 'web', verifiedAgeSeconds: 2678401 });
  const failedQueue = app.report.processes.tiles.find((tile) => tile.tile === 'click-processor').loops[0].queue + '.failed';
  const failures = await poll('above-window message quarantined', () => pullNow(app, worker, failedQueue), (rows) => rows.some((row) => row.attributes.messageId === 'click-over-window'), 35_000);
  assert.equal(failures.find((row) => row.attributes.messageId === 'click-over-window').attributes['x-terminal-code'], 'MALFORMED_MESSAGE');
  assert.equal(await receipt(app, 'click-over-window'), '');

  const deadline = '2027-02-04T23:59:00Z';
  const maintenance = (date) => sql(app, "SELECT last_success_at='" + date + "'::timestamptz FROM jeeves.consumer_receipts_maintenance");
  assert.equal(await sql(app, "SELECT retain_until='" + deadline + "'::timestamptz FROM jeeves.consumer_receipts WHERE event_id='click-combined'"), 't');
  await clock(app, deadline);
  await waitFor('idle sweep ran at the exact receipt deadline', () => maintenance(deadline), 't');
  assert.equal(await receipt(app, 'click-combined'), receiptSeconds);
  await clock(app, '2027-02-04T23:59:00.000001Z');
  await waitFor('idle maintenance removes original receipt one microsecond later', () => receipt(app, 'click-combined'), '');
  assert.equal(await count(app), '1|1');
  assert.equal(await receipt(app, 'click-exact-window'), receiptSeconds);
  app.record({ name: 'two Pub/Sub consumers, replay and idle cleanup', workerCopies: [first.Id, second.Id], persistedWorkers: [firstWorker, secondWorker], day31: 'duplicate count and breakdown stay 1|1', replayMaximumSeconds: 2678400, aboveWindow: 'quarantined', receiptDeadline: deadline, deadlineEqualitySurvived: true, removedOneMicrosecondAfter: true, retentionSeconds: Number(receiptSeconds), calendarMonths: 13, intervalSeconds: 60, monthEndCutoff: '2025-11-30', nextYearCutoff: '2025-12-01', dailyAndBreakdownBoundarySurvived: true });
}

try {
  await withApplication(
    'qr-combined-review',
    ['browser-session', ...Array(3).fill('verified-identity'), ...Array(5).fill('module-stub'), 'webhook-receiver', 'scheduled-task'],
    async (app) => {
      await verifyClicks(app);
    },
    'design.json',
    { beforeStart: provision },
  );
} finally {
  await cleanupRun(runPath);
}
