if [ -f "$ARTIFACTS/run.json" ]; then
  if [ -f "$ARTIFACTS/cleanup.json" ]; then
    cp "$ARTIFACTS/cleanup.json" "$ARTIFACTS/runner-cleanup.json"
  fi
  pnpm test:generated --cleanup "$ARTIFACTS/run.json"
  node --input-type=module <<'JS'
import { readFile } from 'node:fs/promises';
const record = JSON.parse(await readFile(`${process.env.ARTIFACTS}/run.json`, 'utf8'));
const marker = JSON.parse(await readFile(`${process.env.ARTIFACTS}/sanitized.json`, 'utf8'));
if (marker.version !== 1 || marker.id !== record.id || marker.complete !== true)
  throw new Error('Sanitized marker does not match this run');
JS
  printf 'sanitized=true\n' >> "$GITHUB_OUTPUT"
fi

