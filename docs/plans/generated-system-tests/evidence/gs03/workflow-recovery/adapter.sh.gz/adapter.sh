node --input-type=module <<'JS'
import { cp, mkdir, rm, writeFile } from 'node:fs/promises';
await mkdir(process.env.ARTIFACT_ROOT, { recursive: true });
const upload = `${process.env.ARTIFACT_ROOT}/upload`;
await rm(upload, { recursive: true, force: true });
await mkdir(upload);
const sanitized = process.env.SANITIZED_ARTIFACTS === 'true';
await writeFile(`${upload}/adapter.json`, JSON.stringify({
  suite: process.env.SELECTED_SUITE,
  install: process.env.INSTALL_OUTCOME,
  builder: process.env.BUILDER_OUTCOME,
  generated: process.env.GENERATED_OUTCOME,
  cleanup: process.env.CLEANUP_OUTCOME,
  sanitizedArtifacts: sanitized,
}, null, 2) + '\n');
if (sanitized) await cp(process.env.ARTIFACTS, `${upload}/run`, { recursive: true });
JS

