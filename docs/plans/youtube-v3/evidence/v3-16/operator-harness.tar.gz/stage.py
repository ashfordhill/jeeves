#!/usr/bin/env python3
"""stage.py <copy> <step>: V3-16's search hooks as of <step>, in the order a message, then a search,
reaches them: 1 mapping, 2 event, 3 document.parse, 4 document.id, 5 document.version, 6 preset,
7 hit. Each later hook gets the export's own "Not implemented" body back."""
import pathlib, sys
REPO = pathlib.Path("/home/ash/github/jeeves"); APP = REPO / "field-projects/youtube/v3/app"
copy, step = pathlib.Path(sys.argv[1]), int(sys.argv[2])
NI = 'import { NotImplemented } from "../../runtime/tile-process.ts";\n'
def swap(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)
def stage(rel, hooks, anchor):
    text = (APP / rel).read_text(); stubbed = False
    for at, old, what in hooks:
        if step < at:
            indent = old[: len(old) - len(old.lstrip())]
            text = swap(text, old, f'{indent}throw new NotImplemented("{what}");'); stubbed = True
    if stubbed: text = swap(text, anchor, anchor + NI)
    (copy / rel).write_text(text)
W = "src/modules/search-indexer/search-indexer-index-writer.hooks.ts"
stage(W, [
    (1, "      return publicVideoMapping;", "mapping for Index writer"),
    (3, "        return publicVideo.parse(input);", "document.parse for Index writer"),
    (4, "        return document.videoId;", "document.id for Index writer"),
    (5, "        return document.publicationVersion;", "document.version for Index writer"),
    (2, """      const {
        schemaVersion: _schema,
        type: _type,
        eventId,
        occurredAt: _at,
        ...document
      } = wireEvent(videoPublished, raw, messageId);
      return { eventId, document };""", "event for Index writer"),
], 'import type { SearchIndexHooks } from "../../runtime/tile-search.ts";\n')
Q = "src/modules/search-api/search-api-video-search.hooks.ts"
stage(Q, [
    (6, "      return publicVideoQueryPreset;", "preset for Video search"),
    (7, """      return {
        videoId: document.videoId,
        title: document.title,
        description: document.description,
        channel: document.channel,
        durationSeconds: document.durationSeconds,
        publishedAt: document.publishedAt,
        thumbnailUrl: `${DELIVERY_PATH}${document.thumbnail}`,
      };""", "hit for Video search"),
], 'import type { SearchQueryHooks } from "../../runtime/tile-search.ts";\n')
print(f"staged step {step}")
