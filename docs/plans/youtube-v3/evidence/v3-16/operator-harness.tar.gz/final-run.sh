#!/usr/bin/env bash
# final-run.sh: the recorded browser run on a fresh first-run of app/ (the final copy): phase A by
# mouse, the view tap and receipts, a snapshot, pnpm stop and pnpm start, a snapshot, phase B.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v316/env-final.sh
R=$S/harness/runs; P=$COMPOSE_PROJECT_NAME
pg() { docker exec $P-local-postgres-1 psql -U postgres -d $1 -Atc "$2"; }
cd $S/final
docker compose --profile '*' down --volumes --remove-orphans > $S/down-final-3.log 2>&1; echo "reset down $?"
docker image rm "$P-app" "$P-media" >/dev/null 2>&1
rm -rf .runtime dist-public $S/browser/test-results $S/shots/*
t0=$(date +%s.%N); pnpm first-run > $S/final-first-run.log 2>&1; echo "first-run $? $(echo "$(date +%s.%N) - $t0" | bc | cut -c1-5) s"
t0=$(date +%s.%N); node scripts/accounts.mjs > $S/final-accounts.log 2>&1; echo "accounts $? $(echo "$(date +%s.%N) - $t0" | bc | cut -c1-4) s"
docker ps -a --filter label=com.docker.compose.project=$P --format '{{.Names}}' | xargs docker inspect --format '{{.State.Health.Status}} {{.RestartCount}}' | sort | uniq -c
for p in / /main.js /style.css /hls.min.js /runtime-config.js /nope /healthz; do curl -s -o /dev/null -w "edge $p %{http_code} %{content_type}\n" http://127.0.0.1:45680$p; done
$S/incontainer-final.sh app-watch-api tap.mjs MODE=setup | tr -d '\n '; echo
cd /home/ash/github/jeeves
node node_modules/@playwright/test/cli.js test -c $S/browser/app.config.mjs -g "A: creator" > $S/browser-A.log 2>&1; echo "phase A exit $?"
sleep 3
$S/incontainer-final.sh app-watch-api tap.mjs > $R/final-tap.json; node -e 'const t=require(process.argv[1]); for (const m of t["v316-tap-views"]) console.log("tap", m.messageId, m.eventId, m.videoId, "viewer", m.viewer); console.log("counter .failed", t["view-events--view-counter.failed"].count)' $R/final-tap.json
pg d_view_counts "select scope_key, event_id, identity::text from view_counter_receipt_and_increment.receipts order by 1,2" 2>&1 | cut -c1-300
pg i_sign_in "select u.username, u.id from user_entity u join realm r on r.id=u.realm_id where r.name='sign-in' order by 1"
echo "--- before stop"; $S/snapshot-final.sh > $R/final-before.txt; cat $R/final-before.txt
cd $S/final
t0=$(date +%s.%N); pnpm stop > $S/final-stop.log 2>&1; t1=$(date +%s.%N); pnpm start > $S/final-start.log 2>&1; echo "stop $(echo "$t1 - $t0" | bc | cut -c1-4) s, start $? $(echo "$(date +%s.%N) - $t1" | bc | cut -c1-5) s"
echo "--- after start"; $S/snapshot-final.sh > $R/final-after.txt; cat $R/final-after.txt
diff $R/final-before.txt $R/final-after.txt && echo "snapshots identical"
cd /home/ash/github/jeeves
node node_modules/@playwright/test/cli.js test -c $S/browser/app.config.mjs -g "B: after" > $S/browser-B.log 2>&1; echo "phase B exit $?"
echo "--- after phase B"; $S/snapshot-final.sh | grep -E 'favorites|totals|receipts'
