#!/usr/bin/env bash
# pass.sh <step>: restart at <step>; the creator uploads one fixture (titled for the step); once it is
# ready, the index state, a search probe and the not-implemented lines. All into runs/step<step>.txt.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v316/env.sh
out=$S/harness/runs/step$1.txt
{ $S/restart.sh $1 || exit 1
  since=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  (cd $S/harness && node upload.mjs step$1 fixture | tail -1)
  id=$(cat $S/harness/runs/step$1-ids)
  for i in $(seq 1 60); do
    s=$(docker exec $COMPOSE_PROJECT_NAME-local-postgres-1 psql -U postgres -d d_metadata -Atc "select state from upload_api_multipart_uploads.assets where asset_id='$id'")
    [ "$s" = ready ] && break; sleep 1; done
  echo "video $id $s after ${i} s"; sleep 3
  $S/incontainer.sh app-search-indexer indexstate.mjs
  (cd $S/harness && node searchprobe.mjs step$1 "step$1" "synthetic" "creator")
  echo "--- not-implemented since $since"
  for svc in app-search-indexer app-search-api; do docker logs --since $since $COMPOSE_PROJECT_NAME-$svc-1 2>&1 | grep -E 'not-implemented|"level":"(error|fatal)"' | sort | uniq -c | cut -c1-400; done
} > $out 2>&1
echo "step $1 done: $(head -2 $out | tr '\n' ' ')"
