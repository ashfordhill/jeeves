export PATH=~/.nvm/versions/node/v24.21.0/bin:$PATH
export S=/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v316
export COMPOSE_PROJECT_NAME=jeeves-v316-browser LOCAL_HTTP_PORT=45680 LOCAL_IDENTITY_PORT=45681 LOCAL_OBJECT_PORT=45682
export APP=$S/copy FIXTURE=$S/media/youtube-v1-fixture.mp4 INVALID=$S/media/invalid.mp4
