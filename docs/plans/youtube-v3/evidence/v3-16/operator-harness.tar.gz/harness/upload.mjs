// V3-16: the creator takes videos through V3-13's upload: node upload.mjs <label> [fixture|invalid|started]...
// fixture: v1's fixture, 3 parts, completed (V3-14 processes it to ready); invalid: a text file named
// invalid.mp4, completed (it fails INVALID_MEDIA); started: the fixture's upload started and left with
// no part sent (its video stays "uploading"). Writes ./runs/<label>-upload.json and -ids.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { PART, UPLOADS, api, log, putPart, sanitize, show, token } from "./lib.mjs";
const [label, ...kinds] = process.argv.slice(2);
const creator = await token("creator");
const as = { who: "creator", bearer: creator };
async function upload(kind) {
  const file = kind === "invalid" ? process.env.INVALID : process.env.FIXTURE;
  const bytes = readFileSync(file);
  const title = `V3-16 ${label}: ${kind === "invalid" ? "invalid media" : kind === "started" ? "never completed" : "test card"}`;
  const body = { fileName: kind === "invalid" ? "invalid.mp4" : "youtube-v1-fixture.mp4", size: bytes.length, contentType: "video/mp4", lastModified: 1762555020000, sha256: createHash("sha256").update(bytes).digest("hex"), title, description: `V3-16 ${label}: a 20 s synthetic test card and 440 Hz tone.` };
  const started = await api("POST", UPLOADS, { ...as, body });
  if (started.status !== 200) throw new Error(`start ${started.status}`);
  const id = started.body.uploadId;
  if (kind === "started") return { kind, title, uploadId: id, videoId: started.body.assetId };
  for (let n = 1; n <= Math.ceil(bytes.length / PART); n++) {
    const signed = await api("POST", `${UPLOADS}/${id}/parts/${n}`, as);
    const part = bytes.subarray((n - 1) * PART, n * PART);
    const etag = await putPart(signed.body.url, part);
    log.push({ method: "PUT", path: `<signed URL, part ${n}>`, who: "signed URL", status: 200, body: { etag, size: part.length } });
  }
  const done = await api("POST", `${UPLOADS}/${id}/complete`, as);
  if (done.status !== 200) {
    await api("POST", `${UPLOADS}/${id}/abort`, as);
    throw new Error(`complete ${done.status}`);
  }
  return { kind, title, size: bytes.length, ...done.body };
}
const uploads = [];
for (const kind of kinds) uploads.push(await upload(kind));
for (const e of log) console.log(show(e).slice(0, 260));
console.log(JSON.stringify(uploads));
writeFileSync(new URL(`./runs/${label}-upload.json`, import.meta.url), JSON.stringify(sanitize({ uploads, log }), null, 2));
writeFileSync(new URL(`./runs/${label}-ids`, import.meta.url), uploads.map((u) => u.videoId).join(" "));
