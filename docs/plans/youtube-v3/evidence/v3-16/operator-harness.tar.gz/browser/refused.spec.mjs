// V3-16: a refused sign-in on the watch page asks to sign in again; nothing is sent anonymously in its place.
import { readFileSync, writeFileSync } from "node:fs";
import { expect, test } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";
const S = "/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v316";
test("refused: a bad token asks to sign in again", async ({ page }) => {
  const { videoId } = JSON.parse(readFileSync(`${S}/harness/runs/browser-A.json`, "utf8"));
  const sent = [];
  page.on("request", (r) => { if (r.url().includes("/api/")) sent.push({ url: new URL(r.url()).pathname, auth: Boolean(r.headers().authorization) }); });
  await page.goto("/");
  await page.locator("#login").click();
  await page.locator("#username").click();
  await page.locator("#username").fill("viewer");
  await page.locator("#password").click();
  await page.locator("#password").fill(readFileSync(`${S}/final/.runtime/secrets/viewer_password`, "utf8").trim());
  await page.locator("#kc-login").click();
  await expect(page.locator("#identity")).toHaveText("Signed in as viewer");
  // The stored token's signature is changed: Watch API must refuse it (401).
  await page.evaluate(() => {
    const s = JSON.parse(sessionStorage.getItem("auth"));
    const [h, p, sig] = s.access.split(".");
    s.access = `${h}.${p}.${sig.slice(0, -4)}${sig.slice(-4) === "AAAA" ? "BBBB" : "AAAA"}`;
    sessionStorage.setItem("auth", JSON.stringify(s));
  });
  const mark = sent.length;
  await page.locator("#watch-id").click();
  await page.locator("#watch-id").fill(videoId);
  await page.locator("#watch-form button[type=submit]").click();
  await expect(page.locator("#watch-status")).toHaveText(/Sign in again/);
  await expect(page.locator("#message")).toHaveText(/Sign in again/);
  await expect(page.locator("#identity")).toHaveText("Signed out");
  await expect(page.locator("#login")).toBeVisible();
  await expect(page.locator("#favorites")).toBeHidden();
  await expect(page.locator("#watch-details")).toBeHidden();
  const after = sent.slice(mark);
  console.log(JSON.stringify({ after, watchStatus: await page.locator("#watch-status").textContent() }));
  expect(after.filter((r) => r.url.includes("video-details"))).toEqual([{ url: `/api/watch-api/modules/watch-api-video-details-cache/${videoId}`, auth: true }]);
  writeFileSync(`${S}/harness/runs/browser-refused.json`, JSON.stringify(after, null, 2));
});
