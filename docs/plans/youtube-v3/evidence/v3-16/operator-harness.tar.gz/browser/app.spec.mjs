// V3-16's browser run, by mouse (Playwright clicks at each control; text typed into fields). Phase A:
// the creator uploads with pause and resume, an anonymous viewer searches, watches and seeks, and
// the count rises; the viewer signs in, plays, favorites and unfavorites. Phase B (after pnpm stop
// and pnpm start): everything is still there. Writes runs/<phase>.json and at most 4 screenshots.
import { readFileSync, writeFileSync } from "node:fs";
import { expect, test } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";

const S = "/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v316";
const APP = process.env.APP ?? `${S}/copy`;
const FIXTURE = `${S}/media/youtube-v1-fixture.mp4`;
const SHOTS = `${S}/shots`;
const TITLE = "V3-16 browser: test card";
const DESCRIPTION = "A 20 s synthetic test card and 440 Hz tone, uploaded by mouse.";
const OBJECTS = "127.0.0.1:45682";
const files = { creator: "creator_password", viewer: "viewer_password" };
const password = (user) => readFileSync(`${APP}/.runtime/secrets/${files[user]}`, "utf8").trim();

function record(page) {
  const out = { errors: [], console: [], requests: [] };
  page.on("pageerror", (e) => out.errors.push(String(e)));
  page.on("console", (m) => {
    if (m.type() === "error") out.console.push(m.text());
  });
  const keep = (r, status) => {
    const u = new URL(r.url());
    if (u.host === OBJECTS || u.pathname.startsWith("/api/") || u.pathname.startsWith("/cdn/"))
      out.requests.push({
        at: Date.now(),
        method: r.method(),
        url: u.host === OBJECTS ? `${u.origin}${u.pathname}?partNumber=${u.searchParams.get("partNumber")}&<signature>` : `${u.pathname}${u.search}`,
        status,
        auth: Boolean(r.headers().authorization),
      });
  };
  page.on("requestfinished", async (r) => keep(r, (await r.response())?.status() ?? null));
  page.on("requestfailed", (r) => keep(r, `failed: ${r.failure()?.errorText}`));
  return out;
}
/** Every console error must be a refused fetch the page reads as an answer: 401 (sign in again), 403 (not a creator) or 404 (not ready, not a favorite). */
const unexpected = (out) => out.console.filter((t) => !/Failed to load resource: the server responded with a status of 40[134]/.test(t));
async function signIn(page, user) {
  await page.locator("#login").click();
  await page.waitForURL(/:45681\/realms\/sign-in\//);
  await page.locator("#username").click();
  await page.locator("#username").fill(user);
  await page.locator("#password").click();
  await page.locator("#password").fill(password(user));
  await page.locator("#kc-login").click();
  await page.waitForURL(/^http:\/\/127\.0\.0\.1:45680\//);
  await expect(page.locator("#identity")).toHaveText(`Signed in as ${user}`);
}
async function signOut(page) {
  await page.locator("#logout").click();
  await page.waitForURL(/^http:\/\/127\.0\.0\.1:45680\/$/);
  await expect(page.locator("#identity")).toHaveText("Signed out");
  await expect(page.locator("#login")).toBeVisible();
}
async function chooseFixture(page) {
  const chooser = page.waitForEvent("filechooser");
  await page.locator("#file").click();
  await (await chooser).setFiles(FIXTURE);
}
const video = (page) => page.locator("#player");
const media = (page) =>
  video(page).evaluate((v) => ({
    currentTime: v.currentTime,
    paused: v.paused,
    readyState: v.readyState,
    hlsJs: v.currentSrc.startsWith("blob:"),
    src: v.currentSrc.replace(/^(blob:).*/, "$1…"),
    frames: v.getVideoPlaybackQuality().totalVideoFrames,
    dropped: v.getVideoPlaybackQuality().droppedVideoFrames,
  }));
/** The player's box once it is wholly in view and the page has stopped scrolling. */
async function steadyBox(page) {
  await video(page).scrollIntoViewIfNeeded();
  let last = JSON.stringify(await video(page).boundingBox());
  for (let same = 0; same < 3; ) {
    await page.waitForTimeout(100);
    const now = JSON.stringify(await video(page).boundingBox());
    same = now === last ? same + 1 : 0;
    last = now;
  }
  return JSON.parse(last);
}
/** Clicks the player's own play/pause control (bottom left of Chromium's media controls). */
async function playPause(page) {
  const box = await steadyBox(page);
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.click(box.x + 24, box.y + box.height - 48);
}
/** Clicks the player's timeline at a fraction of its length. */
async function seekTo(page, fraction) {
  const box = await steadyBox(page);
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.click(box.x + 16 + fraction * (box.width - 32), box.y + box.height - 22);
}
async function views(page) {
  return Number((await page.locator("#watch-views").textContent()).replace(/\D/g, ""));
}
/** Plays until the page has sent its one view and the count shows `expected`. */
async function playAndCount(page, expected) {
  await playPause(page);
  await expect.poll(async () => (await media(page)).paused, { timeout: 10000 }).toBe(false);
  const started = Date.now();
  await expect(page.locator("#view-status")).toHaveText(/Playback accepted/, { timeout: 15000 });
  const accepted = Date.now() - started;
  await expect.poll(() => views(page), { timeout: 10000 }).toBe(expected);
  return { acceptedAfterMs: accepted, countVisibleAfterMs: Date.now() - started };
}

test("A: creator upload with pause and resume; anonymous search, watch, seek, count; viewer favorites", async ({ page }) => {
  const out = record(page);
  const result = { steps: [] };
  const step = (name, data = {}) => {
    result.steps.push({ name, at: new Date().toISOString(), ...data });
    console.log(`${name} ${JSON.stringify(data)}`);
  };
  await page.goto("/");
  await expect(page.locator("#identity")).toHaveText("Signed out");
  await expect(page.locator("#start")).toBeDisabled();
  await expect(page.locator("#favorites")).toBeHidden();
  step("opened signed out", { message: await page.locator("#message").textContent() });

  await signIn(page, "creator");
  await expect(page.locator("#start")).toBeEnabled();
  await expect(page.locator("#logout")).toBeVisible();
  await expect(page.locator("#favorites")).toBeVisible();
  step("creator signed in", { identity: await page.locator("#identity").textContent(), uploads: await page.locator("#uploads").textContent() });

  // Upload at about 1 MiB/s so part 2 is still sending when Pause is clicked.
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("Network.enable");
  await cdp.send("Network.emulateNetworkConditions", { offline: false, latency: 0, downloadThroughput: -1, uploadThroughput: 1024 * 1024 });
  await chooseFixture(page);
  await page.locator("#title").click();
  await page.locator("#title").fill(TITLE);
  await page.locator("#description").click();
  await page.locator("#description").fill(DESCRIPTION);
  await page.locator("#start").click();
  await expect(page.locator("#progress-text")).toHaveText(/Sending part 2 of 3/, { timeout: 60000 });
  await page.locator("#pause").click();
  await expect(page.locator("#message")).toHaveText(/Upload paused/);
  const beforePause = out.requests.filter((r) => r.url.includes(OBJECTS));
  step("paused during part 2", { puts: beforePause, current: await page.locator("#current").textContent() });
  await cdp.send("Network.emulateNetworkConditions", { offline: false, latency: 0, downloadThroughput: -1, uploadThroughput: -1 });

  await page.reload();
  await expect(page.locator("#identity")).toHaveText("Signed in as creator");
  await expect(page.locator("#resume")).toBeVisible();
  await expect(page.locator("#progress-text")).toHaveText(/^1 of 3 parts acknowledged · uploading$/);
  step("refreshed: the same upload selected, ListParts has part 1", { message: await page.locator("#message").textContent(), progress: await page.locator("#progress-text").textContent(), current: await page.locator("#current").textContent() });
  const mark = out.requests.length;
  await chooseFixture(page);
  await page.locator("#resume").click();
  await expect(page.locator("#message")).toHaveText(/Upload received/, { timeout: 60000 });
  const resumed = out.requests.slice(mark);
  const puts = resumed.filter((r) => r.url.includes(OBJECTS));
  expect(puts.map((r) => r.url.match(/partNumber=(\d)/)[1])).toEqual(["2", "3"]);
  const videoId = (await page.locator("#current").textContent()).match(/Video ([0-9a-f-]{36})/)[1];
  step("resumed: only parts 2 and 3 sent, completed", { videoId, puts, calls: resumed.filter((r) => !r.url.includes(OBJECTS)).map((r) => `${r.method} ${r.url} ${r.status}`) });

  const readyStart = Date.now();
  await expect(page.locator("#uploads .upload", { hasText: TITLE }).locator(".badge")).toHaveText("ready", { timeout: 90000 });
  await expect(page.locator("#current")).toContainText("ready");
  step("ready in the creator's list", { seenAfterMs: Date.now() - readyStart, row: await page.locator("#uploads .upload", { hasText: TITLE }).textContent() });
  await page.screenshot({ path: `${SHOTS}/v3-16-creator-upload.png`, fullPage: true });

  await signOut(page);
  await expect(page.locator("#start")).toBeDisabled();
  await expect(page.locator("#favorites")).toBeHidden();
  step("signed out");

  // Anonymous: search, open, play, count, seek.
  await page.locator("#search-query").click();
  await page.locator("#search-query").fill("synthetic test card");
  // The index is eventually consistent (S06: within 60 s of ready): search again, by mouse, until
  // it is found, as a person would.
  const hit = page.locator("#search-results article", { hasText: TITLE });
  const searches = [];
  for (let tries = 0; tries < 30; tries += 1) {
    await page.locator("#search-form button[type=submit]").click();
    await expect(page.locator("#search-status")).toHaveText(/results · Page 1|unavailable/);
    searches.push({ at: new Date().toISOString(), status: await page.locator("#search-status").textContent() });
    if (await hit.isVisible()) break;
    await page.waitForTimeout(2000);
  }
  await expect(hit).toBeVisible();
  step("anonymous search", { searches, sinceReadyMs: Date.now() - readyStart - result.steps.find((s) => s.name === "ready in the creator's list").seenAfterMs });
  for (const q of ["creator", "uploaded by mouse"]) {
    await page.locator("#search-query").click();
    await page.locator("#search-query").fill(q);
    await page.locator("#search-form button[type=submit]").click();
    await expect(page.locator("#search-results article", { hasText: TITLE })).toBeVisible();
    step(`anonymous search "${q}"`, { status: await page.locator("#search-status").textContent() });
  }
  await page.locator("#search-results article", { hasText: TITLE }).getByRole("button", { name: "Watch video" }).click();
  await expect(page.locator("#watch-title")).toHaveText(TITLE);
  await expect(page.locator("#favorite")).toBeHidden();
  await expect.poll(() => views(page)).toBe(0);
  step("anonymous watch page", { byline: await page.locator("#watch-byline").textContent(), views: await page.locator("#watch-views").textContent(), favoriteToggle: await page.locator("#favorite").isVisible(), favoritesList: await page.locator("#favorites").isVisible(), url: page.url() });
  const anonymousPlay = await playAndCount(page, 1);
  const played = await media(page);
  expect(played.frames).toBeGreaterThan(0);
  step("anonymous play counted", { ...anonymousPlay, media: played });
  await seekTo(page, 0.6);
  await expect.poll(async () => (await media(page)).currentTime, { timeout: 5000 }).toBeGreaterThan(10);
  const sought = await media(page);
  await page.waitForTimeout(3000);
  const later = await media(page);
  expect(later.currentTime).toBeGreaterThan(sought.currentTime);
  expect(await views(page)).toBe(1);
  step("seek by the timeline", { afterSeek: sought, threeSecondsLater: later, views: await views(page) });
  await page.screenshot({ path: `${SHOTS}/v3-16-anonymous-watch.png`, fullPage: true });
  await playPause(page);
  await expect.poll(async () => (await media(page)).paused).toBe(true);

  // A signed-in viewer on the watch page: the sign-in returns to the video.
  await signIn(page, "viewer");
  await expect(page).toHaveURL(new RegExp(`\\?watch=${videoId}$`));
  await expect(page.locator("#watch-title")).toHaveText(TITLE);
  await expect(page.locator("#favorite")).toHaveText("☆ Add to favorites");
  await expect(page.locator("#favorites-status")).toHaveText(/No favorites yet/);
  await expect(page.locator("#uploads")).toHaveText("Uploads need a creator account.");
  step("viewer signed in on the watch page", { message: await page.locator("#message").textContent(), views: await page.locator("#watch-views").textContent() });
  const viewerPlay = await playAndCount(page, 2);
  step("viewer play counted", { ...viewerPlay, media: await media(page) });
  await playPause(page);

  await page.locator("#favorite").click();
  await expect(page.locator("#favorite")).toHaveText("★ In favorites");
  await expect(page.locator("#favorites-list .upload", { hasText: TITLE })).toBeVisible();
  step("favorited", { list: await page.locator("#favorites").textContent() });
  await page.screenshot({ path: `${SHOTS}/v3-16-viewer-favorites.png`, fullPage: true });
  await page.locator("#favorite").click();
  await expect(page.locator("#favorite")).toHaveText("☆ Add to favorites");
  await expect(page.locator("#favorites-status")).toHaveText(/No favorites yet/);
  step("unfavorited", { list: await page.locator("#favorites").textContent() });
  await page.locator("#favorite").click();
  await expect(page.locator("#favorite")).toHaveText("★ In favorites");
  await expect(page.locator("#favorites-list .upload", { hasText: TITLE })).toBeVisible();
  step("favorited again, kept for the restart");

  result.videoId = videoId;
  result.pageErrors = out.errors;
  result.consoleErrors = out.console;
  result.requests = out.requests;
  writeFileSync(`${S}/harness/runs/browser-A.json`, JSON.stringify(result, null, 2));
  expect(out.errors).toEqual([]);
  expect(unexpected(out)).toEqual([]);
});

test("B: after pnpm stop and pnpm start, the video, its count, the upload and the favorite are kept", async ({ page }) => {
  const out = record(page);
  const result = { steps: [] };
  const step = (name, data = {}) => {
    result.steps.push({ name, at: new Date().toISOString(), ...data });
    console.log(`${name} ${JSON.stringify(data)}`);
  };
  const { videoId } = JSON.parse(readFileSync(`${S}/harness/runs/browser-A.json`, "utf8"));
  await page.goto("/");
  await page.locator("#search-query").click();
  await page.locator("#search-query").fill("synthetic test card");
  await page.locator("#search-form button[type=submit]").click();
  await page.locator("#search-results article", { hasText: TITLE }).getByRole("button", { name: "Watch video" }).click();
  await expect(page.locator("#watch-title")).toHaveText(TITLE);
  await expect.poll(() => views(page)).toBe(2);
  await expect.poll(async () => (await media(page)).readyState, { timeout: 10000 }).toBeGreaterThan(0);
  step("anonymous: found and opened, count kept", { views: await page.locator("#watch-views").textContent(), media: await media(page) });

  await signIn(page, "creator");
  await expect(page.locator("#uploads .upload", { hasText: TITLE }).locator(".badge")).toHaveText("ready");
  step("creator: the upload is ready", { row: await page.locator("#uploads .upload", { hasText: TITLE }).textContent() });
  await signOut(page);
  // A new sign-in asks for the password again (the Keycloak form), as S01 says.
  await signIn(page, "viewer");
  await expect(page.locator("#favorites-list .upload", { hasText: TITLE })).toBeVisible();
  await page.locator("#favorites-list .upload", { hasText: TITLE }).getByRole("button", { name: "Watch video" }).click();
  await expect(page.locator("#favorite")).toHaveText("★ In favorites");
  await expect.poll(() => views(page)).toBe(2);
  step("viewer: the favorite is kept", { list: await page.locator("#favorites").textContent(), url: page.url() });
  await page.screenshot({ path: `${SHOTS}/v3-16-after-restart.png`, fullPage: true });
  await page.locator("#favorites-list .upload", { hasText: TITLE }).getByRole("button", { name: "Remove" }).click();
  await expect(page.locator("#favorites-status")).toHaveText(/No favorites yet/);
  await expect(page.locator("#favorite")).toHaveText("☆ Add to favorites");
  step("removed from the list");
  expect(page.url()).toContain(videoId);
  result.pageErrors = out.errors;
  result.consoleErrors = out.console;
  result.requests = out.requests;
  writeFileSync(`${S}/harness/runs/browser-B.json`, JSON.stringify(result, null, 2));
  expect(out.errors).toEqual([]);
  expect(unexpected(out)).toEqual([]);
});
