// V3-16's browser run of app/ (the outside copy's edge, 45680), by mouse in Playwright's Chromium.
const S = "/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v316/browser";
export default {
  testDir: S,
  testMatch: /(app|refused)\.spec\.mjs$/,
  workers: 1,
  timeout: 420000,
  outputDir: `${S}/test-results`,
  reporter: [["list"]],
  use: { baseURL: "http://127.0.0.1:45680", viewport: { width: 1280, height: 900 }, trace: "off" },
  projects: [{ name: "chromium", use: { browserName: "chromium" } }],
};
