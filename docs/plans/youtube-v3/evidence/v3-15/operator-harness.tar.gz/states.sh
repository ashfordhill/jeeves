#!/usr/bin/env bash
# states.sh <label>: each listed video's lifecycle state (as the scratch run's postgres), and published.videos.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v315/env.sh
ids=$(cat $S/harness/runs/$1-ids); list=$(printf "'%s'," $ids); list=${list%,}
docker exec $COMPOSE_PROJECT_NAME-local-postgres-1 psql -U postgres -d d_metadata -c "select asset_id, metadata->>'title' title, state, state_version v, failure_code from upload_api_multipart_uploads.assets where asset_id in ($list) order by created_at" -c "select video_id, title, published_at, publication_version from published.videos order by published_at"
