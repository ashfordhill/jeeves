#!/usr/bin/env bash
# pass.sh <step>: restart at <step>, then one probe pass and the state; all into runs/step<step>.txt.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v315/env.sh
out=$S/harness/runs/step$1.txt
{ $S/restart.sh $1 || exit 1
  since=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  (cd $S/harness && node probe.mjs step$1)
  sleep 2; $S/watchstate.sh $since; } > $out 2>&1
echo "step $1 done: $(head -1 $out)"
