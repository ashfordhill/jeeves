// V3-15's browser check, by mouse: the TinyURL study renders in Detailed and Simple, at 1440×900
// and 1280×800, with no page or console error. The project is deleted afterwards.
import { createStudy, expect, lines, ready, showView, test, tiles } from "/home/ash/github/jeeves/jeeves/apps/web/e2e/studio.ts";
for (const [width, height] of [[1440, 900], [1280, 800]] as const) {
  test(`TinyURL renders at ${width}×${height}`, async ({ page }) => {
    const errors: string[] = [];
    page.on("pageerror", (error) => errors.push(`page: ${error}`));
    page.on("console", (message) => { if (message.type() === "error") errors.push(`console: ${message.text()}`); });
    await page.setViewportSize({ width, height });
    await page.goto("/");
    const id = await createStudy(page, `V3-15 browser ${width}`);
    try {
      for (const view of ["Detailed", "Simple"] as const) {
        await showView(page, view);
        await ready(page);
        const counts = { tiles: await tiles(page).count(), lines: await lines(page).count() };
        console.log(`${width}x${height} ${view}: ${counts.tiles} tiles, ${counts.lines} lines`);
        expect(counts.tiles).toBeGreaterThan(0);
        expect(counts.lines).toBeGreaterThan(0);
      }
    } finally {
      const removed = await page.request.delete(`/api/projects/${id}`);
      console.log(`deleted ${id}: ${removed.status()}`);
    }
    expect(errors).toEqual([]);
  });
}
