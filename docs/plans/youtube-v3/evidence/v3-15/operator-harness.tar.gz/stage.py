#!/usr/bin/env python3
"""stage.py <copy> <step>: V3-15's sources as of <step>, in the order a request reaches the hooks.
Each later hook is put back to the export's own "Not implemented" body; later files to V3-14's."""
import pathlib, subprocess, sys
REPO = pathlib.Path("/home/ash/github/jeeves"); APP = "field-projects/youtube/v3/app"
copy, step = pathlib.Path(sys.argv[1]), int(sys.argv[2])
final = lambda rel: (REPO / APP / rel).read_text()
head = lambda rel: subprocess.run(["git", "-C", str(REPO), "show", f"HEAD:{APP}/{rel}"], check=True, capture_output=True, text=True).stdout
def put(rel, text): (copy / rel).write_text(text)
def swap(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)
NI = 'import { NotImplemented } from "../../runtime/tile-process.ts";\n'
def ni(what): return f'throw new NotImplemented("{what}");'

C = "src/modules/video-contract.ts"; put(C, final(C) if step >= 1 else head(C))

D = "src/modules/watch-api/watch-api-video-details-cache.hooks.ts"
if step == 0: put(D, head(D))
else:
    t = final(D); stubbed = False
    if step < 2:
        t = swap(t, """      const result = await resources.source.query<PublishedVideoRow>(
        `SELECT video_id, title, description, channel, duration_seconds, manifest, thumbnail,
  published_at, publication_version FROM published.videos WHERE video_id = $1`,
        [videoId(input)],
      );
      const row = result.rows[0];
      return row ? watched(row) : null;""", "      " + ni("load for Video details cache")); stubbed = True
    if step < 3:
        t = swap(t, "    codec: watchedVideo,", "    codec: {\n      parse(value) {\n        " + ni("codec for Video details cache") + "\n      },\n    },"); stubbed = True
    if step < 4:
        t = swap(t, "      return record.videoId === videoId(input);", "      " + ni("eligible for Video details cache")); stubbed = True
    if step < 5:
        t = swap(t, "    expiresAt() {\n      return null;", "    expiresAt(record) {\n      " + ni("expiresAt for Video details cache")); stubbed = True
    if stubbed: t = swap(t, 'import type { PositiveReadAdapter } from "../../runtime/positive-cache.ts";\n', 'import type { PositiveReadAdapter } from "../../runtime/positive-cache.ts";\n' + NI)
    put(D, t)

for rel, at in [("src/modules/watch-api/watch-api-view-count-reader.ts", 6),
                ("src/modules/watch-api/watch-api-view-publisher.ts", 7),
                ("src/modules/dependencies.ts", 7),
                ("src/runtime/module-clients.ts", 9),
                ("src/modules/account-api/account-api-favorite-videos.hooks.ts", 13)]:
    put(rel, final(rel) if step >= at else head(rel))

K = "src/modules/view-counter/view-counter-receipt-and-increment.hooks.ts"
if step < 8: put(K, head(K))
else:
    t = final(K); stubbed = False
    for at, old, what in [(10, "      return event.videoId;", "aggregateKey"), (11, "      return event.eventId;", "eventId")]:
        if step < at: t = swap(t, old, "      " + ni(f"{what} for Receipt and increment")); stubbed = True
    if step < 12:
        t = swap(t, """      return {
        schemaVersion: event.schemaVersion,
        type: event.type,
        videoId: event.videoId,
        eventId: event.eventId,
        publicationVersion: event.publicationVersion,
        viewer: event.viewer,
      };""", "      " + ni("identity for Receipt and increment")); stubbed = True
    if stubbed: t = swap(t, 'import type { CounterAdapter } from "../../runtime/event-counter.ts";\n', 'import type { CounterAdapter } from "../../runtime/event-counter.ts";\n' + NI)
    put(K, t)
print(f"staged step {step}")
