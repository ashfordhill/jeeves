// V3-15 extras: node extras.mjs conflict | video <label> <videoId>
// conflict: the viewer reports a play, then the same event ID is sent again anonymously (another
// viewer for the same play). video: details, a play and a favorite of one video, then the favorite
// removed. Writes ./runs/<label>.json.
import { randomUUID } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { api, log, token } from "./lib.mjs";
const W = "/api/watch-api/modules";
const FAV = "/api/account-api/modules/account-api-favorite-videos/items";
const [mode, label = mode, id] = process.argv.slice(2);
const viewer = await token("viewer");
const v = { who: "viewer", bearer: viewer };
const out = { mode, label };
if (mode === "conflict") {
  const READY = readFileSync(new URL("./runs/videos-ids", import.meta.url), "utf8").trim().split(" ")[0];
  const eventId = randomUUID();
  out.eventId = eventId;
  out.before = (await api("GET", `${W}/watch-api-view-count-reader/${READY}`)).body;
  await api("POST", `${W}/watch-api-view-publisher/${READY}`, { ...v, body: { eventId } });
  await new Promise((r) => setTimeout(r, 2000));
  await api("POST", `${W}/watch-api-view-publisher/${READY}`, { body: { eventId } });
  await new Promise((r) => setTimeout(r, 12000));
  out.after = (await api("GET", `${W}/watch-api-view-count-reader/${READY}`)).body;
} else {
  await api("GET", `${W}/watch-api-video-details-cache/${id}`);
  await api("GET", `${W}/watch-api-view-count-reader/${id}`);
  await api("POST", `${W}/watch-api-view-publisher/${id}`, { body: { eventId: randomUUID() } });
  const added = await api("PUT", `${FAV}/${id}`, v);
  if (added.status === 200) await api("DELETE", `${FAV}/${id}`, v);
}
out.log = log;
writeFileSync(new URL(`./runs/${label}.json`, import.meta.url), JSON.stringify(out, null, 2));
for (const e of log) console.log(`${e.method} ${e.path.replace(W, "W").replace(FAV, "FAV")} [${e.who}]${e.request ? " " + JSON.stringify(e.request) : ""} → ${e.status} ${JSON.stringify(e.body).slice(0, 160)}`);
console.log(JSON.stringify({ before: out.before, after: out.after, eventId: out.eventId }));
