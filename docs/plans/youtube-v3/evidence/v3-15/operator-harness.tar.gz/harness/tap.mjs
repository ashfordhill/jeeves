// Inside app-watch-api (cwd /app). MODE=setup binds a scratch queue to the View events exchange;
// MODE=drain takes (acks) what it got since the last drain and peeks (puts back) the counter's
// .failed queue. Prints JSON.
import amqp from "amqplib";
import { readFileSync } from "node:fs";
const password = readFileSync("/run/secrets/broker-password", "utf8").trim();
const connection = await amqp.connect({ hostname: "local-broker", username: "runtime", password });
const channel = await connection.createChannel();
const tap = ["v315-tap-views", "view-events"];
const failed = "view-events--view-counter.failed";
const out = {};
if (process.env.MODE === "setup") {
  await channel.assertQueue(tap[0], { durable: true });
  await channel.bindQueue(tap[0], tap[1], "");
  out.bound = tap;
} else {
  out[tap[0]] = [];
  for (let m; (m = await channel.get(tap[0], { noAck: false })); ) {
    out[tap[0]].push({ messageId: m.properties.messageId, ...JSON.parse(m.content.toString()) });
    channel.ack(m);
  }
  const got = [];
  for (let m; (m = await channel.get(failed, { noAck: false })); ) got.push(m);
  out[failed] = {
    count: got.length,
    last: got.slice(-4).map((m) => ({ messageId: m.properties.messageId, eventId: JSON.parse(m.content.toString()).eventId, attempt: m.properties.headers?.["x-delivery-attempt"], code: m.properties.headers?.["x-terminal-code"] })),
  };
  for (const m of got) channel.nack(m, false, true);
}
console.log(JSON.stringify(out, null, 1));
await channel.close();
await connection.close();
