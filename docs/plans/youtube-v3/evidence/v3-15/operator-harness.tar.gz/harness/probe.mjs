// V3-15: one pass over Watch API and Account API through the edge. node probe.mjs <label> [plays]
// Videos: ./runs/videos-ids (ready, failed, uploading), plus PENDING=<id> when set. Each pass makes two
// fresh plays (anonymous and the viewer) and retries both with the same event IDs; then favorites.
// Writes ./runs/<label>.json. Tokens are kept in memory only.
import { randomUUID } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { api, claims, log, tampered, token } from "./lib.mjs";
const label = process.argv[2];
const [READY, FAILED, UPLOADING] = readFileSync(new URL("./runs/videos-ids", import.meta.url), "utf8").trim().split(" ");
const PENDING = process.env.PENDING;
const W = "/api/watch-api/modules";
const details = (id) => `${W}/watch-api-video-details-cache/${id}`;
const count = (id) => `${W}/watch-api-view-count-reader/${id}`;
const play = (id) => `${W}/watch-api-view-publisher/${id}`;
const FAV = "/api/account-api/modules/account-api-favorite-videos/items";
const viewer = await token("viewer");
const bad = tampered(viewer);
const v = { who: "viewer", bearer: viewer }, t = { who: "tampered", bearer: bad };
const out = { label, subject: claims(viewer).sub, videos: { READY, FAILED, UPLOADING, PENDING } };
const mark = (name) => (out[name] = log.length);

mark("me");
await api("GET", `${W}/watch-api-viewer-check/me`);
await api("GET", `${W}/watch-api-viewer-check/me`, v);
await api("GET", `${W}/watch-api-viewer-check/me`, t);

mark("details");
await api("GET", details(READY));
await api("GET", details(READY), v);
await api("GET", details(READY.toUpperCase()));
await api("GET", details(READY), t);
for (const id of [FAILED, UPLOADING, PENDING, randomUUID()].filter(Boolean)) await api("GET", details(id));
await api("GET", details("not-a-video"));

mark("countBefore");
const before = await api("GET", count(READY));
await api("GET", count(READY), t);

mark("plays");
const anonymousPlay = randomUUID(), viewerPlay = randomUUID();
const a1 = await api("POST", play(READY), { body: { eventId: anonymousPlay } });
const b1 = await api("POST", play(READY), { ...v, body: { eventId: viewerPlay } });
await api("POST", play(READY), { body: { eventId: anonymousPlay } });
await api("POST", play(READY), { ...v, body: { eventId: viewerPlay } });
await api("POST", play(READY), { ...t, body: { eventId: randomUUID() } });
for (const id of [FAILED, UPLOADING, PENDING].filter(Boolean)) await api("POST", play(id), { body: { eventId: randomUUID() } });
await api("POST", play(READY), { body: { eventId: "x", seconds: 2 } });
await api("GET", play(READY));
out.plays = { anonymousPlay, viewerPlay, accepted: [a1.status, b1.status] };

mark("countAfter");
let after = before;
if (a1.status === 202 && typeof before.body?.views === "string") {
  const target = BigInt(before.body.views) + 2n;
  for (let i = 0; i < 20; i++) {
    await new Promise((r) => setTimeout(r, 500));
    after = await api("GET", count(READY));
    if (BigInt(after.body.views) >= target) break;
    log.pop();
  }
  await new Promise((r) => setTimeout(r, 3000));
  after = await api("GET", count(READY));
}
out.counts = { before: before.body?.views, after: after.body?.views };

mark("favorites");
for (const [m, p] of [["PUT", `${FAV}/${READY}`], ["GET", `${FAV}/${READY}`], ["GET", FAV], ["DELETE", `${FAV}/${READY}`]]) {
  await api(m, p);
  await api(m, p, t);
}
await api("PUT", `${FAV}/${READY}`, v);
await new Promise((r) => setTimeout(r, 20));
await api("PUT", `${FAV}/${READY}`, v);
await api("GET", `${FAV}/${READY}`, v);
await api("GET", FAV, v);
await api("DELETE", `${FAV}/${READY}`, v);
await api("GET", `${FAV}/${READY}`, v);
for (const id of [FAILED, UPLOADING, PENDING, randomUUID(), READY.toUpperCase()].filter(Boolean)) await api("PUT", `${FAV}/${id}`, v);
await api("PUT", `${FAV}/bad%20id!`, v);
await api("PUT", `${FAV}/${READY}`, v); // kept, for the stop-and-start check
await api("GET", FAV, v);
out.log = log;
writeFileSync(new URL(`./runs/${label}.json`, import.meta.url), JSON.stringify(out, null, 2));
const name = (path) => path.replace(W, "W").replace(FAV, "FAV").replaceAll(READY, "<ready>").replaceAll(READY.toUpperCase(), "<READY>").replace(FAILED, "<failed>").replace(UPLOADING, "<uploading>").replace(PENDING ?? "\0", "<pending>").replace(/[0-9a-f]{8}-[0-9a-f-]{27}/, "<unknown>");
for (const e of log) console.log(`${e.method} ${name(e.path)} [${e.who}]${e.request ? " " + JSON.stringify(e.request).replace(anonymousPlay, "<A>").replace(viewerPlay, "<B>") : ""} → ${e.status} ${JSON.stringify(e.body).slice(0, 150)}`);
console.log(JSON.stringify({ plays: out.plays, counts: out.counts }));
