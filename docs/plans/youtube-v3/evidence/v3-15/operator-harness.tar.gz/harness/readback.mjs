// V3-15: after pnpm stop and pnpm start, read back details, counts and the viewer's favorites.
import { readFileSync, writeFileSync } from "node:fs";
import { api, log, token } from "./lib.mjs";
const W = "/api/watch-api/modules";
const ids = [readFileSync(new URL("./runs/videos-ids", import.meta.url), "utf8").split(" ")[0], readFileSync(new URL("./runs/pending-ids", import.meta.url), "utf8").trim()];
const viewer = await token("viewer");
for (const id of ids) {
  await api("GET", `${W}/watch-api-video-details-cache/${id}`);
  await api("GET", `${W}/watch-api-view-count-reader/${id}`);
}
await api("GET", "/api/account-api/modules/account-api-favorite-videos/items", { who: "viewer", bearer: viewer });
await api("GET", `${W}/watch-api-viewer-check/me`, { who: "viewer", bearer: viewer });
writeFileSync(new URL("./runs/readback.json", import.meta.url), JSON.stringify(log, null, 2));
for (const e of log) console.log(`${e.method} ${e.path} [${e.who}] → ${e.status} ${JSON.stringify(e.body).slice(0, 140)}`);
