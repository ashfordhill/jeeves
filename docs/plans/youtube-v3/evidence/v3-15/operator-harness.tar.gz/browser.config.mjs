// V3-15's scratch browser check: my API (4467, scratch database jeeves_v315) and Vite (4477).
export default {
  testDir: "/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v315",
  testMatch: "browser-check.spec.ts",
  workers: 1,
  outputDir: "/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v315/test-results",
  reporter: [["list"]],
  use: { baseURL: "http://127.0.0.1:4477" },
  projects: [{ name: "chromium", use: { browserName: "chromium", viewport: { width: 1440, height: 900 } } }],
};
