#!/usr/bin/env bash
# snapshot.sh: a comparable record of the copy's runtime: secrets, setup, volumes, counts, receipts,
# favorites, published.videos, the cached record and the accounts.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v315/env.sh
cd $S/copy; P=$COMPOSE_PROJECT_NAME
pg() { docker exec $P-local-postgres-1 psql -U postgres -d $1 -Atc "$2"; }
vk() { docker exec $P-cache-hot-metadata-1 sh -c "REDISCLI_AUTH=\"\$(cat /run/secrets/cache-hot-metadata)\" valkey-cli $*" 2>/dev/null; }
stat -c '%a %n' .runtime .runtime/secrets
echo "secrets $(ls .runtime/secrets | wc -l) $(cat .runtime/secrets/* | sha256sum | cut -c1-16)"
echo "setup $(sha256sum .runtime/local-setup.json | cut -c1-16)"
docker volume ls -q --filter label=com.docker.compose.project=$P | xargs docker volume inspect --format '{{.Name}} {{.CreatedAt}}'
echo "totals $(pg d_view_counts "select aggregate_key||'='||total from view_counter_receipt_and_increment.totals order by 1" | tr '\n' ' ')"
echo "receipts $(pg d_view_counts "select count(*) from view_counter_receipt_and_increment.receipts") $(pg d_view_counts "select * from view_counter_receipt_and_increment.receipts order by scope_key, event_id" | sha256sum | cut -c1-16)"
echo "favorites $(pg d_favorites "select count(*) from account_api_favorite_videos.favorites") $(pg d_favorites "select account, item, added_at from account_api_favorite_videos.favorites order by 1,2" | sha256sum | cut -c1-16)"
echo "published.videos $(pg d_metadata "select video_id from published.videos order by 1" | tr '\n' ' ')$(pg d_metadata "select * from published.videos order by 1" | sha256sum | cut -c1-16)"
echo "cache $(for k in $(vk --scan --pattern "'ready-video:*'"); do echo -n "$k $(vk GET $k | sha256sum | cut -c1-16) "; done)"
echo "accounts $(pg i_sign_in "select string_agg(u.username, ',' order by u.username) from user_entity u join realm r on r.id=u.realm_id where r.name='sign-in'")"
docker ps -a --filter label=com.docker.compose.project=$P --format '{{.Names}}' | xargs docker inspect --format '{{.State.Health.Status}} {{.RestartCount}}' | sort | uniq -c
