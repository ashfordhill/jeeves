#!/usr/bin/env bash
# watchstate.sh <since>: the cache, the counter's rows, favorites, the View events queues, the tap
# and dead letters, and the not-implemented log lines since <since>.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v315/env.sh
since=$1; P=$COMPOSE_PROJECT_NAME
vk() { docker exec $P-cache-hot-metadata-1 sh -c "REDISCLI_AUTH=\"\$(cat /run/secrets/cache-hot-metadata)\" valkey-cli $*" 2>/dev/null; }
echo "== cache"; vk INFO stats | grep -E 'keyspace_(hits|misses)' | tr -d '\r' | tr '\n' ' '; echo
for k in $(vk --scan --pattern "'ready-video:*'"); do echo "$k pttl=$(vk PTTL $k | tr -d '\r') bytes=$(vk STRLEN $k | tr -d '\r')"; done
pg() { docker exec $P-local-postgres-1 psql -U postgres -d $1 -c "$2"; }
echo "== totals and receipts"; pg d_view_counts "select aggregate_key, total from view_counter_receipt_and_increment.totals"; pg d_view_counts "select scope_key, event_id, payload->'identity'->>'viewer' viewer, result->'value' applied, handled_at::time(3) handled from view_counter_receipt_and_increment.receipts order by handled_at"
echo "== favorites"; pg d_favorites "select account, item, added_at from account_api_favorite_videos.favorites order by added_at"
echo "== queues"; docker exec $P-local-broker-1 rabbitmqctl list_queues -q name messages messages_unacknowledged 2>/dev/null | grep -E 'view|name' | sort | tr "\t" " "
echo "== tap and dead letters"; $S/incontainer.sh app-watch-api tap.mjs MODE=drain
echo "== not-implemented and errors (watch, counter, account)"
for svc in app-watch-api app-view-counter app-account-api; do docker logs --since "$since" $P-$svc-1 2>&1 | grep -E '"not-implemented"|"loop-error"|rror' | cut -c1-400; done
