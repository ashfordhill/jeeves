#!/usr/bin/env bash
# restart.sh <step>: stage V3-15's sources as of <step> into the outside copy (stage.py), build,
# then pnpm stop and pnpm start; print timings and health.
set -euo pipefail
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v315/env.sh
A=/home/ash/github/jeeves/field-projects/youtube/v3/app
rsync -a "$A/scripts/" "$S/copy/scripts/"; rsync -a "$A/infra/" "$S/copy/infra/"; rsync -a --delete "$A/test/" "$S/copy/test/"
python3 $S/stage.py $S/copy $1
cd $S/copy
pnpm build > "$S/build-$1.log" 2>&1 || { cat "$S/build-$1.log"; exit 1; }
t0=$(date +%s.%N); pnpm stop > "$S/stop-$1.log" 2>&1; t1=$(date +%s.%N)
pnpm start > "$S/start-$1.log" 2>&1 || { tail -30 "$S/start-$1.log"; exit 1; }; t2=$(date +%s.%N)
echo "step $1: stop $(echo "$t1 - $t0" | bc | cut -c1-5) s, start $(echo "$t2 - $t1" | bc | cut -c1-5) s"
docker ps -a --filter label=com.docker.compose.project=$COMPOSE_PROJECT_NAME --format '{{.Names}}' | xargs docker inspect --format '{{.State.Health.Status}} {{.RestartCount}}' | sort | uniq -c
