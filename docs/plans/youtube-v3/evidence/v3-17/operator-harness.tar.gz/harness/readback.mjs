// V3-17 after pnpm stop and pnpm start, by API: details and counts of the ready videos, the viewer's
// favorites, who is calling, a search, and the private original.
import { readFileSync, writeFileSync } from "node:fs";
import { api, log, token } from "./lib.mjs";
const W = "/api/watch-api/modules";
const A = JSON.parse(readFileSync(new URL("./runs/browser-A.json", import.meta.url), "utf8")).videoId;
const [B, , key] = readFileSync(new URL("./runs/api-upload-ids", import.meta.url), "utf8").trim().split(" ");
const viewer = await token("viewer");
for (const id of [A, B]) {
  await api("GET", `${W}/watch-api-video-details-cache/${id}`);
  await api("GET", `${W}/watch-api-view-count-reader/${id}`);
}
await api("GET", "/api/account-api/modules/account-api-favorite-videos/items", { who: "viewer", bearer: viewer });
await api("GET", `${W}/watch-api-viewer-check/me`, { who: "viewer", bearer: viewer });
await api("GET", "/api/search-api/modules/search-api-video-search?q=creator");
const original = await fetch(`http://127.0.0.1:${process.env.LOCAL_OBJECT_PORT}/original-videos/${key}`);
log.push({ method: "GET", path: `<objects>/original-videos/<B's original>`, who: "anonymous", status: original.status, body: (await original.text()).slice(0, 80) });
writeFileSync(new URL("./runs/readback.json", import.meta.url), JSON.stringify(log, null, 2));
for (const e of log) console.log(`${e.method} ${e.path.replace(W, "W")} [${e.who}] → ${e.status} ${JSON.stringify(e.body.total !== undefined ? { total: e.body.total } : e.body).slice(0, 170)}`);
