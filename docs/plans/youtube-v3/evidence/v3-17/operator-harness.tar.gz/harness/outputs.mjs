// Inside app-transcoder (cwd /app), with its own storage key: VIDEO=<id> lists Transcoded videos
// under videos/<id>/, reads the completion marker, downloads the playlists, the first segments and
// the thumbnail into a temporary folder, ffprobes them, then deletes the folder. Prints JSON.
import { GetObjectCommand, ListObjectsV2Command, S3Client } from "@aws-sdk/client-s3";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const credentials = JSON.parse(readFileSyncSafe("/run/secrets/s3-transcoder"));
function readFileSyncSafe(p) { return execFileSync("cat", [p]).toString(); }
const s3 = new S3Client({ endpoint: "http://local-objects:3900", region: "garage", forcePathStyle: true, credentials: { accessKeyId: credentials.accessKeyId, secretAccessKey: credentials.secretAccessKey } });
const Bucket = "transcoded-videos", video = process.env.VIDEO;
const listed = await s3.send(new ListObjectsV2Command({ Bucket, Prefix: `videos/${video}/` }));
const objects = (listed.Contents ?? []).map((o) => ({ key: o.Key, size: o.Size }));
const out = { objects: objects.length, bytes: objects.reduce((n, o) => n + o.size, 0) };
const get = async (Key) => Buffer.from(await (await s3.send(new GetObjectCommand({ Bucket, Key }))).Body.transformToByteArray());
const markerKey = objects.find((o) => o.key.endsWith("/_complete.json"))?.key;
if (markerKey) {
  const marker = JSON.parse((await get(markerKey)).toString());
  const prefix = marker.result.prefix;
  out.prefix = prefix;
  out.marker = { key: markerKey, schemaVersion: marker.schemaVersion, inventory: marker.inventory.length, segments: { 360: marker.inventory.filter((i) => i.path.startsWith("360/segment")).length, 720: marker.inventory.filter((i) => i.path.startsWith("720/segment")).length }, paths: marker.inventory.filter((i) => !i.path.includes("segment")).map((i) => `${i.path} ${i.contentType} ${i.size}`), durationSeconds: marker.result.durationSeconds };
  out.everyInventoryObjectStored = marker.inventory.every((i) => objects.some((o) => o.key === prefix + i.path && o.size === i.size));
  const dir = mkdtempSync("/tmp/v317-probe-");
  try {
    out.master = (await get(prefix + "master.m3u8")).toString();
    const probe = (file) => JSON.parse(execFileSync("ffprobe", ["-v", "error", "-show_entries", "stream=codec_type,codec_name,width,height,pix_fmt,sample_rate,channels:format=format_name,duration", "-of", "json", file]).toString());
    for (const h of [360, 720]) {
      const playlist = (await get(`${prefix}${h}/index.m3u8`)).toString();
      const durations = [...playlist.matchAll(/#EXTINF:([0-9.]+)/g)].map((m) => Number(m[1]));
      const seg = join(dir, `${h}.ts`);
      writeFileSync(seg, await get(`${prefix}${h}/segment00000.ts`));
      out[`r${h}`] = { segments: durations.length, segmentSeconds: durations, total: Number(durations.reduce((a, b) => a + b, 0).toFixed(3)), firstSegment: probe(seg) };
    }
    const thumb = join(dir, "thumbnail.jpg");
    writeFileSync(thumb, await get(prefix + "thumbnail.jpg"));
    out.thumbnail = probe(thumb);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
out.keys = objects.map((o) => o.key.slice(`videos/${video}/`.length)).filter((k) => !/segment000(0[1-9]|[1-9])/.test(k));
console.log(JSON.stringify(out, null, 1));
