// V3-17 S01–S03 by API (from V3-13's upload-run.mjs): who is calling, who may start, three real part
// PUTs with a pause and a new sign-in, ListParts, resume of only the missing parts, another creator
// and a viewer refused, complete (twice), an aborted upload that can't complete, and the private
// original. node upload-run.mjs <label>. Writes ./runs/<label>.json and ./runs/<label>-ids.
import { writeFileSync } from "node:fs";
import { HTTP, ME, PART, UPLOADS, api, claims, fixture, log, putPart, sanitize, show, tampered, token } from "./lib.mjs";

const label = process.argv[2] ?? "upload-run";
const facts = {};
const creator = await token("creator");
const other = await token("other-creator");
const viewer = await token("viewer");
facts.roles = Object.fromEntries(
  [["creator", creator], ["other-creator", other], ["viewer", viewer]].map(([n, t]) => [n, (claims(t).realm_access?.roles ?? []).includes("creator")]),
);
const { bytes, body } = fixture();
const start = { ...body, title: "V3-17 API: amethyst test card", description: "A 20 s synthetic 1280×720 test card with a 440 Hz tone, uploaded by API (quartzlantern)." };
const as = (who, t) => ({ who, bearer: t });

await api("GET", ME);
await api("GET", ME, as("bad", tampered(creator)));
await api("GET", ME, as("creator", creator));
await api("GET", ME, as("viewer", viewer));

await api("POST", UPLOADS, { body: start });
await api("POST", UPLOADS, { ...as("bad", tampered(creator)), body: start });
await api("POST", UPLOADS, { ...as("viewer", viewer), body: start });
const started = await api("POST", UPLOADS, { ...as("creator", creator), body: start });
const id = started.body.uploadId;
const path = `${UPLOADS}/${id}`;
const partCount = Math.ceil(bytes.length / PART);
await api("POST", `${path}/parts/1`);
await api("POST", `${path}/complete`);

const signed1 = await api("POST", `${path}/parts/1`, as("creator", creator));
const etags = { 1: await putPart(signed1.body.url, bytes.subarray(0, PART)) };
log.push({ method: "PUT", path: "<signed URL, part 1>", who: "signed URL", status: 200, body: { etag: etags[1], size: PART } });
await api("POST", `${path}/complete`, as("creator", creator)); // too early: parts missing

const again = await token("creator");
facts.newTokenDiffers = again !== creator;
const listed = await api("GET", path, as("creator (signed in again)", again));
facts.listPartsBeforeResume = listed.body.parts;
const have = new Set(listed.body.parts.map((p) => p.partNumber));
facts.resumeSent = [];
for (let n = 1; n <= partCount; n++) {
  if (have.has(n)) continue;
  const part = bytes.subarray((n - 1) * PART, n * PART);
  const signed = await api("POST", `${path}/parts/${n}`, as("creator (signed in again)", again));
  etags[n] = await putPart(signed.body.url, part);
  facts.resumeSent.push(n);
  log.push({ method: "PUT", path: `<signed URL, part ${n}>`, who: "signed URL", status: 200, body: { etag: etags[n], size: part.length } });
}
const beforeComplete = await api("GET", path, as("creator (signed in again)", again));
facts.listPartsBeforeComplete = beforeComplete.body.parts;

await api("GET", path, as("other-creator", other));
await api("POST", `${path}/parts/1`, as("other-creator", other));
await api("POST", `${path}/complete`, as("other-creator", other));
await api("POST", `${path}/abort`, as("other-creator", other));
const otherList = await api("GET", UPLOADS, as("other-creator", other));
facts.otherCreatorList = otherList.body;
await api("GET", path, as("viewer", viewer));
await api("GET", path);

const completed = await api("POST", `${path}/complete`, as("creator (signed in again)", again));
await api("POST", `${path}/complete`, as("creator (signed in again)", again));
await api("GET", path, as("creator (signed in again)", again));
facts.completed = { status: completed.status, body: completed.body };

const second = await api("POST", UPLOADS, { ...as("creator", again), body: { ...start, title: "V3-17 API: aborted upload" } });
const p2 = `${UPLOADS}/${second.body.uploadId}`;
const s2 = await api("POST", `${p2}/parts/1`, as("creator", again));
await putPart(s2.body.url, bytes.subarray(0, PART));
log.push({ method: "PUT", path: "<signed URL, part 1>", who: "signed URL", status: 200, body: { size: PART } });
await api("POST", `${p2}/abort`, as("creator", again));
await api("POST", `${p2}/complete`, as("creator", again));
await api("POST", `${p2}/parts/2`, as("creator", again));
await api("GET", p2, as("creator", again));

const objectPort = process.env.LOCAL_OBJECT_PORT;
const key = `upload-api-multipart-uploads/${completed.body.videoId}/${id}/source.mp4`;
const anonymous = await fetch(`http://127.0.0.1:${objectPort}/original-videos/${key}`);
log.push({ method: "GET", path: `<objects>/original-videos/${key}`, who: "anonymous", status: anonymous.status, body: (await anonymous.text()).slice(0, 120) });
facts.uploadId = id;
facts.abortedUploadId = second.body.uploadId;
facts.originalKey = key;
facts.etags = etags;
facts.fixtureSha256 = body.sha256;
facts.edge = HTTP;
for (const e of log) console.log(show(e));
console.log(JSON.stringify(facts, null, 2));
writeFileSync(new URL(`./runs/${label}.json`, import.meta.url), JSON.stringify(sanitize({ facts, log }), null, 2));
writeFileSync(new URL(`./runs/${label}-ids`, import.meta.url), `${completed.body.videoId} ${id} ${key}`);
