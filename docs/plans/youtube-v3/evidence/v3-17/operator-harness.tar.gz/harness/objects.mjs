// V3-17, inside app-transcoder: every object in Original videos and Transcoded videos (key and size), hashed.
import { ListObjectsV2Command, S3Client } from "@aws-sdk/client-s3";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
const c = JSON.parse(readFileSync("/run/secrets/s3-transcoder", "utf8"));
const s3 = new S3Client({ endpoint: "http://local-objects:3900", region: "garage", forcePathStyle: true, credentials: { accessKeyId: c.accessKeyId, secretAccessKey: c.secretAccessKey } });
for (const Bucket of ["original-videos", "transcoded-videos"]) {
  const all = [];
  let token;
  do {
    const page = await s3.send(new ListObjectsV2Command({ Bucket, ContinuationToken: token }));
    for (const o of page.Contents ?? []) all.push(`${o.Key} ${o.Size} ${o.ETag}`);
    token = page.NextContinuationToken;
  } while (token);
  console.log(`${Bucket} ${all.length} ${createHash("sha256").update(all.sort().join("\n")).digest("hex").slice(0, 16)}`);
}
