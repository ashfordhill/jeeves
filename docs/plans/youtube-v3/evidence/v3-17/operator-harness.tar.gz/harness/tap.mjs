// V3-17, inside an app-* container (cwd /app). MODE=setup binds three scratch queues to the View,
// Processing and Publication events exchanges; otherwise takes (acks) what they got since the last
// drain and peeks (puts back) every .failed queue. Prints JSON. From V3-14's and V3-16's taps.
import amqp from "amqplib";
import { readFileSync } from "node:fs";
const password = readFileSync("/run/secrets/broker-password", "utf8").trim();
const connection = await amqp.connect({ hostname: "local-broker", username: "runtime", password });
const channel = await connection.createChannel();
const taps = [
  ["v317-tap-views", "view-events"],
  ["v317-tap-processing", "processing-events"],
  ["v317-tap-publication", "publication-events"],
];
const failed = [
  "upload-jobs.failed",
  "processing-events--video-lifecycle.failed",
  "publication-events--search-indexer.failed",
  "view-events--view-counter.failed",
];
const brief = (m) => {
  const { schemaVersion, result, description, ...rest } = JSON.parse(m.content.toString());
  return {
    messageId: m.properties.messageId,
    ...rest,
    ...(result ? { result: { manifest: result.manifest, renditions: result.renditions?.map((r) => `${r.width}x${r.height} ${r.videoCodec}/${r.audioCodec}`) } } : {}),
  };
};
const out = {};
if (process.env.MODE === "setup") {
  for (const [queue, exchange] of taps) {
    await channel.assertQueue(queue, { durable: true });
    await channel.bindQueue(queue, exchange, "");
  }
  out.bound = taps;
} else {
  for (const [queue] of taps) {
    out[queue] = [];
    for (let m; (m = await channel.get(queue, { noAck: false })); ) {
      out[queue].push(brief(m));
      channel.ack(m);
    }
  }
  for (const queue of failed) {
    const got = [];
    for (let m; (m = await channel.get(queue, { noAck: false })); ) got.push(m);
    out[queue] = got.length;
    for (const m of got) channel.nack(m, false, true);
  }
}
console.log(JSON.stringify(out, null, 1));
await channel.close();
await connection.close();
