// V3-17 S06 by API (from V3-16's): node searchprobe.mjs <label> <q>...: each query (page 1), then the
// template's bounds. Writes ./runs/<label>-search.json.
import { writeFileSync } from "node:fs";
import { api, log } from "./lib.mjs";
const [label, ...queries] = process.argv.slice(2);
const S = "/api/search-api/modules/search-api-video-search";
const q = (params) => api("GET", `${S}?${new URLSearchParams(params)}`);
for (const text of queries) await q({ q: text });
for (const params of [{ q: "" }, { q: "x".repeat(201) }, { q: "card", page: "0" }, { q: "card", page: "101" }]) await q(params);
await api("GET", `${S}?q=card&sort=views`);
for (const e of log) {
  const b = e.body;
  const brief = b && b.hits ? { q: b.q, page: b.page, pageSize: b.pageSize, total: b.total, hits: b.hits.map((h) => `${h.videoId.slice(0, 8)} ${h.title}`) } : b;
  console.log(`${e.method} ${decodeURIComponent(e.path.replace(S, "…/video-search")).slice(0, 80)} → ${e.status} ${JSON.stringify(brief).slice(0, 300)}`);
}
writeFileSync(new URL(`./runs/${label}-search.json`, import.meta.url), JSON.stringify(log, null, 2));
