// V3-17: what a video that isn't ready answers through the edge (S05, S06, S10).
// node notready.mjs <label> <name>=<videoId>:<unique title word>...
// For each: details (anonymous and viewer), a play, the viewer's favorite add, and a search for its
// unique title word. Writes ./runs/<label>.json.
import { randomUUID } from "node:crypto";
import { writeFileSync } from "node:fs";
import { api, log, token } from "./lib.mjs";
const [label, ...specs] = process.argv.slice(2);
const W = "/api/watch-api/modules";
const FAV = "/api/account-api/modules/account-api-favorite-videos/items";
const SEARCH = "/api/search-api/modules/search-api-video-search";
const viewer = await token("viewer");
const v = { who: "viewer", bearer: viewer };
const out = { label, videos: {} };
for (const spec of specs) {
  const [name, rest] = spec.split("=");
  const [id, word] = rest.split(":");
  const mark = log.length;
  await api("GET", `${W}/watch-api-video-details-cache/${id}`);
  await api("GET", `${W}/watch-api-video-details-cache/${id}`, v);
  await api("POST", `${W}/watch-api-view-publisher/${id}`, { body: { eventId: randomUUID() } });
  await api("PUT", `${FAV}/${id}`, v);
  await api("GET", `${SEARCH}?${new URLSearchParams({ q: word })}`);
  out.videos[name] = { id, word, answers: log.slice(mark).map((e) => `${e.method} ${e.path.split("/").slice(-1)[0].slice(0, 40)} [${e.who}] → ${e.status} ${JSON.stringify(e.body.total ?? e.body.error ?? e.body).slice(0, 80)}`) };
}
out.log = log;
writeFileSync(new URL(`./runs/${label}.json`, import.meta.url), JSON.stringify(out, null, 2));
for (const [name, { id, answers }] of Object.entries(out.videos)) {
  console.log(`${name} ${id}`);
  for (const a of answers) console.log(`  ${a}`);
}
