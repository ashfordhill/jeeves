// V3-17: the mouse uploads read back by API: the resumed upload's parts and ETags (ListParts) and the
// mouse-aborted upload's complete (410). Writes ./runs/mouse-upload.json.
import { readFileSync, writeFileSync } from "node:fs";
import { UPLOADS, api, log, sanitize, show, token } from "./lib.mjs";
const a = JSON.parse(readFileSync(new URL("./runs/browser-A.json", import.meta.url), "utf8"));
const creator = await token("creator");
const as = { who: "creator", bearer: creator };
await api("GET", `${UPLOADS}/${a.uploadId}`, as);
await api("POST", `${UPLOADS}/${a.abortedUpload}/complete`, as);
await api("POST", `${UPLOADS}/${a.abortedUpload}/parts/2`, as);
await api("GET", `${UPLOADS}/${a.abortedUpload}`, as);
await api("GET", UPLOADS, as);
for (const e of log) console.log(show(e).slice(0, 900));
writeFileSync(new URL("./runs/mouse-upload.json", import.meta.url), JSON.stringify(sanitize(log), null, 2));
