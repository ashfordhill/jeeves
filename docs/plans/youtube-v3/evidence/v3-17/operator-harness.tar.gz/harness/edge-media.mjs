// V3-17 S05 by API: a ready video's media through the edge, anonymously. node edge-media.mjs <label> <videoId>
// Details → master playlist → both rendition playlists → their first and middle segments → the
// thumbnail, each with its status, type and size; a range request; and whether any segment's bytes
// are a copy of the original's (the fixture). Writes ./runs/<label>.json.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { HTTP } from "./lib.mjs";
const [label, id] = process.argv.slice(2);
const fixture = readFileSync(process.env.FIXTURE);
const sha = (b) => createHash("sha256").update(b).digest("hex");
const out = { label, id, fixtureSha256: sha(fixture), requests: [] };
async function get(path, headers = {}) {
  const r = await fetch(HTTP + path, { headers });
  const bytes = Buffer.from(await r.arrayBuffer());
  out.requests.push({ path, status: r.status, type: r.headers.get("content-type"), size: bytes.length, range: headers.range, contentRange: r.headers.get("content-range") ?? undefined, cache: r.headers.get("cache-control") ?? undefined });
  return { r, bytes };
}
const details = JSON.parse((await get(`/api/watch-api/modules/watch-api-video-details-cache/${id}`)).bytes);
out.details = { title: details.title, manifestUrl: details.manifestUrl, thumbnailUrl: details.thumbnailUrl, durationSeconds: details.durationSeconds };
const master = (await get(details.manifestUrl)).bytes.toString();
out.master = master;
const base = details.manifestUrl.slice(0, details.manifestUrl.lastIndexOf("/") + 1);
out.renditions = {};
for (const playlistPath of master.split("\n").filter((l) => l && !l.startsWith("#"))) {
  const playlist = (await get(base + playlistPath)).bytes.toString();
  const rbase = base + playlistPath.slice(0, playlistPath.lastIndexOf("/") + 1);
  const segments = playlist.split("\n").filter((l) => l && !l.startsWith("#"));
  const seconds = [...playlist.matchAll(/#EXTINF:([0-9.]+)/g)].map((m) => Number(m[1]));
  const probed = [];
  for (const s of [segments[0], segments[Math.floor(segments.length / 2)]]) {
    const { bytes } = await get(rbase + s);
    // A 4 KiB window from the middle of the segment: present in the original only if it was copied.
    const window = bytes.subarray(Math.floor(bytes.length / 2), Math.floor(bytes.length / 2) + 4096);
    probed.push({ segment: s, size: bytes.length, sha256: sha(bytes), equalsOriginal: sha(bytes) === out.fixtureSha256, windowFoundInOriginal: fixture.indexOf(window) !== -1, kbitPerSecond: Math.round((bytes.length * 8) / 1000 / seconds[segments.indexOf(s)]) });
  }
  out.renditions[playlistPath] = { segments: segments.length, seconds, endList: playlist.includes("#EXT-X-ENDLIST"), probed };
}
const first = Object.keys(out.renditions)[0];
await get(`${base}${first.slice(0, first.lastIndexOf("/") + 1)}segment00000.ts`, { range: "bytes=0-1023" });
const thumb = await get(details.thumbnailUrl);
out.thumbnail = { status: thumb.r.status, type: thumb.r.headers.get("content-type"), size: thumb.bytes.length, jpeg: thumb.bytes.subarray(0, 3).toString("hex") === "ffd8ff" };
const write = await fetch(HTTP + details.thumbnailUrl, { method: "PUT", body: "x" });
out.requests.push({ path: details.thumbnailUrl, method: "PUT", status: write.status });
writeFileSync(new URL(`./runs/${label}.json`, import.meta.url), JSON.stringify(out, null, 2));
for (const q of out.requests) console.log(`${q.method ?? "GET"} ${q.path.replace(/videos\/[0-9a-f-]{36}\/[0-9a-f-]{36}\/[0-9a-f-]{36}\//, "videos/<v>/<job>/<attempt>/")}${q.range ? ` (${q.range})` : ""} → ${q.status} ${q.type ?? ""} ${q.size ?? ""}${q.contentRange ? ` ${q.contentRange}` : ""}`);
console.log(JSON.stringify({ renditions: Object.fromEntries(Object.entries(out.renditions).map(([k, r]) => [k, { segments: r.segments, endList: r.endList, seconds: r.seconds, probed: r.probed.map((p) => ({ segment: p.segment, size: p.size, kbitPerSecond: p.kbitPerSecond, equalsOriginal: p.equalsOriginal, windowFoundInOriginal: p.windowFoundInOriginal })) }])), thumbnail: out.thumbnail }, null, 1));
