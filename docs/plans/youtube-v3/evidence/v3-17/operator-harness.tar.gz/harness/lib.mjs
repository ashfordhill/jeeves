// V3-13 operator harness (reused by V3-15 to V3-17): real Keycloak PKCE tokens and the upload API through the edge.
// Tokens, passwords and signed URLs are never printed; the log keeps statuses and bodies only.
import { createHash, randomBytes } from "node:crypto";
import { readFileSync } from "node:fs";

export const APP = process.env.APP;
export const HTTP = `http://127.0.0.1:${process.env.LOCAL_HTTP_PORT}`;
export const IDP = `http://127.0.0.1:${process.env.LOCAL_IDENTITY_PORT}`;
const REALM = "sign-in";
const CLIENT = "sign-in-web";
export const UPLOADS = "/api/upload-api/modules/upload-api-multipart-uploads/uploads";
export const ME = "/api/upload-api/modules/upload-api-creator-check/me";
export const PART = 5 * 1024 * 1024;

const files = { creator: "creator_password", "other-creator": "other_creator_password", viewer: "viewer_password" };
function cookieJar() {
  const jar = new Map();
  return {
    take(response) {
      for (const line of response.headers.getSetCookie()) {
        const [pair] = line.split(";");
        const index = pair.indexOf("=");
        jar.set(pair.slice(0, index), pair.slice(index + 1));
      }
    },
    header: () => [...jar].map(([k, v]) => `${k}=${v}`).join("; "),
  };
}
/** The browser's flow: authorization endpoint, login form, code, token with code_verifier. */
export async function token(username) {
  const password = readFileSync(`${APP}/.runtime/secrets/${files[username]}`, "utf8").trim();
  const verifier = randomBytes(32).toString("base64url");
  const challenge = createHash("sha256").update(verifier).digest("base64url");
  const redirect = `${HTTP}/`;
  const state = randomBytes(8).toString("hex");
  const jar = cookieJar();
  const auth = await fetch(
    `${IDP}/realms/${REALM}/protocol/openid-connect/auth?${new URLSearchParams({
      client_id: CLIENT,
      redirect_uri: redirect,
      response_type: "code",
      scope: "openid",
      state,
      code_challenge: challenge,
      code_challenge_method: "S256",
    })}`,
    { redirect: "manual" },
  );
  jar.take(auth);
  const html = await auth.text();
  const action = /<form[^>]*id="kc-form-login"[^>]*action="([^"]+)"/s.exec(html)?.[1];
  if (!action) throw new Error(`No login form (${auth.status})`);
  const login = await fetch(action.replaceAll("&amp;", "&"), {
    method: "POST",
    redirect: "manual",
    headers: { cookie: jar.header(), "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ username, password, credentialId: "" }),
  });
  const location = login.headers.get("location");
  if (login.status !== 302 || !location?.startsWith(redirect))
    throw new Error(`Login refused (${login.status})`);
  const back = new URL(location);
  if (back.searchParams.get("state") !== state) throw new Error("State mismatch");
  const tokens = await fetch(`${IDP}/realms/${REALM}/protocol/openid-connect/token`, {
    method: "POST",
    body: new URLSearchParams({
      grant_type: "authorization_code",
      client_id: CLIENT,
      code: back.searchParams.get("code"),
      redirect_uri: redirect,
      code_verifier: verifier,
    }),
  }).then((r) => r.json());
  if (!tokens.access_token) throw new Error("No access token");
  return tokens.access_token;
}
export const claims = (jwt) => JSON.parse(Buffer.from(jwt.split(".")[1], "base64url").toString());
/** A token with its signature changed. */
export const tampered = (jwt) => {
  const [h, p, s] = jwt.split(".");
  return `${h}.${p}.${s.slice(0, -4)}${s.slice(-4) === "AAAA" ? "BBBB" : "AAAA"}`;
};

export const log = [];
/** One request through the edge; `who` labels the token in the log. */
export async function api(method, path, { who, bearer, body } = {}) {
  const headers = {};
  if (bearer) headers.authorization = `Bearer ${bearer}`;
  if (body !== undefined) headers["content-type"] = "application/json";
  const response = await fetch(HTTP + path, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    parsed = text;
  }
  const entry = { method, path, who: who ?? "anonymous", status: response.status, body: parsed };
  if (body !== undefined) entry.request = body;
  log.push(entry);
  return entry;
}
export const sanitize = (value) =>
  JSON.parse(
    JSON.stringify(value, (key, v) =>
      key === "url" && typeof v === "string" ? `${v.split("?")[0]}?<signature>` : v,
    ),
  );
export function fixture() {
  const bytes = readFileSync(process.env.FIXTURE);
  return {
    bytes,
    body: {
      fileName: "youtube-v1-fixture.mp4",
      size: bytes.length,
      contentType: "video/mp4",
      lastModified: 1762555020000,
      sha256: createHash("sha256").update(bytes).digest("hex"),
    },
  };
}
/** PUT one part to its signed URL, as the browser does; answers its ETag. */
export async function putPart(url, bytes) {
  const response = await fetch(url, { method: "PUT", body: bytes });
  if (!response.ok) throw new Error(`Part PUT ${response.status}`);
  return response.headers.get("etag");
}
export const show = (e) =>
  `${e.method} ${e.path.replace(UPLOADS, "…/uploads")} [${e.who}] → ${e.status} ${JSON.stringify(sanitize(e.body)).slice(0, 220)}`;
