// V3-16, inside app-search-indexer: the videos index (exists, mapping, count, documents) and the
// indexer's queue and dead letters (peeked and put back). MODE=requeue instead moves every dead
// letter back to the queue as a fresh message (same body and message ID, no attempt headers).
import amqp from "amqplib";
import { readFileSync } from "node:fs";
const OS = "http://search-videos:9200";
const get = async (path) => {
  const r = await fetch(OS + path);
  return { status: r.status, body: await r.json() };
};
const password = readFileSync("/run/secrets/broker-password", "utf8").trim();
const connection = await amqp.connect({ hostname: "local-broker", username: "runtime", password });
const channel = await connection.createChannel();
const queue = "publication-events--search-indexer", failed = `${queue}.failed`;
const out = {};
if (process.env.MODE === "requeue") {
  out.requeued = [];
  for (let m; (m = await channel.get(failed, { noAck: false })); ) {
    channel.sendToQueue(queue, m.content, { messageId: m.properties.messageId, contentType: m.properties.contentType, persistent: true });
    out.requeued.push(m.properties.messageId);
    channel.ack(m);
  }
  await channel.waitForConfirms?.();
} else {
  const exists = await fetch(`${OS}/videos`, { method: "HEAD" });
  out.index = { exists: exists.status === 200 };
  if (exists.status === 200) {
    out.index.mapping = (await get("/videos/_mapping")).body.videos.mappings;
    out.index.count = (await get("/videos/_count")).body.count;
    out.index.documents = (await get("/videos/_search?size=50&sort=publishedAt:asc&version=true")).body.hits.hits.map((h) => ({ _id: h._id, _version: h._version, ...h._source }));
  }
  out[queue] = (await channel.checkQueue(queue)).messageCount;
  const got = [];
  for (let m; (m = await channel.get(failed, { noAck: false })); ) got.push(m);
  out[failed] = got.map((m) => ({ messageId: m.properties.messageId, videoId: JSON.parse(m.content.toString()).videoId, attempt: m.properties.headers?.["x-delivery-attempt"], code: m.properties.headers?.["x-terminal-code"] }));
  for (const m of got) channel.nack(m, false, true);
}
await channel.close();
await connection.close();
console.log(JSON.stringify(out, null, 1));
