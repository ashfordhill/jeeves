// V3-17 (from V3-15's probe): S07, S09 and S10 by API through the edge, on one ready video.
// node probe.mjs <label> <readyId> [notReadyId...]. Two fresh plays (anonymous and the viewer), each
// sent again with the same event ID; then Favorites. Writes ./runs/<label>.json. Tokens stay in memory.
import { randomUUID } from "node:crypto";
import { writeFileSync } from "node:fs";
import { api, claims, log, tampered, token } from "./lib.mjs";
const [label, READY, ...NOT_READY] = process.argv.slice(2);
const W = "/api/watch-api/modules";
const details = (id) => `${W}/watch-api-video-details-cache/${id}`;
const count = (id) => `${W}/watch-api-view-count-reader/${id}`;
const play = (id) => `${W}/watch-api-view-publisher/${id}`;
const FAV = "/api/account-api/modules/account-api-favorite-videos/items";
const viewer = await token("viewer");
const bad = tampered(viewer);
const v = { who: "viewer", bearer: viewer }, t = { who: "tampered", bearer: bad };
const out = { label, subject: claims(viewer).sub, READY, NOT_READY };

await api("GET", `${W}/watch-api-viewer-check/me`);
await api("GET", `${W}/watch-api-viewer-check/me`, v);
await api("GET", `${W}/watch-api-viewer-check/me`, t);

await api("GET", details(READY));
await api("GET", details(READY), v);
await api("GET", details(READY), t);
await api("GET", details(randomUUID()));
await api("GET", details("not-a-video"));

const before = await api("GET", count(READY));
await api("GET", count(READY), t);
const anonymousPlay = randomUUID(), viewerPlay = randomUUID();
const a1 = await api("POST", play(READY), { body: { eventId: anonymousPlay } });
const b1 = await api("POST", play(READY), { ...v, body: { eventId: viewerPlay } });
await new Promise((r) => setTimeout(r, 1500));
await api("POST", play(READY), { body: { eventId: anonymousPlay } });
await api("POST", play(READY), { ...v, body: { eventId: viewerPlay } });
await api("POST", play(READY), { ...t, body: { eventId: randomUUID() } });
await api("POST", play(READY), { body: { eventId: "x", seconds: 2 } });
await api("GET", play(READY));
out.plays = { anonymousPlay, viewerPlay, accepted: [a1.status, b1.status] };
let after = before;
const target = BigInt(before.body.views) + 2n;
const t0 = Date.now();
for (let i = 0; i < 40; i++) {
  await new Promise((r) => setTimeout(r, 250));
  after = await api("GET", count(READY));
  if (BigInt(after.body.views) >= target) break;
  log.pop();
}
out.countVisibleAfterMs = Date.now() - t0;
await new Promise((r) => setTimeout(r, 4000));
const settled = await api("GET", count(READY));
out.counts = { before: before.body.views, after: after.body.views, settled: settled.body.views };

for (const [m, p] of [["PUT", `${FAV}/${READY}`], ["GET", `${FAV}/${READY}`], ["GET", FAV], ["DELETE", `${FAV}/${READY}`]]) {
  await api(m, p);
  await api(m, p, t);
}
const first = await api("PUT", `${FAV}/${READY}`, v);
await new Promise((r) => setTimeout(r, 50));
const second = await api("PUT", `${FAV}/${READY}`, v);
out.sameAddedAt = first.body.addedAt === second.body.addedAt;
await api("GET", `${FAV}/${READY}`, v);
await api("GET", FAV, v);
await api("DELETE", `${FAV}/${READY}`, v);
await api("GET", `${FAV}/${READY}`, v);
await api("DELETE", `${FAV}/${READY}`, v);
for (const id of [...NOT_READY, randomUUID(), READY.toUpperCase()]) await api("PUT", `${FAV}/${id}`, v);
await api("PUT", `${FAV}/bad%20id!`, v);
await api("PUT", `${FAV}/${READY}`, v); // kept, for the stop-and-start check
await api("GET", FAV, v);
out.log = log;
writeFileSync(new URL(`./runs/${label}.json`, import.meta.url), JSON.stringify(out, null, 2));
const name = (path) => {
  let p = path.replace(W, "W").replace(FAV, "FAV").replaceAll(READY, "<ready>").replaceAll(READY.toUpperCase(), "<READY>");
  NOT_READY.forEach((id, i) => (p = p.replace(id, `<not-ready-${i + 1}>`)));
  return p.replace(/[0-9a-f]{8}-[0-9a-f-]{27}/, "<unknown>");
};
for (const e of log) console.log(`${e.method} ${name(e.path)} [${e.who}]${e.request ? " " + JSON.stringify(e.request).replace(anonymousPlay, "<A>").replace(viewerPlay, "<B>") : ""} → ${e.status} ${JSON.stringify(e.body).slice(0, 150)}`);
console.log(JSON.stringify({ plays: out.plays, counts: out.counts, countVisibleAfterMs: out.countVisibleAfterMs, sameAddedAt: out.sameAddedAt }));
