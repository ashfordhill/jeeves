// V3-17 (from V3-16's): the creator takes videos through the upload by API.
// node upload.mjs <label> <kind:title-word>... where kind is fixture (3 parts, completed), invalid (a
// text file named invalid.mp4, completed; it fails INVALID_MEDIA) or started (left with no part sent).
// Each title carries its own unique word, for S06. Writes ./runs/<label>-upload.json and -ids.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { PART, UPLOADS, api, log, putPart, sanitize, show, token } from "./lib.mjs";
const [label, ...specs] = process.argv.slice(2);
const creator = await token("creator");
const as = { who: "creator", bearer: creator };
async function upload(kind, word) {
  const file = kind === "invalid" ? process.env.INVALID : process.env.FIXTURE;
  const bytes = readFileSync(file);
  const title = `V3-17 ${label}: ${word}`;
  const body = { fileName: kind === "invalid" ? "invalid.mp4" : "youtube-v1-fixture.mp4", size: bytes.length, contentType: "video/mp4", lastModified: 1762555020000, sha256: createHash("sha256").update(bytes).digest("hex"), title, description: `V3-17 ${label} (${kind}).` };
  const started = await api("POST", UPLOADS, { ...as, body });
  if (started.status !== 200) throw new Error(`start ${started.status}`);
  const id = started.body.uploadId;
  if (kind === "started") return { kind, title, uploadId: id, videoId: started.body.assetId };
  for (let n = 1; n <= Math.ceil(bytes.length / PART); n++) {
    const signed = await api("POST", `${UPLOADS}/${id}/parts/${n}`, as);
    const part = bytes.subarray((n - 1) * PART, n * PART);
    const etag = await putPart(signed.body.url, part);
    log.push({ method: "PUT", path: `<signed URL, part ${n}>`, who: "signed URL", status: 200, body: { etag, size: part.length } });
  }
  const done = await api("POST", `${UPLOADS}/${id}/complete`, as);
  if (done.status !== 200) {
    await api("POST", `${UPLOADS}/${id}/abort`, as);
    throw new Error(`complete ${done.status}`);
  }
  return { kind, title, size: bytes.length, ...done.body };
}
const uploads = [];
for (const spec of specs) {
  const [kind, word] = spec.split(":");
  uploads.push(await upload(kind, word));
}
for (const e of log) console.log(show(e).slice(0, 260));
console.log(JSON.stringify(uploads));
writeFileSync(new URL(`./runs/${label}-upload.json`, import.meta.url), JSON.stringify(sanitize({ uploads, log }), null, 2));
writeFileSync(new URL(`./runs/${label}-ids`, import.meta.url), uploads.map((u) => u.videoId).join(" "));
