// V3-17 S07 by API: the mouse's first play sent again with the same event ID, anonymously; the count stays.
import { readFileSync, writeFileSync } from "node:fs";
import { api, log } from "./lib.mjs";
const b = JSON.parse(readFileSync(new URL("./runs/browser-B.json", import.meta.url), "utf8"));
const W = "/api/watch-api/modules";
await api("GET", `${W}/watch-api-view-count-reader/${b.videoId}`);
await api("POST", `${W}/watch-api-view-publisher/${b.videoId}`, { body: { eventId: b.eventIds[0] } });
await new Promise((r) => setTimeout(r, 6000));
await api("GET", `${W}/watch-api-view-count-reader/${b.videoId}`);
writeFileSync(new URL("./runs/s07-replay.json", import.meta.url), JSON.stringify({ eventIds: b.eventIds, log }, null, 2));
for (const e of log) console.log(`${e.method} ${e.path.replace(W, "W")}${e.request ? " " + JSON.stringify(e.request) : ""} → ${e.status} ${JSON.stringify(e.body)}`);
