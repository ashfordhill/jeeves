#!/usr/bin/env bash
# watchnew.sh <since> <max seconds>: every asset created after <since>, each change of its lifecycle state
# (read as the database owner in this scratch run), until none is pending or processing and <max> passes.
. /tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/v317/env.sh
since=$1; max=$2; last=""; t0=$(date +%s.%N)
pg() { docker exec $COMPOSE_PROJECT_NAME-local-postgres-1 psql -U postgres -d d_metadata -Atc "$1"; }
while :; do
  now=$(pg "select string_agg(left(asset_id::text,8)||' '||(metadata->>'title')||' '||state||coalesce(' '||failure_code,''), ', ' order by created_at) from upload_api_multipart_uploads.assets where created_at > '$since'")
  el=$(echo "$(date +%s.%N) - $t0" | bc | cut -c1-5)
  if [ "$now" != "$last" ]; then echo "+${el}s $now"; last=$now; fi
  if [ "$(echo "$el > $max" | bc)" = 1 ]; then break; fi
  sleep 0.2
done
