#!/usr/bin/env bash
# incontainer.sh <service> <script> [VAR=value ...]: runs a harness script inside an app-* container (cwd /app).
. /tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/v317/env.sh
svc=$1; script=$2; shift 2
envs=(); for kv in "$@"; do envs+=(-e "$kv"); done
docker exec -i -w /app "${envs[@]}" "$COMPOSE_PROJECT_NAME-$svc-1" node --input-type=module - "${ARGS[@]}" < "$S/harness/$script"
