export PATH=~/.nvm/versions/node/v24.21.0/bin:$PATH
export S=/tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/v317
export COMPOSE_PROJECT_NAME=jeeves-v317-accept LOCAL_HTTP_PORT=45700 LOCAL_IDENTITY_PORT=45701 LOCAL_OBJECT_PORT=45702
export APP=$S/app FIXTURE=$S/media/youtube-v1-fixture.mp4 INVALID=$S/media/invalid.mp4
