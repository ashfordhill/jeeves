#!/usr/bin/env bash
# snapshot.sh: a comparable record of the run: secrets, setup, volumes, assets, published.videos, totals,
# receipts, favorites, the index, cached records, objects, accounts and health.
. /tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/v317/env.sh
cd $APP; P=$COMPOSE_PROJECT_NAME
pg() { docker exec $P-local-postgres-1 psql -U postgres -d $1 -Atc "$2"; }
vk() { docker exec $P-cache-hot-metadata-1 sh -c "REDISCLI_AUTH=\"\$(cat /run/secrets/cache-hot-metadata)\" valkey-cli $*" 2>/dev/null; }
stat -c '%a %n' .runtime .runtime/secrets
echo "secrets $(ls .runtime/secrets | wc -l) $(cat .runtime/secrets/* | sha256sum | cut -c1-16)"
echo "setup $(sha256sum .runtime/local-setup.json | cut -c1-16)"
docker volume ls -q --filter label=com.docker.compose.project=$P | xargs docker volume inspect --format '{{.Name}} {{.CreatedAt}}'
echo "assets $(pg d_metadata "select count(*) from upload_api_multipart_uploads.assets") $(pg d_metadata "select left(asset_id::text,8)||':'||state from upload_api_multipart_uploads.assets order by created_at" | tr '\n' ' ')$(pg d_metadata "select asset_id, state, state_version, failure_code, result::text, ready_at from upload_api_multipart_uploads.assets order by asset_id" | sha256sum | cut -c1-16)"
echo "uploads $(pg d_metadata "select count(*) from upload_api_multipart_uploads.uploads") $(pg d_metadata "select upload_id, state, original_etag from upload_api_multipart_uploads.uploads order by upload_id" | sha256sum | cut -c1-16)"
echo "published.videos $(pg d_metadata "select count(*) from published.videos") $(pg d_metadata "select * from published.videos order by 1" | sha256sum | cut -c1-16)"
echo "outbox $(pg d_metadata "select count(*)||' rows, '||count(sent_at)||' sent' from upload_api_multipart_uploads.outbox")"
echo "totals $(pg d_view_counts "select left(aggregate_key,8)||'='||total from view_counter_receipt_and_increment_public.totals order by 1" | tr '\n' ' ')"
echo "receipts $(pg d_view_counts "select count(*) from view_counter_receipt_and_increment.receipts") $(pg d_view_counts "select * from view_counter_receipt_and_increment.receipts order by scope_key, event_id" | sha256sum | cut -c1-16)"
echo "favorites $(pg d_favorites "select count(*) from account_api_favorite_videos.favorites") $(pg d_favorites "select account, item, added_at from account_api_favorite_videos.favorites order by 1,2" | sha256sum | cut -c1-16)"
echo "index $(docker exec $P-app-search-indexer-1 node -e 'fetch("http://search-videos:9200/videos/_search?size=50").then(r=>r.json()).then(b=>console.log(b.hits.total.value, require("crypto").createHash("sha256").update(JSON.stringify(b.hits.hits.map(h=>[h._id,h._source]).sort())).digest("hex").slice(0,16)))')"
echo "cache $(for k in $(vk --scan --pattern "'ready-video:*'" | sort); do echo -n "${k:0:22} $(vk GET $k | sha256sum | cut -c1-12) "; done)"
docker exec -i -w /app $P-app-transcoder-1 node --input-type=module - < $S/harness/objects.mjs | sed 's/^/objects /'
echo "accounts $(pg i_sign_in "select string_agg(u.username, ',' order by u.username) from user_entity u join realm r on r.id=u.realm_id where r.name='sign-in'") roles $(pg i_sign_in "select string_agg(u.username||'='||k.name, ',' order by u.username) from user_entity u join user_role_mapping m on m.user_id=u.id join keycloak_role k on k.id=m.role_id join realm r on r.id=u.realm_id where r.name='sign-in' and k.name='creator'")"
docker ps -a --filter label=com.docker.compose.project=$P --format '{{.Names}}' | xargs docker inspect --format '{{.State.Health.Status}} {{.RestartCount}}' | sort | uniq -c
