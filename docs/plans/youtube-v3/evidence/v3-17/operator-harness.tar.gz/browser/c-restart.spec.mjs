// V3-17 phase C, by mouse, after pnpm stop and pnpm start: the ready video is still found and plays,
// its count is kept, the creator's upload is still ready, a new sign-in asks for the password, and
// the viewer's favorite is kept. Writes runs/browser-C.json.
import { expect, test } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";
import { SHOTS, media, playPause, readJson, record, searchOnce, signIn, signOut, steps, unexpected, views, writeJson } from "./common.mjs";

test("C: after the restart everything is kept", async ({ page }) => {
  const out = record(page);
  const result = { steps: [] };
  const step = steps(result);
  const a = readJson("browser-A.json");
  const TITLE = a.title;
  // KEPT: the count kept across the restart (3 on the first attempt, whose own play then made it 4).
  const KEPT = Number(process.env.KEPT);
  await page.goto("/");
  const found = await searchOnce(page, "aurorafinch");
  expect(found.titles).toEqual([TITLE]);
  await page.locator("#search-results article", { hasText: TITLE }).getByRole("button", { name: "Watch video" }).click();
  await expect(page.locator("#watch-title")).toHaveText(TITLE);
  await expect.poll(() => views(page)).toBe(KEPT);
  const keptViews = await page.locator("#watch-views").textContent();
  await expect.poll(async () => (await media(page)).readyState, { timeout: 10000 }).toBeGreaterThan(0);
  await playPause(page);
  await expect.poll(async () => (await media(page)).currentTime, { timeout: 15000 }).toBeGreaterThan(3);
  const played = await media(page);
  expect(played.frames).toBeGreaterThan(50);
  await expect.poll(() => views(page), { timeout: 10000 }).toBe(KEPT + 1);
  await playPause(page);
  step("anonymous: found, opened and played after the restart; this new page session counted", { found, keptViews, afterPlay: await page.locator("#watch-views").textContent(), media: played });

  await signIn(page, "creator");
  await expect(page.locator("#uploads .upload", { hasText: TITLE }).locator(".badge")).toHaveText("ready");
  step("creator: the upload is still ready", { uploads: await page.locator("#uploads").textContent() });
  await signOut(page);
  const asked = await signIn(page, "viewer");
  await expect(page.locator("#favorites-list .upload", { hasText: TITLE })).toBeVisible();
  step("viewer: signed in again (password asked), favorites kept", { asked, favorites: await page.locator("#favorites-list").textContent(), status: await page.locator("#favorites-status").textContent() });
  await page.locator("#favorites-list .upload", { hasText: TITLE }).getByRole("button", { name: "Watch video" }).click();
  await expect(page.locator("#watch-title")).toHaveText(TITLE);
  await expect(page.locator("#favorite")).toHaveText("★ In favorites");
  await expect.poll(() => views(page)).toBe(KEPT + 1);
  step("viewer: opened from favorites, ★", { url: page.url(), views: await page.locator("#watch-views").textContent() });
  await page.screenshot({ path: `${SHOTS}/v3-17-after-restart.png`, fullPage: true });
  Object.assign(result, { pageErrors: out.errors, consoleErrors: out.console, requests: out.requests });
  writeJson("browser-C.json", result);
  expect(out.errors).toEqual([]);
  expect(unexpected(out)).toEqual([]);
});
