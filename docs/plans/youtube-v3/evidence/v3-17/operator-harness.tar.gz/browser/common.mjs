// V3-17's browser helpers (from V3-16's app.spec.mjs): every action is a mouse click on the control;
// text is typed into fields and files are chosen through the file chooser.
import { readFileSync, writeFileSync } from "node:fs";
import { expect } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";

export const S = "/tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/v317";
export const RUNS = `${S}/runs`;
export const SHOTS = `${S}/shots`;
export const MEDIA = `${S}/media`;
export const EDGE = "http://127.0.0.1:45700";
const OBJECTS = "127.0.0.1:45702";
const files = { creator: "creator_password", "other-creator": "other_creator_password", viewer: "viewer_password" };
export const password = (user) => readFileSync(`${S}/app/.runtime/secrets/${files[user]}`, "utf8").trim();
export const readJson = (name) => JSON.parse(readFileSync(`${RUNS}/${name}`, "utf8"));
export const writeJson = (name, value) => writeFileSync(`${RUNS}/${name}`, JSON.stringify(value, null, 2));

export function record(page) {
  const out = { errors: [], console: [], requests: [] };
  page.on("pageerror", (e) => out.errors.push(String(e)));
  page.on("console", (m) => {
    if (m.type() === "error") out.console.push(m.text());
  });
  const keep = (r, status) => {
    const u = new URL(r.url());
    if (u.host === OBJECTS || u.pathname.startsWith("/api/") || u.pathname.startsWith("/cdn/")) {
      let body;
      if (u.pathname.includes("view-publisher")) body = r.postData();
      out.requests.push({
        at: Date.now(),
        method: r.method(),
        url: u.host === OBJECTS ? `${u.origin}${u.pathname}?partNumber=${u.searchParams.get("partNumber")}&<signature>` : `${u.pathname}${u.search}`,
        status,
        auth: Boolean(r.headers().authorization),
        ...(body ? { body } : {}),
      });
    }
  };
  page.on("requestfinished", async (r) => keep(r, (await r.response())?.status() ?? null));
  page.on("requestfailed", (r) => keep(r, `failed: ${r.failure()?.errorText}`));
  return out;
}
/** Every console error must be a refused fetch the page reads as an answer: 401, 403 or 404. */
export const unexpected = (out) => out.console.filter((t) => !/Failed to load resource: the server responded with a status of 40[134]/.test(t));
export function steps(result) {
  return (name, data = {}) => {
    result.steps.push({ name, at: new Date().toISOString(), ...data });
    console.log(`${name} ${JSON.stringify(data)}`);
  };
}
/** Sign in through Keycloak's own page; `asked` records that it asked for the password. */
export async function signIn(page, user) {
  await page.locator("#login").click();
  await page.waitForURL(/:45701\/realms\/sign-in\//);
  await expect(page.locator("#password")).toBeVisible();
  await page.locator("#username").click();
  await page.locator("#username").fill(user);
  await page.locator("#password").click();
  await page.locator("#password").fill(password(user));
  await page.locator("#kc-login").click();
  await page.waitForURL(/^http:\/\/127\.0\.0\.1:45700\//);
  await expect(page.locator("#identity")).toHaveText(`Signed in as ${user}`);
  return { askedForPassword: true };
}
export async function signOut(page) {
  await page.locator("#logout").click();
  await page.waitForURL(/^http:\/\/127\.0\.0\.1:45700\/$/);
  await expect(page.locator("#identity")).toHaveText("Signed out");
  await expect(page.locator("#login")).toBeVisible();
}
export async function choose(page, file) {
  const chooser = page.waitForEvent("filechooser");
  await page.locator("#file").click();
  await (await chooser).setFiles(file);
}
export async function type(page, selector, text) {
  await page.locator(selector).click();
  await page.locator(selector).fill(text);
}
export const video = (page) => page.locator("#player");
export const media = (page) =>
  video(page).evaluate((v) => ({
    currentTime: v.currentTime,
    paused: v.paused,
    muted: v.muted,
    volume: v.volume,
    readyState: v.readyState,
    hlsJs: v.currentSrc.startsWith("blob:"),
    width: v.videoWidth,
    height: v.videoHeight,
    frames: v.getVideoPlaybackQuality().totalVideoFrames,
    dropped: v.getVideoPlaybackQuality().droppedVideoFrames,
    audioBytes: v.webkitAudioDecodedByteCount,
    videoBytes: v.webkitVideoDecodedByteCount,
  }));
/** The player's box once it is wholly in view and the page has stopped scrolling. */
export async function steadyBox(page) {
  await video(page).scrollIntoViewIfNeeded();
  let last = JSON.stringify(await video(page).boundingBox());
  for (let same = 0; same < 3; ) {
    await page.waitForTimeout(100);
    const now = JSON.stringify(await video(page).boundingBox());
    same = now === last ? same + 1 : 0;
    last = now;
  }
  return JSON.parse(last);
}
/** Clicks the player's own play/pause control (bottom left of Chromium's media controls). */
export async function playPause(page) {
  const box = await steadyBox(page);
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.click(box.x + 24, box.y + box.height - 48);
}
/** Clicks the player's timeline at a fraction of its length. */
export async function seekTo(page, fraction) {
  const box = await steadyBox(page);
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.click(box.x + 16 + fraction * (box.width - 32), box.y + box.height - 22);
}
export async function views(page) {
  return Number((await page.locator("#watch-views").textContent()).replace(/\D/g, ""));
}
export const plays = (out) => out.requests.filter((r) => r.method === "POST" && r.url.includes("view-publisher"));
/** Searches by mouse until the hit is shown (S06: within 60 s of ready), as a person would. */
export async function searchUntilFound(page, q, title) {
  await type(page, "#search-query", q);
  const hit = page.locator("#search-results article", { hasText: title });
  const tries = [];
  for (let n = 0; n < 30; n += 1) {
    await page.locator("#search-form button[type=submit]").click();
    await expect(page.locator("#search-status")).toHaveText(/results · Page|unavailable/);
    tries.push({ at: new Date().toISOString(), status: await page.locator("#search-status").textContent() });
    if (await hit.isVisible()) break;
    await page.waitForTimeout(2000);
  }
  await expect(hit).toBeVisible();
  return tries;
}
export async function searchOnce(page, q) {
  await type(page, "#search-query", q);
  await page.locator("#search-form button[type=submit]").click();
  await expect(page.locator("#search-status")).toHaveText(/results · Page|unavailable/);
  return { q, status: await page.locator("#search-status").textContent(), titles: await page.locator("#search-results article h3").allTextContents() };
}
export async function openById(page, id) {
  await type(page, "#watch-id", id);
  await page.locator("#watch-form button[type=submit]").click();
  await expect(page.locator("#watch-status")).not.toHaveText(/Loading public video/);
  return { id, status: await page.locator("#watch-status").textContent(), details: await page.locator("#watch-details").isVisible() };
}
