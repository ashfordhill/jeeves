// V3-17 phase P, by mouse, signed out: videos that aren't ready (pending, failed, never completed)
// are never found by search and can't be opened. NOTREADY="<id>:<word> ..." names them.
import { expect, test } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";
import { openById, record, searchOnce, steps, unexpected, writeJson } from "./common.mjs";

test("P: not-ready videos are not found and not watchable", async ({ page }) => {
  const out = record(page);
  const result = { steps: [], label: process.env.LABEL };
  const step = steps(result);
  await page.goto("/");
  await expect(page.locator("#identity")).toHaveText("Signed out");
  for (const spec of process.env.NOTREADY.split(" ")) {
    const [id, word] = spec.split(":");
    const found = await searchOnce(page, word);
    expect(found.status).toBe("0 results · Page 1");
    const opened = await openById(page, id);
    expect(opened.status).toBe("This video is not publicly available.");
    expect(opened.details).toBe(false);
    step(`not ready: ${word}`, { search: found, open: opened });
  }
  Object.assign(result, { pageErrors: out.errors, consoleErrors: out.console, requests: out.requests });
  writeJson(`browser-P-${process.env.LABEL}.json`, result);
  expect(out.errors).toEqual([]);
  expect(unexpected(out)).toEqual([]);
});
