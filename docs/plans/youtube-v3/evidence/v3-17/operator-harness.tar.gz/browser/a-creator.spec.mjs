// V3-17 phase A, by mouse: S01 sign-in and sign-out (the next sign-in asks again), S02/S03 the
// creator's multipart upload with pause, refresh and resume, an aborted second upload, and S08's
// browser refusals (oversize, not an MP4) and invalid media. Writes runs/browser-A.json.
import { expect, test } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";
import { MEDIA, SHOTS, choose, record, signIn, signOut, steps, type, unexpected, writeJson } from "./common.mjs";

const TITLE = "V3-17 mouse: aurorafinch test card";
const DESCRIPTION = "A 20 s synthetic test card and 440 Hz tone, uploaded by mouse (glimmerreed).";
const ABORTED = "V3-17 mouse: aborted upload";
const INVALID = "V3-17 mouse: invalid media cobaltwren";

test("A: creator sign-in, upload with pause and resume, abort, refusals", async ({ page }) => {
  const out = record(page);
  const result = { steps: [] };
  const step = steps(result);
  await page.goto("/");
  await expect(page.locator("#identity")).toHaveText("Signed out");
  await expect(page.locator("#start")).toBeDisabled();
  await expect(page.locator("#favorites")).toBeHidden();
  step("S01 opened signed out", { message: await page.locator("#message").textContent() });

  await signIn(page, "creator");
  await expect(page.locator("#logout")).toBeVisible();
  await expect(page.locator("#start")).toBeEnabled();
  step("S01 creator signed in", { identity: await page.locator("#identity").textContent(), signOut: await page.locator("#logout").textContent(), uploads: await page.locator("#uploads").textContent() });
  await signOut(page);
  step("S01 signed out");
  const again = await signIn(page, "creator");
  step("S01 signed in again: Keycloak asked for the password", again);

  // S02/S03: upload at about 1 MiB/s so part 2 is still sending when Pause is clicked.
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("Network.enable");
  const throttle = (on) => cdp.send("Network.emulateNetworkConditions", { offline: false, latency: 0, downloadThroughput: -1, uploadThroughput: on ? 1024 * 1024 : -1 });
  await throttle(true);
  await choose(page, `${MEDIA}/youtube-v1-fixture.mp4`);
  await type(page, "#title", TITLE);
  await type(page, "#description", DESCRIPTION);
  await page.locator("#start").click();
  await expect(page.locator("#progress-text")).toHaveText(/Sending part 2 of 3/, { timeout: 60000 });
  await page.locator("#pause").click();
  await expect(page.locator("#message")).toHaveText(/Upload paused/);
  step("S03 paused during part 2", { puts: out.requests.filter((r) => r.url.includes("45702")), current: await page.locator("#current").textContent() });
  await throttle(false);
  const selection = JSON.parse(await page.evaluate(() => localStorage.getItem("upload-selection")));

  await page.reload();
  await expect(page.locator("#identity")).toHaveText("Signed in as creator");
  await expect(page.locator("#resume")).toBeVisible();
  await expect(page.locator("#progress-text")).toHaveText(/^1 of 3 parts acknowledged · uploading$/);
  step("S03 refreshed: the same upload selected from ListParts", { message: await page.locator("#message").textContent(), progress: await page.locator("#progress-text").textContent(), sameUpload: JSON.parse(await page.evaluate(() => localStorage.getItem("upload-selection"))).uploadId === selection.uploadId });
  const mark = out.requests.length;
  await choose(page, `${MEDIA}/youtube-v1-fixture.mp4`);
  await page.locator("#resume").click();
  await expect(page.locator("#message")).toHaveText(/Upload received/, { timeout: 60000 });
  const completedAt = Date.now();
  const resumed = out.requests.slice(mark);
  const puts = resumed.filter((r) => r.url.includes("45702"));
  expect(puts.map((r) => r.url.match(/partNumber=(\d)/)[1])).toEqual(["2", "3"]);
  const videoId = (await page.locator("#current").textContent()).match(/Video ([0-9a-f-]{36})/)[1];
  step("S02/S03 resumed: only parts 2 and 3 sent, completed", { videoId, uploadId: selection.uploadId, puts, calls: resumed.filter((r) => !r.url.includes("45702")).map((r) => `${r.method} ${r.url} ${r.status}`), current: await page.locator("#current").textContent(), progress: await page.locator("#progress-text").textContent() });
  const row = page.locator("#uploads .upload", { hasText: TITLE });
  const badges = [];
  for (let n = 0; n < 120; n += 1) {
    const text = await row.locator(".badge").textContent();
    if (badges.at(-1)?.badge !== text) badges.push({ afterMs: Date.now() - completedAt, badge: text });
    if (text === "ready") break;
    await page.waitForTimeout(250);
  }
  await expect(row.locator(".badge")).toHaveText("ready");
  step("S02/S04 the creator's list: badge changes after complete", { badges });

  // S03: a second upload, paused after part 1, then aborted from Recent uploads.
  await throttle(true);
  await choose(page, `${MEDIA}/youtube-v1-fixture.mp4`);
  await type(page, "#title", ABORTED);
  await type(page, "#description", "Aborted after part 1.");
  await page.locator("#start").click();
  await expect(page.locator("#progress-text")).toHaveText(/Sending part 2 of 3/, { timeout: 60000 });
  await page.locator("#pause").click();
  await expect(page.locator("#message")).toHaveText(/Upload paused/);
  await throttle(false);
  const abortedUpload = JSON.parse(await page.evaluate(() => localStorage.getItem("upload-selection"))).uploadId;
  const abortedRow = page.locator("#uploads .upload", { hasText: ABORTED });
  await expect(abortedRow.getByRole("button", { name: "Abort upload" })).toBeEnabled();
  await abortedRow.getByRole("button", { name: "Abort upload" }).click();
  await expect(page.locator("#message")).toHaveText(`“${ABORTED}” was aborted.`);
  await expect(page.locator("#uploads .upload", { hasText: ABORTED }).locator(".badge")).toHaveText("aborted");
  step("S03 second upload aborted by mouse", { uploadId: abortedUpload, message: await page.locator("#message").textContent(), row: await page.locator("#uploads .upload", { hasText: ABORTED }).textContent() });

  // S08 in the browser: a file over 256 MiB and a file that isn't an MP4 are refused before any request.
  const before = out.requests.filter((r) => r.url.includes("/uploads")).length;
  await choose(page, `${MEDIA}/oversize.mp4`);
  await type(page, "#title", "V3-17 mouse: oversize");
  await page.locator("#start").click();
  await expect(page.locator("#message")).toHaveClass(/error/);
  const oversize = await page.locator("#message").textContent();
  await choose(page, `${MEDIA}/notes.txt`);
  await type(page, "#title", "V3-17 mouse: not an MP4");
  await page.locator("#start").click();
  await expect(page.locator("#message")).toHaveText(/Choose an MP4 video/);
  const notMp4 = await page.locator("#message").textContent();
  step("S08 refused in the browser", { oversize, notMp4, uploadRequestsSent: out.requests.filter((r) => r.url.includes("/uploads")).length - before });

  // S08 invalid media: a text file named invalid.mp4 uploads and completes; the lifecycle fails it.
  await choose(page, `${MEDIA}/invalid.mp4`);
  await type(page, "#title", INVALID);
  await type(page, "#description", "A text file named invalid.mp4.");
  await page.locator("#start").click();
  await expect(page.locator("#message")).toHaveText(/Upload received/, { timeout: 60000 });
  const invalidId = (await page.locator("#current").textContent()).match(/Video ([0-9a-f-]{36})/)[1];
  await page.waitForTimeout(12000);
  await page.locator("#refresh").click();
  await expect(page.locator("#message")).toHaveText("Upload status refreshed.");
  step("S08 invalid media by mouse, 12 s after complete", { videoId: invalidId, current: await page.locator("#current").textContent(), row: await page.locator("#uploads .upload", { hasText: INVALID }).textContent() });
  await page.screenshot({ path: `${SHOTS}/v3-17-creator.png`, fullPage: true });

  await signOut(page);
  await expect(page.locator("#start")).toBeDisabled();
  step("signed out");
  Object.assign(result, { title: TITLE, description: DESCRIPTION, videoId, uploadId: selection.uploadId, abortedUpload, invalidId, invalidTitle: INVALID, pageErrors: out.errors, consoleErrors: out.console, requests: out.requests });
  writeJson("browser-A.json", result);
  expect(out.errors).toEqual([]);
  expect(unexpected(out)).toEqual([]);
});
