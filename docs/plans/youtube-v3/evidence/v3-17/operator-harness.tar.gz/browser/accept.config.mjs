// V3-17's browser runs of the outside copy's edge (45700), by mouse in Playwright's Chromium.
const S = "/tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/v317/browser";
export default {
  testDir: S,
  testMatch: /\.spec\.mjs$/,
  workers: 1,
  timeout: 420000,
  outputDir: `${S}/test-results`,
  reporter: [["list"]],
  use: { baseURL: "http://127.0.0.1:45700", viewport: { width: 1280, height: 900 }, trace: "off" },
  projects: [{ name: "chromium", use: { browserName: "chromium" } }],
};
