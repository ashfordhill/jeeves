// V3-17 phase B, by mouse: S06 search (title, description, channel), S05 signed-out playback with
// details, thumbnail, count, five seconds of decoded video and audio, and a timeline seek, S07 counts
// (fetches, a short play, pause and seek add none; 2 cumulative seconds add 1; a new page session
// adds 1), S09 the viewer signs in on the watch page and plays (counted), and S10 Favorites (toggle,
// list, remove from the list; signed out no toggle). READY_AT is video A's ready commit (ISO).
// Writes runs/browser-B.json.
import { expect, test } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";
import { SHOTS, media, openById, playPause, plays, readJson, record, searchOnce, searchUntilFound, seekTo, signIn, signOut, steps, unexpected, views, writeJson } from "./common.mjs";

test("B: anonymous search, watch, counts; the viewer plays and keeps a favorite", async ({ page }) => {
  const out = record(page);
  const result = { steps: [] };
  const step = steps(result);
  const a = readJson("browser-A.json");
  const TITLE = a.title, A = a.videoId;
  const readyAt = Date.parse(process.env.READY_AT);
  await page.goto("/");
  await expect(page.locator("#identity")).toHaveText("Signed out");

  // S06: title, description keyword and channel.
  const tries = await searchUntilFound(page, "aurorafinch", TITLE);
  step("S06 title search found it", { tries, foundAfterReadyMs: Date.parse(tries.at(-1).at) - readyAt });
  for (const q of ["glimmerreed", "creator"]) {
    const found = await searchOnce(page, q);
    expect(found.titles).toContain(TITLE);
    step(`S06 search "${q}"`, found);
  }
  await searchOnce(page, "aurorafinch");
  await page.locator("#search-results article", { hasText: TITLE }).getByRole("button", { name: "Watch video" }).click();
  await expect(page.locator("#watch-title")).toHaveText(TITLE);
  await expect.poll(() => views(page)).toBe(0);
  await expect(page.locator("#favorite")).toBeHidden();
  await expect(page.locator("#favorites")).toBeHidden();
  await expect(page.locator("#login")).toBeVisible();
  await page.locator("#watch-details summary").click();
  await expect.poll(() => page.locator("#thumbnail").evaluate((i) => i.complete && i.naturalWidth > 0)).toBe(true);
  const thumbnail = await page.locator("#thumbnail").evaluate((i) => ({ src: new URL(i.src).pathname.replace(/[0-9a-f-]{36}/g, "<id>"), width: i.naturalWidth, height: i.naturalHeight }));
  step("S05/S09 signed out: opened from search, no sign-in asked", { url: page.url(), byline: await page.locator("#watch-byline").textContent(), views: await page.locator("#watch-views").textContent(), viewStatus: await page.locator("#view-status").textContent(), thumbnail, favoriteToggle: await page.locator("#favorite").isVisible() });

  // S07: details and search fetches add nothing.
  for (let n = 0; n < 2; n += 1) {
    await searchOnce(page, "aurorafinch");
    await page.locator("#search-results article", { hasText: TITLE }).getByRole("button", { name: "Watch video" }).click();
    await expect(page.locator("#watch-title")).toHaveText(TITLE);
  }
  await page.waitForTimeout(3000);
  expect(await views(page)).toBe(0);
  expect(plays(out)).toEqual([]);
  step("S07 two more searches and opens: no play sent, still 0", { views: await views(page), detailsFetches: out.requests.filter((r) => r.url.includes("video-details-cache")).length, searches: out.requests.filter((r) => r.url.includes("video-search")).length });

  // S07: a short play (under 2 s), pause, and a seek while paused add nothing.
  await expect.poll(async () => (await media(page)).readyState, { timeout: 10000 }).toBeGreaterThan(0);
  await playPause(page);
  await expect.poll(async () => (await media(page)).currentTime, { timeout: 10000 }).toBeGreaterThan(0.6);
  await playPause(page);
  await expect.poll(async () => (await media(page)).paused).toBe(true);
  const short = await media(page);
  await seekTo(page, 0.1);
  await page.waitForTimeout(3000);
  expect(plays(out)).toEqual([]);
  expect(await views(page)).toBe(0);
  step("S07 short play, pause and a seek while paused: nothing sent", { pausedAt: short.currentTime, afterSeek: (await media(page)).currentTime, views: await views(page) });

  // S05: listen through an analyser (decoded PCM; Playwright's Chromium runs with --mute-audio and
  // nobody listens), then play: the count rises once 2 cumulative seconds have played.
  const audioContext = await page.evaluate(async () => {
    const v = document.querySelector("#player"), ctx = new AudioContext(), source = ctx.createMediaElementSource(v), analyser = ctx.createAnalyser();
    analyser.fftSize = 32768;
    source.connect(analyser);
    analyser.connect(ctx.destination);
    await ctx.resume();
    window.audioProbe = { ctx, analyser };
    return { state: ctx.state, sampleRate: ctx.sampleRate };
  });
  const startTime = (await media(page)).currentTime;
  await playPause(page);
  await expect.poll(async () => (await media(page)).paused, { timeout: 10000 }).toBe(false);
  await expect(page.locator("#view-status")).toHaveText(/Playback accepted/, { timeout: 15000 });
  const firstPost = plays(out)[0];
  await expect.poll(() => views(page), { timeout: 10000 }).toBe(1);
  const visibleAt = Date.now();
  step("S07 first play counted", { post: firstPost, countVisibleAfterAcceptMs: visibleAt - firstPost.at });
  await expect.poll(async () => (await media(page)).currentTime, { timeout: 20000 }).toBeGreaterThan(startTime + 5.5);
  const playback = await page.evaluate(() => {
    const v = document.querySelector("#player"), p = window.audioProbe, a = new Float32Array(p.analyser.fftSize), f = new Float32Array(p.analyser.frequencyBinCount);
    p.analyser.getFloatTimeDomainData(a);
    p.analyser.getFloatFrequencyData(f);
    let index = 0;
    for (let i = 1; i < f.length; i++) if (f[i] > f[index]) index = i;
    return { rms: Math.sqrt(a.reduce((n, x) => n + x * x, 0) / a.length), peakHz: (index * p.ctx.sampleRate) / p.analyser.fftSize, ctxState: p.ctx.state, muted: v.muted, volume: v.volume, humanListening: false };
  });
  const after5 = await media(page);
  expect(after5.frames).toBeGreaterThan(100);
  expect(playback.rms).toBeGreaterThan(0.01);
  expect(Math.abs(playback.peakHz - 440)).toBeLessThan(5);
  step("S05 played 5 s and more: decoded video and a 440 Hz tone", { audioContext, startTime, media: after5, audio: playback });
  await page.screenshot({ path: `${SHOTS}/v3-17-anonymous-watch.png`, fullPage: true });

  // S05/S07: a timeline seek keeps playing; pause and resume send nothing more.
  const beforeSeek = (await media(page)).currentTime;
  await seekTo(page, 0.8);
  await expect.poll(async () => (await media(page)).currentTime, { timeout: 5000 }).toBeGreaterThan(14);
  const sought = await media(page);
  await page.waitForTimeout(2000);
  const later = await media(page);
  expect(later.currentTime).toBeGreaterThan(sought.currentTime);
  await playPause(page);
  await expect.poll(async () => (await media(page)).paused).toBe(true);
  await seekTo(page, 0.3);
  await playPause(page);
  await page.waitForTimeout(2500);
  await playPause(page);
  await page.waitForTimeout(2500);
  expect(plays(out).length).toBe(1);
  expect(await views(page)).toBe(1);
  step("S05/S07 seek by the timeline, pause, seek and resume: still 1", { beforeSeek, afterSeek: sought.currentTime, twoSecondsLater: later.currentTime, end: await media(page), views: await views(page), playsSent: plays(out).length });

  // S07: a new page session counts again (a new event ID).
  await page.reload();
  await expect(page.locator("#watch-title")).toHaveText(TITLE);
  await expect.poll(() => views(page)).toBe(1);
  const mark = plays(out).length;
  await expect.poll(async () => (await media(page)).readyState, { timeout: 10000 }).toBeGreaterThan(0);
  await playPause(page);
  await expect(page.locator("#view-status")).toHaveText(/Playback accepted/, { timeout: 15000 });
  await expect.poll(() => views(page), { timeout: 10000 }).toBe(2);
  const second = plays(out)[mark];
  expect(JSON.parse(second.body).eventId).not.toBe(JSON.parse(firstPost.body).eventId);
  step("S07 new page session counted", { post: second, countVisibleAfterAcceptMs: Date.now() - second.at });
  await playPause(page);

  // S09: the viewer signs in on the watch page, comes back to the video and plays: counted.
  await signIn(page, "viewer");
  await expect(page).toHaveURL(new RegExp(`\\?watch=${A}$`));
  await expect(page.locator("#watch-title")).toHaveText(TITLE);
  await expect(page.locator("#favorite")).toHaveText("☆ Add to favorites");
  await expect(page.locator("#favorites")).toBeVisible();
  await expect(page.locator("#uploads")).toHaveText("Uploads need a creator account.");
  step("S09 viewer signed in on the watch page", { identity: await page.locator("#identity").textContent(), message: await page.locator("#message").textContent(), views: await page.locator("#watch-views").textContent(), favorites: await page.locator("#favorites").textContent() });
  const mark2 = plays(out).length;
  await expect.poll(async () => (await media(page)).readyState, { timeout: 10000 }).toBeGreaterThan(0);
  await playPause(page);
  await expect(page.locator("#view-status")).toHaveText(/Playback accepted/, { timeout: 15000 });
  await expect.poll(() => views(page), { timeout: 10000 }).toBe(3);
  const third = plays(out)[mark2];
  expect(third.auth).toBe(true);
  step("S09 the viewer's play counted", { post: third, countVisibleAfterAcceptMs: Date.now() - third.at });
  await playPause(page);

  // S10: ☆ → ★ and listed; removed from the list; added again for the restart.
  await page.locator("#favorite").click();
  await expect(page.locator("#favorite")).toHaveText("★ In favorites");
  await expect(page.locator("#favorites-list .upload", { hasText: TITLE })).toBeVisible();
  step("S10 favorited", { toggle: await page.locator("#favorite").textContent(), list: await page.locator("#favorites-list").textContent() });
  await page.screenshot({ path: `${SHOTS}/v3-17-viewer-favorites.png`, fullPage: true });
  await page.locator("#favorites-list .upload", { hasText: TITLE }).getByRole("button", { name: "Remove" }).click();
  await expect(page.locator("#favorites-list .upload", { hasText: TITLE })).toBeHidden();
  await expect(page.locator("#favorite")).toHaveText("☆ Add to favorites");
  step("S10 removed from the list", { toggle: await page.locator("#favorite").textContent(), list: await page.locator("#favorites-list").textContent(), status: await page.locator("#favorites-status").textContent() });
  await page.locator("#favorite").click();
  await expect(page.locator("#favorite")).toHaveText("★ In favorites");
  await expect(page.locator("#favorites-list .upload", { hasText: TITLE })).toBeVisible();
  step("S10 favorited again, kept for the restart");

  // S10: signed out, a ready video has no toggle and no list, only Sign in.
  await signOut(page);
  const opened = await openById(page, A);
  expect(opened.details).toBe(true);
  await expect(page.locator("#favorite")).toBeHidden();
  await expect(page.locator("#favorites")).toBeHidden();
  await expect(page.locator("#login")).toBeVisible();
  step("S10 signed out: the video opens with no toggle and no list", { opened, favoriteToggle: await page.locator("#favorite").isVisible(), favorites: await page.locator("#favorites").isVisible(), signIn: await page.locator("#login").isVisible() });

  Object.assign(result, { videoId: A, eventIds: plays(out).map((p) => JSON.parse(p.body).eventId), pageErrors: out.errors, consoleErrors: out.console, requests: out.requests });
  writeJson("browser-B.json", result);
  expect(out.errors).toEqual([]);
  expect(unexpected(out)).toEqual([]);
});
