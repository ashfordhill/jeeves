// V3-17 S08 (from V3-16's): a refused sign-in asks to sign in again, and the refused request is never
// sent again anonymously. The viewer signs in; the stored token's signature is then changed. The
// first request that carries it (whichever the page makes first: with favorites kept, the list's
// own details fetch) must be 401; then the page is signed out and says "Sign in again". Opening a
// video afterwards is a signed-out visitor's, anonymous by design. Writes runs/browser-refused.json.
import { expect, test } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";
import { openById, readJson, signIn, unexpected, writeJson } from "./common.mjs";

test("refused: a bad token asks to sign in again", async ({ page }) => {
  const errors = [], consoleErrors = [], sent = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => m.type() === "error" && consoleErrors.push(m.text()));
  page.on("request", (r) => {
    const u = new URL(r.url());
    if (u.pathname.startsWith("/api/")) sent.push({ at: Date.now(), path: u.pathname, auth: r.headers().authorization ? (r.headers().authorization.endsWith("AAAA") || r.headers().authorization.endsWith("BBBB") ? "changed" : "valid") : "none", response: r.response().then((x) => x?.status()) });
  });
  const { videoId } = readJson("browser-A.json");
  await page.goto("/");
  await signIn(page, "viewer");
  const tamper = await page.evaluate(() => {
    const s = JSON.parse(sessionStorage.getItem("auth"));
    const [h, p, sig] = s.access.split(".");
    s.access = `${h}.${p}.${sig.slice(0, -4)}${sig.slice(-4) === "AAAA" ? "BBBB" : "AAAA"}`;
    sessionStorage.setItem("auth", JSON.stringify(s));
    return { changed: JSON.parse(sessionStorage.getItem("auth")).access.split(".")[2] !== sig };
  });
  const mark = sent.length;
  // The first request with the changed token, whichever the page sends first; else opening a video sends it.
  for (let n = 0; n < 30 && !sent.slice(mark).some((r) => r.auth === "changed"); n += 1) await page.waitForTimeout(100);
  const first = sent.slice(mark).some((r) => r.auth === "changed") ? "the page itself" : "opening the video";
  if (first === "opening the video") await openById(page, videoId);
  await expect(page.locator("#message")).toHaveText(/Sign in again/);
  await expect(page.locator("#identity")).toHaveText("Signed out");
  await expect(page.locator("#login")).toBeVisible();
  await expect(page.locator("#favorites")).toBeHidden();
  const refused = sent.slice(mark).find((r) => r.auth === "changed");
  refused.status = await refused.response;
  expect(refused.status).toBe(401);
  await page.waitForTimeout(3000);
  const retried = sent.filter((r) => r.at > refused.at && r.path === refused.path && r.auth === "none");
  expect(retried).toEqual([]);
  const message = await page.locator("#message").textContent();
  // Afterwards, a signed-out visitor opens the video: anonymous, as Optional sign-in allows.
  const opened = await openById(page, videoId);
  const list = await Promise.all(sent.slice(mark).map(async (r) => ({ path: r.path.replace(/^.*\/modules\//, "…/"), auth: r.auth, status: await r.response })));
  const result = { tamper, firstSentBy: first, refused: { path: refused.path, status: refused.status }, anonymousRetryOfRefused: retried.length, message, messageIsError: await page.locator("#message").evaluate((m) => m.classList.contains("error")), identity: await page.locator("#identity").textContent(), thenOpened: opened, requests: list };
  console.log(JSON.stringify(result));
  writeJson("browser-refused.json", { ...result, pageErrors: errors, consoleErrors });
  expect(errors).toEqual([]);
  expect(unexpected({ console: consoleErrors })).toEqual([]);
});
