// V3-17 S06 timing, by mouse, signed out: started as soon as an upload completes by API, it searches
// for WORD by mouse until TITLE is found, then opens it. Writes runs/browser-fresh.json.
import { expect, test } from "/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs";
import { record, searchUntilFound, steps, unexpected, writeJson } from "./common.mjs";

test("fresh: a just-completed upload is found by search and opens", async ({ page }) => {
  const out = record(page);
  const result = { steps: [] };
  const step = steps(result);
  await page.goto("/");
  const tries = await searchUntilFound(page, process.env.WORD, process.env.TITLE);
  step("found", { tries });
  await page.locator("#search-results article", { hasText: process.env.TITLE }).getByRole("button", { name: "Watch video" }).click();
  await expect(page.locator("#watch-title")).toHaveText(process.env.TITLE);
  step("opened", { url: page.url(), status: await page.locator("#watch-status").textContent() });
  Object.assign(result, { foundAt: tries.at(-1).at, pageErrors: out.errors, consoleErrors: out.console });
  writeJson("browser-fresh.json", result);
  expect(out.errors).toEqual([]);
  expect(unexpected(out)).toEqual([]);
});
