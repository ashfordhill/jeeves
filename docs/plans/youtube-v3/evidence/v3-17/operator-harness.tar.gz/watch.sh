#!/usr/bin/env bash
# watch.sh <label> [max seconds]: prints each change of the listed videos' lifecycle state (read as the
# database owner, postgres, in this scratch run) until each is ready or failed, or <max> seconds pass.
. /tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/v317/env.sh
label=$1; max=${2:-120}; ids=$(cat $S/runs/$label-ids | cut -d' ' -f1-3 | tr ' ' '\n' | grep -E '^[0-9a-f-]{36}$'); list=$(printf "'%s'," $ids); list=${list%,}
pg() { docker exec $COMPOSE_PROJECT_NAME-local-postgres-1 psql -U postgres -d d_metadata -Atc "$1"; }
last=""; t0=$(date +%s.%N)
while :; do
  now=$(pg "select string_agg(left(asset_id::text,8)||' '||state||coalesce(' '||failure_code,''), ', ' order by created_at) from upload_api_multipart_uploads.assets where asset_id in ($list)")
  el=$(echo "$(date +%s.%N) - $t0" | bc | cut -c1-5)
  if [ "$now" != "$last" ]; then echo "+${el}s $now"; last=$now; fi
  if ! echo "$now" | grep -Eq 'pending|processing|uploading'; then break; fi
  if [ "$(echo "$el > $max" | bc)" = 1 ]; then echo "+${max}s timeout"; break; fi
  sleep 0.25
done
