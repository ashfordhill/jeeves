// Creates and removes my own Docker network (jeeves-v318-net) every 4 s for the given seconds.
import { execFileSync } from "node:child_process";
const until = Date.now() + Number(process.argv[2] ?? 180) * 1000;
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
let n = 0;
while (Date.now() < until) {
  try { execFileSync("docker", ["network", "create", "jeeves-v318-net"], { stdio: "ignore" }); console.log(`${Date.now()} created`); } catch (e) { console.log(`create failed ${e.message}`); }
  await wait(2000);
  try { execFileSync("docker", ["network", "rm", "jeeves-v318-net"], { stdio: "ignore" }); console.log(`${Date.now()} removed`); } catch (e) { console.log(`rm failed ${e.message}`); }
  await wait(2000);
  n += 1;
}
console.log(`done ${n}`);
