// V3-18 scratch: a copy of YouTube v3's saved design (field-projects/youtube/v3/inputs/design.json)
// in my scratch database, through my API on 4480, for the review's mouse pass.
import { readFileSync } from "node:fs";
import { designSchema, studioStudySeedOperations } from "/home/ash/github/jeeves/jeeves/packages/spec/src/index.ts";
const api = "http://127.0.0.1:4480";
const name = process.argv[2] ?? "V318 review v3";
const seed = designSchema.parse(JSON.parse(readFileSync("/home/ash/github/jeeves/field-projects/youtube/v3/inputs/design.json", "utf8")));
const ops = studioStudySeedOperations(seed);
if (seed.schemaVersion === 3 && seed.generation) ops.push({ op: "setGeneration", generation: structuredClone(seed.generation) });
const json = async (res: Response) => {
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  return res.json();
};
const { project } = await json(await fetch(`${api}/projects`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name }) }));
const saved = await json(await fetch(`${api}/projects/${project.id}/operations`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ baseRevision: 0, ops, source: "api" }) }));
const same = JSON.stringify({ ...saved.design, revision: 0 }) === JSON.stringify({ ...seed, revision: 0 });
console.log(JSON.stringify({ id: project.id, revision: saved.design.revision, sameAsSeed: same, findings: saved.findings.length }));
