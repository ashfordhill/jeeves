// V3-18 scratch: builds the stub stack (Runnable processes on) through my API on 4480, then saves
// one older-style revision whose Links API Request timeout is out of range, straight into the
// scratch database jeeves_v318. Never the owner's database.
import { createRequire } from "node:module";
import { buildStudioCommand } from "/home/ash/github/jeeves/jeeves/packages/spec/src/studio-operations.ts";
import { stubStackModuleCommands, stubStackTileCommands } from "/home/ash/github/jeeves/jeeves/packages/spec/src/fixtures/stub-stack.ts";
const require = createRequire("/home/ash/github/jeeves/jeeves/apps/server/package.json");
const { Client } = require("pg");
const api = "http://127.0.0.1:4480";
const name = process.argv[2] ?? "V318 out-of-range timeout";
const json = async (res: Response) => {
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  return res.json();
};
const { project } = await json(await fetch(`${api}/projects`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name }) }));
const id = project.id as string;
for (const command of [...stubStackTileCommands, ...stubStackModuleCommands, { type: "setRunnableProcesses", on: true }] as const) {
  const { design } = await json(await fetch(`${api}/projects/${id}/design`));
  const batch = buildStudioCommand(design, command as never);
  await json(await fetch(`${api}/projects/${id}/operations`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ baseRevision: batch.baseRevision, ops: batch.ops, source: "api" }) }));
}
const { design } = await json(await fetch(`${api}/projects/${id}/design`));
const old = structuredClone(design);
old.revision = design.revision + 1;
old.architecture.studio.elements.find((row: { element: string }) => row.element === "links-api").settings.requestTimeoutMs = 99999999;
const db = new Client({ connectionString: "postgres://jeeves:jeeves@127.0.0.1:54329/jeeves_v318" });
await db.connect();
const cols = await db.query("SELECT column_name FROM information_schema.columns WHERE table_name = 'design_revisions'");
console.log("columns", cols.rows.map((r: { column_name: string }) => r.column_name).join(","));
await db.query("BEGIN");
await db.query("INSERT INTO design_revisions (project_id, revision, document, findings) VALUES ($1, $2, $3, '[]'::jsonb)", [id, old.revision, JSON.stringify(old)]);
await db.query("UPDATE projects SET revision = $2 WHERE id = $1", [id, old.revision]);
await db.query("COMMIT");
await db.end();
console.log(JSON.stringify({ id, revision: old.revision }));
