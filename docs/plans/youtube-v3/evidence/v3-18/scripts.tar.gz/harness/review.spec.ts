// V3-18 review, by mouse: owner feedback 1-9, 12, 13 and D3-D5, D7 on a scratch copy of YouTube v3
// (my API 4480, scratch database jeeves_v318; my Vite 4490), at 1440×900 and 1280×800.
import type { Page } from "@playwright/test";
import {
  dashedLines,
  design,
  expect,
  fan,
  lines,
  moduleMenu,
  ready,
  settledBox,
  showView,
  test,
  tile,
  tiles,
} from "/home/ash/github/jeeves/jeeves/apps/web/e2e/studio.ts";

const shots = "/tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/shots";
const V3 = "dcc761d4-d0fe-4908-806e-dc25f3a5f6ed";
const inspector = (page: Page) => page.locator(".studio-inspector");
const toolbar = (page: Page) => page.getByRole("toolbar", { name: "Canvas tools" });
const notes: Record<string, unknown>[] = [];

for (const size of [
  { width: 1440, height: 900 },
  { width: 1280, height: 800 },
])
  test(`YouTube v3 by mouse at ${size.width}×${size.height}`, async ({ page }) => {
    test.setTimeout(420_000);
    const t0 = Date.now();
    const step = (name: string) => console.log(`STEP ${size.width} ${name} ${Date.now() - t0}ms`);
    const errors: string[] = [];
    page.on("pageerror", (error) => errors.push(String(error)));
    page.on("console", (message) => message.type() === "error" && errors.push(message.text()));
    await page.setViewportSize(size);
    await page.goto(`/?project=${V3}`);
    await ready(page);
    const note: Record<string, unknown> = { size: `${size.width}×${size.height}` };

    step('// F6/F7');
    // F6/F7: Detailed | Simple, Detailed first and the default; Pointer and Connect, no Hand.
    const view = page.getByRole("group", { name: "View", exact: true }).getByRole("button");
    await expect(view).toHaveText(["Detailed", "Simple"]);
    await expect(view.first()).toHaveAttribute("aria-pressed", "true");
    await expect(toolbar(page).getByRole("button", { name: "Pointer", exact: true })).toBeVisible();
    await expect(toolbar(page).getByRole("button", { name: "Connect", exact: true })).toBeVisible();
    await expect(page.getByRole("button", { name: /^Hand/ })).toHaveCount(0);
    // F5/D7: the legend is the dashed sample and the word Async.
    await expect(page.getByRole("note", { name: "Line guide" })).toHaveText("Async");

    step('// F3/F2');
    // F3/F2: kind labels; Queue or Topic by mode.
    for (const [name, kind] of [
      ["Metadata", "Database"],
      ["Hot metadata", "Cache"],
      ["Upload jobs", "Queue"],
      ["View events", "Topic"],
      ["Processing events", "Topic"],
      ["Publication events", "Topic"],
      ["Sign-in", "Identity"],
      ["Watch API", "Service"],
      ["Upload API", "Uploads"],
      ["Transcoder", "Worker"],
    ] as const)
      await expect(tile(page, name)).toContainText(kind);

    step('// F4/D3');
    // F4/D3: every application container has a + inside its frame; a click toggles the menu.
    const pluses = page.locator(".board").getByRole("button", { name: "Add module", exact: true });
    note.boardPluses = await pluses.count();
    const watchPlus = tile(page, "Watch API").getByRole("button", { name: "Add module", exact: true });
    await settledBox(watchPlus);
    await watchPlus.click();
    await expect(moduleMenu(page)).toBeVisible();
    note.menuGroups = await moduleMenu(page).getByRole("group").count();
    for (const group of ["Template", "Part of a template", "Stub"])
      await expect(moduleMenu(page)).toContainText(group);
    if (size.width === 1440) await page.screenshot({ path: `${shots}/review-plus-menu-1440.png` });
    await watchPlus.click();
    await expect(moduleMenu(page)).toHaveCount(0);
    await watchPlus.click();
    await expect(moduleMenu(page)).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(moduleMenu(page)).toHaveCount(0);

    step('// F8/D4');
    // F8/D4: the watchers' sign-in is Optional; the account and upload ones Required; Favorites.
    if (!(await inspector(page).isVisible()))
      await page.getByRole("button", { name: "Open inspector" }).click();
    const signIn = async (tileName: string, module: string) => {
      await tile(page, tileName).locator(".lane-container-header").click();
      await inspector(page).getByRole("button", { name: `Open ${module}`, exact: true }).click();
      const field = inspector(page).getByLabel("Sign-in", { exact: true });
      await expect(field).toBeVisible();
      const value = await field.evaluate((node) =>
        node instanceof HTMLSelectElement ? node.selectedOptions[0]?.textContent : (node as HTMLInputElement).value,
      );
      await inspector(page).getByRole("button", { name: `Back to ${tileName}` }).click();
      return value;
    };
    note.signIn = {
      viewer: await signIn("Watch API", "Viewer check"),
      account: await signIn("Account API", "Account check"),
      creator: await signIn("Upload API", "Creator check"),
    };
    await tile(page, "Account API").locator(".lane-container-header").click();
    await expect(inspector(page).getByRole("button", { name: "Open Favorite videos", exact: true })).toContainText("Favorites");

    step('// F9:');
    // F9: the inspector's + opens the same menu, left of the rail.
    const railPlus = inspector(page).getByRole("button", { name: "Add module", exact: true });
    await railPlus.click();
    await expect(moduleMenu(page)).toBeVisible();
    const menu = await settledBox(moduleMenu(page));
    const rail = await settledBox(inspector(page));
    note.inspectorMenuLeftOfRail = menu.x + menu.width <= rail.x + 1;
    // A click away, on empty paper near the canvas's top-left corner, closes it.
    const board = await settledBox(page.locator(".board .react-flow"));
    expect(menu.x).toBeGreaterThan(board.x + 40);
    const unchanged = (await design(page, V3)).revision;
    await page.mouse.click(board.x + 20, board.y + 140);
    await expect(moduleMenu(page)).toHaveCount(0);
    expect((await design(page, V3)).revision).toBe(unchanged);

    step('// D3: the link fan');
    // D3: the link fan opens and closes by a click.
    // Watch API is at the 5-link cap, so it offers none; Search API has one link.
    await tile(page, "Watch API").locator(".lane-container-header").click();
    note.watchApiAtCapOffersNoLinkedTile =
      (await tile(page, "Watch API").getByRole("button", { name: "Add linked tile", exact: true }).count()) === 0;
    await tile(page, "Search API").locator(".lane-container-header").click();
    const linked = tile(page, "Search API").getByRole("button", { name: "Add linked tile", exact: true });
    await settledBox(linked);
    await linked.click();
    await expect(fan(page).first()).toBeVisible();
    note.fanItems = await fan(page).count();
    await linked.click();
    await expect(fan(page)).toHaveCount(0);

    step('// F1:');
    // F1: Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y outside a field run Undo and Redo; inside a field the
    // key is the browser's own text undo and never the design's.
    const before = (await design(page, V3)).revision;
    const described = async () =>
      ((await design(page, V3)).elements.find((item) => item.id === "search-api") as { description?: string })
        .description ?? "";
    const description = inspector(page).getByLabel("Description", { exact: true });
    const original = await description.inputValue();
    const edited = `${original} (review)`.trim();
    await description.fill(edited);
    await inspector(page).getByRole("heading", { name: "Modules", exact: true }).click();
    await expect.poll(described).toBe(edited);
    const after = (await design(page, V3)).revision;
    expect(after).toBe(before + 1);
    await page.locator(".board .react-flow__pane").click({ position: { x: 10, y: 10 } });
    const keys: [string, string][] = [
      ["Control+z", original],
      ["Control+Shift+z", edited],
      ["Control+z", original],
      ["Control+y", edited],
    ];
    for (const [index, [key, expected]] of keys.entries()) {
      await page.keyboard.press(key);
      await expect.poll(async () => (await design(page, V3)).revision).toBe(after + index + 1);
      expect(await described()).toBe(expected);
    }
    note.undoRedoKeys = true;
    // In a field nobody has typed in this session, Ctrl+Z does nothing to the design.
    await tile(page, "Search API").locator(".lane-container-header").click();
    const name = inspector(page).getByLabel("Name", { exact: true });
    await name.click();
    await page.keyboard.press("Control+z");
    await page.waitForTimeout(900);
    note.ctrlZInFieldLeftDesign = (await design(page, V3)).revision === after + keys.length;
    await page.locator(".board .react-flow__pane").click({ position: { x: 10, y: 10 } });
    await page.getByRole("button", { name: "Undo", exact: true }).click();
    await expect.poll(described).toBe(original);

    step('// F12: Simple');
    // F12: Simple shows 21 tiles (24 with the user and actions), 33 lines, 8 dashed; the selected
    // tile has its + clear of its kind label.
    await showView(page, "Simple");
    note.simple = { tiles: await tiles(page).count(), lines: await lines(page).count(), dashed: await dashedLines(page).count() };
    await tile(page, "Watch API").click();
    note.simplePlus = await tile(page, "Watch API").getByRole("button", { name: "Add module", exact: true }).count();
    if (size.width === 1280) await page.screenshot({ path: `${shots}/review-simple-1280.png` });
    await showView(page, "Detailed");

    step('// D5/F12');
    // D5/F12: Generate project with Runnable processes: 11 templates and 2 stubs, runnable.
    await page.getByRole("button", { name: "Generate project", exact: true }).click();
    const dialog = page.getByRole("dialog", { name: "Generate experimental project" });
    await expect(dialog.getByRole("checkbox", { name: "Runnable processes" })).toBeChecked();
    const response = page.waitForResponse((item) => item.url().endsWith("/experimental-generation/preview"));
    await dialog.getByRole("button", { name: "Preview scaffold", exact: true }).click();
    const preview = await (await response).json();
    const templates = preview.templates as { ref: { id: string } }[];
    note.preview = {
      findings: preview.report.findings.length,
      runnable: preview.report.processes.runnable,
      templates: templates.filter((item) => item.ref.id !== "module-stub").length,
      stubs: templates.filter((item) => item.ref.id === "module-stub").length,
      files: preview.archive.files,
    };
    await dialog.getByRole("button", { name: "Close generate experimental project" }).click();
    notes.push(note);
    console.log(`REVIEW ${JSON.stringify(note)}`);
    expect(errors).toEqual([]);
  });
