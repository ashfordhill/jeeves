// V3-18 mouse check: an older revision whose Links API Request timeout is out of range opens, shows
// that one control with its reason, and is put right by mouse; Undo puts the old value back.
import { design, expect, ready, test, tile } from "/home/ash/github/jeeves/jeeves/apps/web/e2e/studio.ts";

const shots = "/tmp/claude-1000/-home-ash-github-jeeves/cd329e46-a878-4104-b70d-33aedd075c18/scratchpad/shots";
const cases = [
  { size: { width: 1440, height: 900 }, id: "96320b93-dd5a-44ed-8bf4-93cf85d70160" },
  { size: { width: 1280, height: 800 }, id: "2db145aa-ab93-4da7-aea0-68fbf3ea2194" },
];
for (const { size, id } of cases)
  test(`an out-of-range Request timeout is put right by mouse at ${size.width}×${size.height}`, async ({ page }) => {
    const errors: string[] = [];
    page.on("pageerror", (error) => errors.push(String(error)));
    page.on("console", (message) => message.type() === "error" && errors.push(message.text()));
    await page.setViewportSize(size);
    await page.goto(`/?project=${id}`);
    await ready(page);
    const settings = async () =>
      (await design(page, id)).architecture.studio.elements.find((row) => row.element === "links-api")
        ?.settings;
    expect((await settings())?.requestTimeoutMs).toBe(99999999);
    const inspector = page.locator(".studio-inspector");
    if (!(await inspector.isVisible())) await page.getByRole("button", { name: "Open inspector" }).click();
    await tile(page, "Links API").locator(".lane-container-header").click();
    const timeout = inspector.getByLabel("Request timeout", { exact: true });
    const limit = inspector.getByLabel("Concurrency limit", { exact: true });
    await expect(timeout).toHaveValue("99999999");
    await expect(inspector.getByText("Too big: expected number to be <=300000")).toBeVisible();
    // Only the control the finding names; the tile's other process limit waits.
    await expect(limit).toHaveCount(0);
    await page.screenshot({ path: `${shots}/out-of-range-before-${size.width}.png` });
    const before = (await design(page, id)).revision;
    await timeout.fill("5000");
    await inspector.getByRole("heading", { name: "Options", exact: true }).click();
    await expect.poll(async () => (await settings())?.requestTimeoutMs).toBe(5000);
    expect((await design(page, id)).revision).toBe(before + 1);
    await expect(inspector.getByText("Too big: expected number to be <=300000")).toHaveCount(0);
    // The design is valid again, so every control is back.
    await expect(limit).toBeVisible();
    await expect(limit).toHaveAttribute("placeholder", "1000");
    const findings = (await (await page.request.get(`/api/projects/${id}/findings`)).json()).findings as { message: string }[];
    expect(findings.filter((item) => item.message.startsWith("Too big"))).toEqual([]);
    await page.screenshot({ path: `${shots}/out-of-range-after-${size.width}.png` });
    // Undo puts the old value back, and it still opens; Redo fixes it again.
    await page.getByRole("button", { name: "Undo", exact: true }).click();
    await expect.poll(async () => (await settings())?.requestTimeoutMs).toBe(99999999);
    await expect(timeout).toHaveValue("99999999");
    await page.getByRole("button", { name: "Redo", exact: true }).click();
    await expect.poll(async () => (await settings())?.requestTimeoutMs).toBe(5000);
    expect(errors).toEqual([]);
  });
