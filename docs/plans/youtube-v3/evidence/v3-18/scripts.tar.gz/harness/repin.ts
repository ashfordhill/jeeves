import { writeFileSync, readFileSync } from "node:fs";
import { loadLocalV2Registry } from "/home/ash/github/jeeves/jeeves-generator/templates/local-v2/index.ts";
import { offDesigns, offPin } from "/home/ash/github/jeeves/jeeves-generator/src/v2/fixtures/processes-off.ts";
const registry = loadLocalV2Registry();
const path = "/home/ash/github/jeeves/jeeves-generator/src/v2/fixtures/processes-off.json";
const before = JSON.parse(readFileSync(path, "utf8"));
const after: Record<string, unknown> = {};
for (const [name, design] of Object.entries(offDesigns(registry))) {
  const pin = offPin(design, registry);
  after[name] = pin;
  const old = before[name];
  const changed = Object.keys({ ...old.sha256, ...pin.sha256 }).filter((k) => old.sha256[k] !== pin.sha256[k]);
  console.log(name, old.files, "->", pin.files, changed);
}
if (process.argv.includes("--write")) writeFileSync(path, `${JSON.stringify(after, null, 2)}\n`);
