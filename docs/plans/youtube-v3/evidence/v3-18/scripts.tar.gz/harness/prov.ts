import { readFileSync } from "node:fs";
import { provenanceWithoutInventory } from "/home/ash/github/jeeves/jeeves-generator/src/v2/fixtures/processes-off.ts";
const [a, b] = process.argv.slice(2);
for (const p of [".jeeves/report.json", ".jeeves/manifest.json"]) {
  const x = provenanceWithoutInventory(p, readFileSync(`${a}/${p}`));
  const y = provenanceWithoutInventory(p, readFileSync(`${b}/${p}`));
  if (x === y) { console.log(p, "equal without inventory"); continue; }
  const X = JSON.parse(x), Y = JSON.parse(y);
  if (p.endsWith("manifest.json")) {
    const fx = new Map(X.files.map((f: any) => [f.path, JSON.stringify(f)]));
    for (const f of Y.files) if (fx.get(f.path) !== JSON.stringify(f)) console.log(p, "differs at", f.path);
    for (const k of Object.keys({ ...X, ...Y })) if (k !== "files" && JSON.stringify(X[k]) !== JSON.stringify(Y[k])) console.log(p, "differs at key", k);
  } else console.log(p, "differs");
}
