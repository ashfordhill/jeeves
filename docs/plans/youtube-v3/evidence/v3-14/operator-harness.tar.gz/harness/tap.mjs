// Inside app-video-lifecycle (cwd /app). MODE=setup binds two scratch queues to the Processing and
// Publication events exchanges; MODE=drain takes (acks) what they got since the last drain and peeks
// (puts back) every .failed queue. Prints JSON.
import amqp from "amqplib";
import { readFileSync } from "node:fs";
const password = readFileSync("/run/secrets/broker-password", "utf8").trim();
const connection = await amqp.connect({ hostname: "local-broker", username: "runtime", password });
const channel = await connection.createChannel();
const taps = [["v314-tap-processing", "processing-events"], ["v314-tap-publication", "publication-events"]];
const failed = ["upload-jobs.failed", "processing-events--video-lifecycle.failed", "publication-events--search-indexer.failed"];
const brief = (m, ack) => {
  const body = JSON.parse(m.content.toString());
  const { schemaVersion, result, ...rest } = body;
  return { messageId: m.properties.messageId, headers: m.properties.headers, ...rest, ...(result ? { result: { manifest: result.manifest, thumbnail: result.thumbnail, durationSeconds: result.durationSeconds, renditions: result.renditions.map((r) => `${r.width}x${r.height} ${r.videoCodec}/${r.audioCodec}`) } } : {}) };
};
const out = {};
if (process.env.MODE === "setup") {
  for (const [queue, exchange] of taps) {
    await channel.assertQueue(queue, { durable: true });
    await channel.bindQueue(queue, exchange, "");
  }
  out.bound = taps;
} else {
  for (const [queue] of taps) {
    out[queue] = [];
    for (let m; (m = await channel.get(queue, { noAck: false })); ) { out[queue].push(brief(m)); channel.ack(m); }
  }
  for (const queue of failed) {
    const got = [];
    for (let m; (m = await channel.get(queue, { noAck: false })); ) got.push(m);
    out[queue] = { count: got.length, last: got.slice(-3).map((m) => { const b = brief(m); return { messageId: b.messageId, type: b.type, videoId: b.videoId, attempt: b.headers?.["x-delivery-attempt"], code: b.headers?.["x-terminal-code"] }; }) };
    for (const m of got) channel.nack(m, false, true);
  }
}
console.log(JSON.stringify(out, null, 1));
await channel.close();
await connection.close();
