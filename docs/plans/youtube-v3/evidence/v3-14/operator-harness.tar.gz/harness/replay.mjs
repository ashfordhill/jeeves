// Inside app-video-lifecycle (cwd /app): sends one message again, as a redelivery would, with its
// own message ID. QUEUE=<queue> ID=<message id> BODY=<json>. Uses a confirm channel.
import amqp from "amqplib";
import { readFileSync } from "node:fs";
const password = readFileSync("/run/secrets/broker-password", "utf8").trim();
const connection = await amqp.connect({ hostname: "local-broker", username: "runtime", password });
const channel = await connection.createConfirmChannel();
channel.sendToQueue(process.env.QUEUE, Buffer.from(process.env.BODY), { persistent: true, messageId: process.env.ID, contentType: "application/json" });
await channel.waitForConfirms();
console.log(JSON.stringify({ sent: process.env.ID, queue: process.env.QUEUE }));
await channel.close();
await connection.close();
