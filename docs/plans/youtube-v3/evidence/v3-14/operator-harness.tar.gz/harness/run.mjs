// One V3-14 pass: the creator uploads the fixture (3 parts) and, with "invalid", a text file named
// invalid.mp4 (1 part); both complete. node run.mjs <label> [invalid]. Writes ../runs/<label>-upload.json.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { PART, UPLOADS, api, log, putPart, sanitize, show, token } from "./lib.mjs";
const label = process.argv[2];
const creator = await token("creator");
const as = { who: "creator", bearer: creator };
async function upload(file, fileName, title) {
  const bytes = readFileSync(file);
  const body = { fileName, size: bytes.length, contentType: "video/mp4", lastModified: 1762555020000, sha256: createHash("sha256").update(bytes).digest("hex"), title, description: `V3-14 ${label}: a 20 s synthetic test card and 440 Hz tone.` };
  const started = await api("POST", UPLOADS, { ...as, body });
  if (started.status !== 200) throw new Error(`start ${started.status}`);
  const id = started.body.uploadId;
  for (let n = 1; n <= Math.ceil(bytes.length / PART); n++) {
    const signed = await api("POST", `${UPLOADS}/${id}/parts/${n}`, as);
    const part = bytes.subarray((n - 1) * PART, n * PART);
    const etag = await putPart(signed.body.url, part);
    log.push({ method: "PUT", path: `<signed URL, part ${n}>`, who: "signed URL", status: 200, body: { etag, size: part.length } });
  }
  const done = await api("POST", `${UPLOADS}/${id}/complete`, as);
  if (done.status !== 200) {
    await api("POST", `${UPLOADS}/${id}/abort`, as); // never leave a completion for the next start's sweep
    throw new Error(`complete ${done.status}`);
  }
  await api("GET", `${UPLOADS}/${id}`, as);
  return { title, size: bytes.length, ...done.body };
}
const uploads = [await upload(process.env.FIXTURE, "youtube-v1-fixture.mp4", `V3-14 ${label}: test card`)];
if (process.argv.includes("invalid")) uploads.push(await upload(process.env.INVALID, "invalid.mp4", `V3-14 ${label}: invalid media`));
for (const e of log) console.log(show(e).slice(0, 260));
console.log(JSON.stringify(uploads));
writeFileSync(new URL(`./runs/${label}-upload.json`, import.meta.url), JSON.stringify(sanitize({ uploads, log }), null, 2));
writeFileSync(new URL(`./runs/${label}-ids`, import.meta.url), uploads.map((u) => u.videoId).join(" "));
