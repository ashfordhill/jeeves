# Stage k of V3-14 in the outside copy: hooks after step k throw "Not implemented" again, exactly
# as exported, so each step shows where a message stops next. python3 stage.py <copy> <k>
import re, sys
copy, k = sys.argv[1], int(sys.argv[2])
T = f"{copy}/src/modules/transcoder/transcoder-segmenter-and-encoder.hooks.ts"
L = f"{copy}/src/modules/video-lifecycle/video-lifecycle-lifecycle-writer.hooks.ts"
SQL = f"{copy}/infra/postgres/metadata/modules/video-lifecycle-lifecycle-writer.sql"
# (step, file, indent, signature start, occurrence, what)
hooks = [
  (1, T, 4, "job(raw, messageId) {", 0, "job for Segmenter and encoder"),
  (2, T, 4, "video(job) {", 0, "video for Segmenter and encoder"),
  (3, T, 6, "owns(job: VideoHlsJob): boolean {", 1, "results.owns for Segmenter and encoder"),
  (4, T, 4, "eventId(job, kind) {", 0, "eventId for Segmenter and encoder"),
  (4, T, 4, "event(job, event) {", 0, "event for Segmenter and encoder"),
  (5, T, 6, "owns(job: VideoHlsJob): boolean {", 0, "source.owns for Segmenter and encoder"),
  (6, T, 4, "result(raw, job) {", 0, "result for Segmenter and encoder"),
  (7, L, 4, "event(input) {", 0, "event for Lifecycle writer"),
  (8, L, 6, "result(identity, kind) {", 0, "identities.result for Lifecycle writer"),
  (9, L, 4, "failure(input) {", 0, "failure for Lifecycle writer"),
  (10, L, 4, "result(input, identity) {", 0, "result for Lifecycle writer"),
  (11, L, 6, "publication(assetId) {", 0, "identities.publication for Lifecycle writer"),
  (11, L, 6, "async construct(_tx, ready, eventId) {", 0, "publication.construct for Lifecycle writer"),
  (11, L, 6, "codec(input, eventId) {", 1, "publication.codec for Lifecycle writer"),
]
stubbed = []
for path in (T, L):
    lines = open(path).read().split("\n")
    for step, file, indent, sig, occ, what in hooks:
        if file != path or step <= k: continue
        pad = " " * indent
        starts = [i for i, l in enumerate(lines) if l == pad + sig]
        i = starts[occ]
        j = next(n for n in range(i + 1, len(lines)) if lines[n] in (pad + "},", pad + "}"))
        lines[i + 1 : j] = [pad + f'  throw new NotImplemented("{what}");']
        stubbed.append(what)
    text = "\n".join(lines)
    if "NotImplemented(" in text and "import { NotImplemented }" not in text:
        text = text.replace('import ', 'import { NotImplemented } from "../../runtime/tile-process.ts";\nimport ', 1)
    open(path, "w").write(text)
if k < 11:
    sql = open(SQL).read()
    open(SQL, "w").write(sql.split("\n\n-- published.videos (V3-14)")[0] + ("\n" if not sql.split("\n\n-- published.videos (V3-14)")[0].endswith("\n") else ""))
    stubbed.append("published.videos (not yet in the SQL file)")
print(f"stage {k}: still unwritten: {', '.join(stubbed) or 'none'}")
