#!/usr/bin/env bash
# incontainer.sh <service> <script> [VAR=value ...]: runs a harness script inside an app-* container.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v314/env.sh
svc=$1; script=$2; shift 2
envs=(); for kv in "$@"; do envs+=(-e "$kv"); done
docker exec -i -w /app "${envs[@]}" "$COMPOSE_PROJECT_NAME-$svc-1" node --input-type=module - < "$S/harness/$script"
