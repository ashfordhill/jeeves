#!/usr/bin/env bash
# snapshot.sh: a comparable record of the copy's runtime: secrets, setup, volumes, lifecycle rows,
# published.videos, outbox, receipts, queues, the ready video's objects and the accounts.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v314/env.sh
cd $S/copy; V=$(cut -d' ' -f1 $S/harness/runs/step11-ids)
pg() { docker exec $COMPOSE_PROJECT_NAME-local-postgres-1 psql -U postgres -d d_metadata -Atc "$1"; }
stat -c '%a %n' .runtime .runtime/secrets
echo "secrets $(ls .runtime/secrets | wc -l) $(cat .runtime/secrets/* | sha256sum | cut -c1-16)"
echo "setup $(sha256sum .runtime/local-setup.json | cut -c1-16)"
docker volume ls -q --filter label=com.docker.compose.project=$COMPOSE_PROJECT_NAME | xargs docker volume inspect --format '{{.Name}} {{.CreatedAt}}'
echo "assets $(pg "select count(*) from upload_api_multipart_uploads.assets") $(pg "select asset_id, state, state_version, failure_code, result::text, ready_at from upload_api_multipart_uploads.assets where state in ('ready','failed') order by asset_id" | sha256sum | cut -c1-16)"
echo "published.videos $(pg "select * from published.videos" | sha256sum | cut -c1-16) $(pg "select video_id||' '||title from published.videos")"
echo "outbox $(pg "select count(*)||' rows, '||count(sent_at)||' sent' from upload_api_multipart_uploads.outbox") $(pg "select event_id, payload::text, sent_at from upload_api_multipart_uploads.outbox order by event_id" | sha256sum | cut -c1-16)"
echo "receipts $(pg "select count(*) from upload_api_multipart_uploads.receipts") $(pg "select * from upload_api_multipart_uploads.receipts order by event_id" | sha256sum | cut -c1-16)"
echo "queues $(docker exec $COMPOSE_PROJECT_NAME-local-broker-1 rabbitmqctl list_queues -q name messages 2>/dev/null | grep -v '^name' | sort | tr '\t' '=' | tr '\n' ' ')"
echo "objects $($S/incontainer.sh app-transcoder outputs.mjs VIDEO=$V | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d["objects"], d["bytes"], d["everyInventoryObjectStored"])')"
echo "accounts $(docker exec $COMPOSE_PROJECT_NAME-local-postgres-1 psql -U postgres -d i_sign_in -Atc "select string_agg(u.username, ',' order by u.username) from user_entity u join realm r on r.id=u.realm_id where r.name='sign-in'")"
