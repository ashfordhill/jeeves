#!/usr/bin/env bash
# state.sh <label> <since>: this step's rows, published.videos, the outbox, the queues, the taps and
# the not-implemented log lines since <since>.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v314/env.sh
label=$1; since=$2; ids=$(cat $S/harness/runs/$label-ids); list=$(printf "'%s'," $ids); list=${list%,}
pg() { docker exec $COMPOSE_PROJECT_NAME-local-postgres-1 psql -U postgres -d d_metadata -c "$1"; }
echo "== assets"; pg "select asset_id, metadata->>'title' title, state, state_version v, failure_code, queued_at::time(0) queued, started_at::time(0) started, ready_at::time(0) ready, deadline_at::time(0) deadline from upload_api_multipart_uploads.assets where asset_id in ($list) order by created_at"
echo "== published.videos (all rows)"; pg "select video_id, title, channel, duration_seconds, manifest, thumbnail, published_at, publication_version from published.videos order by published_at"
echo "== outbox (this step)"; pg "select destination, event_id, payload->>'type' type, sent_at is not null sent, attempts from upload_api_multipart_uploads.outbox where payload->>'videoId' in ($list) order by created_at"
echo "== receipts (this step)"; pg "select left(payload->>'assetId',8) asset, payload->>'kind' kind, event_id, result->'value'->>'outcome' outcome, handled_at::time(0) handled from upload_api_multipart_uploads.receipts where payload->>'assetId' in ($list) order by handled_at"
echo "== queues"; docker exec $COMPOSE_PROJECT_NAME-local-broker-1 rabbitmqctl list_queues -q name messages messages_unacknowledged 2>/dev/null | sort | tr "\t" " "
echo "== taps and dead letters"; $S/incontainer.sh app-video-lifecycle tap.mjs MODE=drain
echo "== not-implemented and failures (transcoder, lifecycle, search indexer)"
for svc in app-transcoder app-video-lifecycle app-search-indexer; do docker logs --since "$since" $COMPOSE_PROJECT_NAME-$svc-1 2>&1 | grep -E '"not-implemented"|"failed"|rror' | cut -c1-400; done
