#!/usr/bin/env bash
# watch.sh <label> [max seconds]: prints each change of this step's assets' lifecycle state (as the
# setup owner would read it, here as postgres in the scratch run), until every one is ready or failed,
# or nothing has changed for 25 s with Upload jobs and Processing events empty.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v314/env.sh
label=$1; max=${2:-180}; ids=$(cat $S/harness/runs/$label-ids); list=$(printf "'%s'," $ids); list=${list%,}
pg() { docker exec $COMPOSE_PROJECT_NAME-local-postgres-1 psql -U postgres -d d_metadata -Atc "$1"; }
q() { docker exec $COMPOSE_PROJECT_NAME-local-broker-1 rabbitmqctl list_queues -q name messages messages_unacknowledged 2>/dev/null | awk '$1=="upload-jobs"||$1=="processing-events--video-lifecycle"{s+=$2+$3} END{print s+0}'; }
last=""; t0=$(date +%s); still=$t0
while :; do
  now=$(pg "select string_agg(left(asset_id::text,8)||' '||state||coalesce(' '||failure_code,'')||' v'||state_version, ', ' order by created_at) from upload_api_multipart_uploads.assets where asset_id in ($list)")
  if [ "$now" != "$last" ]; then echo "+$(( $(date +%s) - t0 ))s $now"; last=$now; still=$(date +%s); fi
  if ! echo "$now" | grep -Eq 'pending|processing|uploading'; then break; fi
  if [ "$(q)" = 0 ] && [ $(( $(date +%s) - still )) -ge 25 ]; then echo "+$(( $(date +%s) - t0 ))s settled (queues empty, no change for 25 s)"; break; fi
  if [ $(( $(date +%s) - t0 )) -ge $max ]; then echo "+${max}s timeout"; break; fi
  sleep 1
done
