#!/usr/bin/env bash
# step.sh <label> [invalid]: one pass after a restart: upload, watch the lifecycle, dump the state.
. /tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v314/env.sh
since=$(date -u +%Y-%m-%dT%H:%M:%SZ)
(cd $S/harness && node run.mjs "$@") | tail -1
$S/watch.sh $1 ${MAX:-180}
$S/state.sh $1 $since
