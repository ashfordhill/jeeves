#!/usr/bin/env bash
# A comparable snapshot of the copy's runtime: secrets, volumes, upload rows, queues, accounts.
S=/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v313
cd $S/copy
stat -c '%a %n' .runtime .runtime/secrets
echo "secrets $(ls .runtime/secrets | wc -l) $(cat .runtime/secrets/* | sha256sum | cut -c1-16)"
echo "setup $(sha256sum .runtime/local-setup.json | cut -c1-16)"
docker volume ls -q --filter label=com.docker.compose.project=jeeves-v313-upload | xargs docker volume inspect --format '{{.Name}} {{.CreatedAt}}'
docker exec jeeves-v313-upload-local-postgres-1 psql -U postgres -d d_metadata -Atc "select upload_id, state, phase, complete_response::text from upload_api_multipart_uploads.uploads order by created_at" | sha256sum | sed 's/^/uploads /' | cut -c1-30
docker exec jeeves-v313-upload-local-postgres-1 psql -U postgres -d d_metadata -Atc "select count(*), count(sent_at) from upload_api_multipart_uploads.outbox" | sed 's/^/outbox total|sent /'
docker exec jeeves-v313-upload-local-broker-1 rabbitmqctl list_queues -q name messages 2>/dev/null | grep upload | tr '\t' ' ' | tr '\n' ';'; echo
docker exec jeeves-v313-upload-local-postgres-1 psql -U postgres -d i_sign_in -Atc "select u.username, coalesce(string_agg(r.name, ',' order by r.name) filter (where r.name='creator'),'-') from user_entity u join realm re on re.id=u.realm_id left join user_role_mapping m on m.user_id=u.id left join keycloak_role r on r.id=m.role_id where re.name='sign-in' group by u.username order by 1" | tr '\n' ' '; echo
