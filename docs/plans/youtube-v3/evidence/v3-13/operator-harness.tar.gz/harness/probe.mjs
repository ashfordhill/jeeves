// One pass of the upload path, as far as it gets: node probe.mjs <label>
// Writes ../runs/<label>.json (sanitized) and prints one line per request.
import { mkdirSync, writeFileSync } from "node:fs";
import { UPLOADS, ME, api, fixture, log, putPart, sanitize, show, tampered, token, claims, PART } from "./lib.mjs";

const label = process.argv[2] ?? "probe";
const creator = await token("creator");
const viewer = await token("viewer");
const roles = (t) => claims(t).realm_access?.roles ?? [];
console.log(`tokens: creator roles ${JSON.stringify(roles(creator))}, viewer roles ${JSON.stringify(roles(viewer))}, aud ${JSON.stringify(claims(creator).aud)}`);
const { bytes, body } = fixture();
const start = { ...body, title: `V3-13 ${label}`, description: "A 20 s synthetic test card and tone." };

await api("GET", ME, { who: "creator", bearer: creator });
await api("POST", UPLOADS, { body: start });
await api("POST", UPLOADS, { who: "bad", bearer: tampered(creator), body: start });
await api("POST", UPLOADS, { who: "viewer", bearer: viewer, body: start });
const s = await api("POST", UPLOADS, { who: "creator", bearer: creator, body: start });
if (s.status === 200) {
  const id = s.body.uploadId;
  const parts = Math.ceil(bytes.length / PART);
  const sign = async (n) => (await api("POST", `${UPLOADS}/${id}/parts/${n}`, { who: "creator", bearer: creator })).body.url;
  const etag = await putPart(await sign(1), bytes.subarray(0, PART));
  log.push({ method: "PUT", path: "<signed part 1>", who: "signed URL", status: 200, body: { etag, size: PART } });
  await api("GET", `${UPLOADS}/${id}`, { who: "creator", bearer: creator });
  for (let n = 2; n <= parts; n++) {
    const part = bytes.subarray((n - 1) * PART, n * PART);
    const e = await putPart(await sign(n), part);
    log.push({ method: "PUT", path: `<signed part ${n}>`, who: "signed URL", status: 200, body: { etag: e, size: part.length } });
  }
  await api("GET", `${UPLOADS}/${id}`, { who: "creator", bearer: creator });
  const done = await api("POST", `${UPLOADS}/${id}/complete`, { who: "creator", bearer: creator });
  await api("POST", `${UPLOADS}/${id}/complete`, { who: "creator", bearer: creator });
  await api("GET", `${UPLOADS}/${id}`, { who: "creator", bearer: creator });
  // A completion stopped by an unwritten hook stays "completing"; abort it so the next start's sweep can't reach it.
  if (done.status === 501) await api("POST", `${UPLOADS}/${id}/abort`, { who: "creator", bearer: creator });
}
await api("GET", UPLOADS, { who: "creator", bearer: creator });
for (const e of log) console.log(show(e));
mkdirSync(new URL("../runs/", import.meta.url), { recursive: true });
writeFileSync(new URL(`../runs/${label}.json`, import.meta.url), JSON.stringify(sanitize(log), null, 2));
