// After stop and start: the same accounts sign in, the same uploads answer the same.
import { writeFileSync } from "node:fs";
import { ME, UPLOADS, api, log, sanitize, show, token } from "./lib.mjs";
const id = "9de9fd5f-30f7-4a6f-a246-cb201a5933d3", aborted = "756340b8-430b-44ec-a621-c90f23c42e2f";
const creator = await token("creator"), other = await token("other-creator"), viewer = await token("viewer");
await api("GET", ME, { who: "creator", bearer: creator });
const list = await api("GET", UPLOADS, { who: "creator", bearer: creator });
await api("POST", `${UPLOADS}/${id}/complete`, { who: "creator", bearer: creator });
await api("POST", `${UPLOADS}/${aborted}/complete`, { who: "creator", bearer: creator });
await api("GET", `${UPLOADS}/${id}`, { who: "other-creator", bearer: other });
await api("POST", UPLOADS, { who: "viewer", bearer: viewer, body: {} });
await api("POST", UPLOADS, { body: {} });
for (const e of log) console.log(show(e).slice(0, 300));
console.log("uploads listed:", list.body.uploads.map((u) => `${u.uploadId.slice(0, 8)} ${u.state}`).join(", "));
writeFileSync(new URL("../runs/after-restart.json", import.meta.url), JSON.stringify(sanitize(log), null, 2));
