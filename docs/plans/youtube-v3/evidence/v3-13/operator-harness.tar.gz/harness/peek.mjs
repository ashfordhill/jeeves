// Inside an app-* container: read every message on a queue and put them all back (nack, requeue).
import amqp from "amqplib";
import { readFileSync } from "node:fs";
const queue = process.argv[2];
const password = readFileSync("/run/secrets/broker-password", "utf8").trim();
const connection = await amqp.connect({ hostname: "local-broker", username: "runtime", password });
const channel = await connection.createChannel();
const messages = [];
for (let message; (message = await channel.get(queue, { noAck: false })); ) messages.push(message);
console.log(JSON.stringify({ queue, messages: messages.map((m) => ({ messageId: m.properties.messageId, headers: m.properties.headers, body: JSON.parse(m.content.toString()) })) }, null, 2));
for (const m of messages) channel.nack(m, false, true);
await channel.close();
await connection.close();
