// The start request's refusals (S08's oversize and non-MP4, plus a bad title): node validate.mjs <label>
import { mkdirSync, writeFileSync } from "node:fs";
import { UPLOADS, api, fixture, log, sanitize, show, token } from "./lib.mjs";

const label = process.argv[2] ?? "validate";
const creator = await token("creator");
const { body } = fixture();
const ok = { ...body, title: "Refusal check", description: "" };
const as = (request) => api("POST", UPLOADS, { who: "creator", bearer: creator, body: request });
await as({ ...ok, size: 268435457 });
await as({ ...ok, fileName: "notes.txt", contentType: "text/plain" });
await as({ ...ok, contentType: "video/quicktime" });
await as({ ...ok, title: "" });
await as({ ...ok, title: "x".repeat(201) });
await as({ ...ok, sha256: "not-a-hash" });
await as({ ...ok, extra: true });
for (const e of log) console.log(show(e));
mkdirSync(new URL("../runs/", import.meta.url), { recursive: true });
writeFileSync(new URL(`../runs/${label}.json`, import.meta.url), JSON.stringify(sanitize(log), null, 2));
