// V3-13's recorded upload pass (contract §7 S01–S03's upload rows): node upload-run.mjs <label>
import { mkdirSync, writeFileSync } from "node:fs";
import { HTTP, ME, PART, UPLOADS, api, claims, fixture, log, putPart, sanitize, show, tampered, token } from "./lib.mjs";

const label = process.argv[2] ?? "upload-run";
const facts = {};
const creator = await token("creator");
const other = await token("other-creator");
const viewer = await token("viewer");
facts.roles = Object.fromEntries(
  [["creator", creator], ["other-creator", other], ["viewer", viewer]].map(([n, t]) => [n, (claims(t).realm_access?.roles ?? []).includes("creator")]),
);
const { bytes, body } = fixture();
const start = { ...body, title: "V3-13 upload: test card and tone", description: "A 20 s synthetic 1280×720 test card with a 440 Hz tone." };
const as = (who, t) => ({ who, bearer: t });

// Who is calling.
await api("GET", ME);
await api("GET", ME, as("bad", tampered(creator)));
await api("GET", ME, as("creator", creator));
await api("GET", ME, as("viewer", viewer));

// Who may start.
await api("POST", UPLOADS, { body: start });
await api("POST", UPLOADS, { ...as("bad", tampered(creator)), body: start });
await api("POST", UPLOADS, { ...as("viewer", viewer), body: start });
const started = await api("POST", UPLOADS, { ...as("creator", creator), body: start });
const id = started.body.uploadId;
const path = `${UPLOADS}/${id}`;
const partCount = Math.ceil(bytes.length / PART);

// Part 1, then pause.
const signed1 = await api("POST", `${path}/parts/1`, as("creator", creator));
const etags = { 1: await putPart(signed1.body.url, bytes.subarray(0, PART)) };
log.push({ method: "PUT", path: "<signed URL, part 1>", who: "signed URL", status: 200, body: { etag: etags[1], size: PART } });
await api("POST", `${path}/complete`, as("creator", creator)); // too early: parts missing

// "Refresh": a new sign-in (new token), then the same upload ID's parts from ListParts.
const again = await token("creator");
facts.newTokenDiffers = again !== creator;
const listed = await api("GET", path, as("creator (signed in again)", again));
const have = new Set(listed.body.parts.map((p) => p.partNumber));
facts.resumeSent = [];
for (let n = 1; n <= partCount; n++) {
  if (have.has(n)) continue;
  const part = bytes.subarray((n - 1) * PART, n * PART);
  const signed = await api("POST", `${path}/parts/${n}`, as("creator (signed in again)", again));
  etags[n] = await putPart(signed.body.url, part);
  facts.resumeSent.push(n);
  log.push({ method: "PUT", path: `<signed URL, part ${n}>`, who: "signed URL", status: 200, body: { etag: etags[n], size: part.length } });
}
await api("GET", path, as("creator (signed in again)", again));

// Another creator and a viewer can't see or manage it.
await api("GET", path, as("other-creator", other));
await api("POST", `${path}/parts/1`, as("other-creator", other));
await api("POST", `${path}/complete`, as("other-creator", other));
await api("POST", `${path}/abort`, as("other-creator", other));
await api("GET", UPLOADS, as("other-creator", other));
await api("GET", path, as("viewer", viewer));
await api("GET", path);

// Complete, and complete again (the stored answer).
const completed = await api("POST", `${path}/complete`, as("creator (signed in again)", again));
await api("POST", `${path}/complete`, as("creator (signed in again)", again));
await api("GET", path, as("creator (signed in again)", again));
facts.completed = completed.body;

// A second upload, aborted after part 1: it can't complete.
const second = await api("POST", UPLOADS, { ...as("creator", again), body: { ...start, title: "V3-13 aborted upload" } });
const p2 = `${UPLOADS}/${second.body.uploadId}`;
const s2 = await api("POST", `${p2}/parts/1`, as("creator", again));
await putPart(s2.body.url, bytes.subarray(0, PART));
log.push({ method: "PUT", path: "<signed URL, part 1>", who: "signed URL", status: 200, body: { size: PART } });
await api("POST", `${p2}/abort`, as("creator", again));
await api("POST", `${p2}/complete`, as("creator", again));
await api("POST", `${p2}/parts/2`, as("creator", again));
await api("POST", `${p2}/abort`, as("creator", again));
await api("GET", p2, as("creator", again));
await api("GET", UPLOADS, as("creator", again));
await api("POST", `${UPLOADS}/not-a-uuid/complete`, as("creator", again));
await api("POST", `${path}/parts/9`, as("creator", again));

// The original is private: an anonymous GET of its key is refused by storage.
const objectPort = process.env.LOCAL_OBJECT_PORT;
const key = `upload-api-multipart-uploads/${completed.body.videoId}/${id}/source.mp4`;
const anonymous = await fetch(`http://127.0.0.1:${objectPort}/original-videos/${key}`);
log.push({ method: "GET", path: `<objects>/original-videos/${key}`, who: "anonymous", status: anonymous.status, body: (await anonymous.text()).slice(0, 120) });
facts.uploadId = id;
facts.abortedUploadId = second.body.uploadId;
facts.originalKey = key;
facts.etags = etags;
facts.edge = HTTP;
for (const e of log) console.log(show(e));
console.log(JSON.stringify(facts, null, 2));
mkdirSync(new URL("../runs/", import.meta.url), { recursive: true });
writeFileSync(new URL(`../runs/${label}.json`, import.meta.url), JSON.stringify(sanitize({ facts, log }), null, 2));
