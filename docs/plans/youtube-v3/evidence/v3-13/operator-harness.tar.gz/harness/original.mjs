// Inside app-upload-api: the stored original's size, metadata and SHA-256 of its bytes.
import { GetObjectCommand, HeadObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
const credentials = JSON.parse(readFileSync("/run/secrets/s3-upload-api", "utf8"));
const s3 = new S3Client({ endpoint: "http://local-objects:3900", region: "garage", forcePathStyle: true, credentials: { accessKeyId: credentials.accessKeyId, secretAccessKey: credentials.secretAccessKey } });
const key = process.argv[2];
const head = await s3.send(new HeadObjectCommand({ Bucket: "original-videos", Key: key }));
const object = await s3.send(new GetObjectCommand({ Bucket: "original-videos", Key: key }));
const hash = createHash("sha256");
for await (const chunk of object.Body) hash.update(chunk);
console.log(JSON.stringify({ key, size: head.ContentLength, contentType: head.ContentType, etag: head.ETag, metadata: head.Metadata, sha256: hash.digest("hex") }, null, 2));
