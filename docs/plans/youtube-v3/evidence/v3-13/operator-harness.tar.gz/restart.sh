#!/usr/bin/env bash
# Sync app/src and app/scripts into the outside copy, build, then pnpm stop/start; print health.
set -euo pipefail
export PATH=~/.nvm/versions/node/v24.21.0/bin:$PATH
S=/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v313
APP=/home/ash/github/jeeves/field-projects/youtube/v3/app
rsync -a --delete "$APP/src/" "$S/copy/src/"
rsync -a "$APP/scripts/" "$S/copy/scripts/"
cd "$S/copy"
export COMPOSE_PROJECT_NAME=jeeves-v313-upload LOCAL_HTTP_PORT=45620 LOCAL_IDENTITY_PORT=45621 LOCAL_OBJECT_PORT=45622
pnpm build > "$S/build-$1.log" 2>&1 || { cat "$S/build-$1.log"; exit 1; }
t0=$(date +%s.%N)
pnpm stop > "$S/stop-$1.log" 2>&1
t1=$(date +%s.%N)
pnpm start > "$S/start-$1.log" 2>&1
t2=$(date +%s.%N)
echo "stop $(echo "$t1 - $t0" | bc | cut -c1-5) s, start $(echo "$t2 - $t1" | bc | cut -c1-5) s"
docker ps -a --filter label=com.docker.compose.project=jeeves-v313-upload --format '{{.Names}}' | xargs docker inspect --format '{{.State.Health.Status}} {{.RestartCount}}' | sort | uniq -c
