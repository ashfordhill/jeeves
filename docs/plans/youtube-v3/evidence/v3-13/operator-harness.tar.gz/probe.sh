#!/usr/bin/env bash
export PATH=~/.nvm/versions/node/v24.21.0/bin:$PATH
S=/tmp/claude-1000/-home-ash-github-book-catalogue/719a64af-f36f-424e-bb83-8b8f5999e4ed/scratchpad/v313
cd $S/harness && APP=$S/copy LOCAL_HTTP_PORT=45620 LOCAL_IDENTITY_PORT=45621 FIXTURE=$S/media/youtube-v1-fixture.mp4 node "${2:-probe.mjs}" "$1"
