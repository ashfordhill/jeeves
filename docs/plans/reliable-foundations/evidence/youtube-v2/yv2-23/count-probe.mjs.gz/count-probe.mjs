import {selected,pool} from './dist/features/service-resources.js';
const end=[],s=selected('event-counter'),db=pool({own:f=>end.push(f)},s,'state');
try {const totals=(await db.query('SELECT aggregate_key,total FROM count_private.totals ORDER BY aggregate_key')).rows;const receipts=(await db.query('SELECT scope_key,event_id,handled_at FROM count_private.receipts ORDER BY handled_at')).rows;console.log(JSON.stringify({totals,receipts},null,2));}finally{for(const f of end.reverse())await f();}
