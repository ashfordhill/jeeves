import {loadLocalV2Registry} from '/home/ash/github/jeeves/jeeves-generator/src/index.ts';
import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const registry=loadLocalV2Registry();
const freeze=JSON.parse(readFileSync('/home/ash/github/jeeves/field-projects/youtube/v2/inputs/freeze.json','utf8'));
assert.equal(registry.sha256,freeze.registrySha256);
writeFileSync('/tmp/jeeves-yv2-23/evidence/current-registry.json',JSON.stringify({sha256:registry.sha256,sources:registry.sources.length,implementations:registry.emitters.length,templates:registry.installed.templates.length,exactFrozenDefaultRegistry:true},null,2)+'\n');
console.log('Current default registry matches frozen registry:',registry.sha256);
