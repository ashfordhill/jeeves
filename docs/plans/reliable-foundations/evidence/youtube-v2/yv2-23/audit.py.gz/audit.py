from pathlib import Path
import hashlib,json,subprocess,re
root=Path('/home/ash/github/jeeves');out=Path('/tmp/jeeves-yv2-23/evidence');app=Path('/tmp/jeeves-yv2-23/independent-app');prefix='field-projects/youtube/v2/app/';base='695addeb3ac4a77c3a6fbfd2f68d901fced3619f';final='08699b2dc631709bff12fb25914e0d2681b6b535';inputs=root/'field-projects/youtube/v2/inputs'
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
blob=lambda rev,p:subprocess.check_output(['git','show',rev+':'+p],cwd=root)
pins=json.loads((inputs/'output-path-hashes.json').read_text());freeze=json.loads((inputs/'freeze.json').read_text());m=json.loads((app/'.jeeves/manifest.json').read_text())
for p in pins:
 b=blob(base,prefix+p['path']);assert sha(b)==p['sha256'] and len(b)==p['bytes']
for p in m['registry']['sources']:
 b=(root/p['path']).read_bytes();assert sha(b)==p['sha256'] and len(b)==p['bytes'],p['path']
assert m['registry']['sources']==json.loads((inputs/'registry-sources.json').read_text())
assert m['registry']['sha256']==freeze['registrySha256']
assert sha((inputs/'design.json').read_bytes())==freeze['input']['sourceSha256']
assert sha(canonical(pins))==freeze['outputInventorySha256']
assert sha((app/'.jeeves/manifest.json').read_bytes())==freeze['manifestSha256']
files=[p for p in subprocess.check_output(['git','ls-tree','-r','--name-only',final,'--',prefix],cwd=root).decode().splitlines()];rows=[];imports=0
for p in files:
 rel=p[len(prefix):];b=blob(final,p);assert (app/rel).read_bytes()==b,rel
 before=next((x for x in pins if x['path']==rel),None)
 rows.append({'path':rel,'baselineSha256':before['sha256'] if before else None,'finalSha256':sha(b),'unchanged':before is not None and before['sha256']==sha(b)})
 if rel.startswith('src/') or rel.startswith('.jeeves/') or rel in ['pnpm-lock.yaml','ffmpeg-os.lock']:assert before and before['sha256']==sha(b),rel
 if rel.endswith(('.ts','.mjs')):
  text=b.decode()
  for spec in re.findall(r'''(?:from\s*|import\s*\(\s*|require\s*\(\s*)["']([^"']+)["']''',text):
   imports+=1;assert not spec.startswith(('@jeeves/','/')), (rel,spec)
   if spec.startswith('.'):assert ((app/rel).parent/spec).resolve().is_relative_to(app.resolve())
assert all(not p.is_symlink() for p in app.rglob('*') if not p.is_relative_to(app/'node_modules'))
pkg=json.loads((app/'package.json').read_text())
assert all(re.fullmatch(r'\d+\.\d+\.\d+',v) for group in ['dependencies','devDependencies'] for v in pkg[group].values())
assert all(not v.startswith(('workspace:','link:','file:')) for group in ['dependencies','devDependencies'] for v in pkg[group].values())
# Import reachability: emitted SQL contributors are setup-time imports, never dead-code padding.
sources={p[len(prefix):]:blob(final,p).decode() for p in files if p.startswith(prefix+'src/') and p.endswith('.ts')}
def edges(rel,text):
 for spec in re.findall(r'''(?:from\s*|import\s*\(\s*)["'](\.[^"']+)["']''',text):
  q=((app/rel).parent/spec).resolve().relative_to(app).as_posix();yield q
seen=set();todo=['src/services/youtube.ts']
while todo:
 p=todo.pop()
 if p in seen:continue
 seen.add(p);todo.extend(q for q in edges(p,sources.get(p,'')) if q in sources)
setup_refs={}
for p in set(sources)-seen:
 target=p.replace('src/','dist/').replace('.ts','.js')
 refs=[f[len(prefix):] for f in files if not f.startswith(prefix+'src/') and f.endswith('.mjs') and target in blob(final,f).decode()]
 setup_refs[p]=refs
generator_refs={}
for p in setup_refs:
 if p in ['src/features/positive-cache-bindings.ts','src/features/search-bindings.ts']:
  assert p in json.loads((root/'field-projects/youtube/v2/notes/benchmarks/backend-scope.json').read_text())['configurationPaths']
  continue
 name=p.split('/')[-1]
 refs=[str(f.relative_to(root)) for f in (root/'jeeves-generator/src/v2').glob('*.ts') if not f.name.endswith('.test.ts') and name in f.read_text()]
 assert refs,p
 generator_refs[p]=refs
v1=root/'field-projects/youtube/v1/app/.jeeves/manifest.json';assert sha(v1.read_bytes())=='5098707958077ea90b4ad36118f987069351ace61b6f33251d347144f764e21f'
historical={str(p.relative_to(root)):sha(p.read_bytes()) for p in (root/'field-projects/youtube/v1/notes/benchmarks').glob('*') if p.is_file()}
result={'baselineCommit':base,'completionCommit':final,'allBaseline93PinsMatch':True,'allFinal102TrackedCopyBytesMatch':True,'registrySourcesVerified':len(m['registry']['sources']),'sourceSha256':freeze['input']['sourceSha256'],'registrySha256':m['registry']['sha256'],'manifestSha256':freeze['manifestSha256'],'inventorySha256':freeze['outputInventorySha256'],'backendSourceFilesUnchanged':sum(r['path'].startswith('src/') and r['unchanged'] for r in rows),'metadataFilesUnchanged':sum(r['path'].startswith('.jeeves/') and r['unchanged'] for r in rows),'runtimeImportReachableSourceFiles':len(seen),'notRuntimeImported':sorted(setup_refs),'generationTimeSqlConstructors':generator_refs,'relativeOrExternalPinnedImportsInspected':imports,'dependencyPins':{k:pkg[k] for k in ['dependencies','devDependencies']},'v1HistoricalReportHashes':historical,'customBackendPaths':[],'generatedBackendRepairPaths':[],'allFiles':rows}
(out/'provenance.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k in ['allBaseline93PinsMatch','allFinal102TrackedCopyBytesMatch','registrySourcesVerified','backendSourceFilesUnchanged','metadataFilesUnchanged','runtimeImportReachableSourceFiles','generationTimeSqlConstructors','notRuntimeImported']})
