from pathlib import Path
import subprocess,os,json,hashlib,shutil,socket
out=Path('/tmp/jeeves-yv2-23');app=out/'independent-app';p='jeeves-yv2-23-independent';env=dict(os.environ,COMPOSE_PROJECT_NAME=p,LOCAL_HTTP_PORT='45410',LOCAL_IDENTITY_PORT='45411',LOCAL_OBJECT_PORT='45412');before=json.loads((out/'docker-before.json').read_text())
assert not any(x['Repository'].startswith(p) for x in before['images'])
for f in json.loads((out/'evidence/copy.json').read_text())['files']:
 b=(app/f['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'] and len(b)==f['bytes'],f['path']
with (out/'cleanup.log').open('w') as log:
 subprocess.run(['docker','compose','-p',p,'--profile','*','down','--volumes','--remove-orphans'],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 tags=[p+'-app:latest',p+'-media:latest'];subprocess.run(['docker','image','rm',*tags],stdout=log,stderr=subprocess.STDOUT,check=True)
for command in [['docker','ps','-aq','--filter','label=com.docker.compose.project='+p],['docker','volume','ls','-q','--filter','label=com.docker.compose.project='+p],['docker','network','ls','-q','--filter','label=com.docker.compose.project='+p]]:assert not subprocess.check_output(command).strip()
images=[json.loads(x) for x in subprocess.check_output(['docker','image','ls','--format','json']).decode().splitlines()];assert not any(x['Repository'].startswith(p) for x in images)
for port in [45410,45411,45412]:
 with socket.socket() as s:s.bind(('127.0.0.1',port))
shutil.rmtree(app);assert not app.exists()
(out/'evidence/cleanup.json').write_text(json.dumps({'project':p,'allProfiles':True,'downVolumesRemoveOrphansExit':0,'removedExactOwnImageTags':tags,'remainingOwnContainers':0,'remainingOwnVolumes':0,'remainingOwnNetworks':0,'remainingOwnImageTags':0,'portsFree':[45410,45411,45412],'finalTrackedCopyHashesRechecked':102,'copiedAppRuntimeCredentialsMediaDependenciesBuildRemoved':True,'globalPruneUsed':False},indent=2)+'\n')
print('Exact all-profile project cleanup complete;102sourcehashes retained; own copy/runtime/deps/build/media/secrets removed.')
