from pathlib import Path
import subprocess,os,json
out=Path('/tmp/jeeves-yv2-23');env=dict(os.environ,COMPOSE_PROJECT_NAME='jeeves-yv2-23-independent',LOCAL_HTTP_PORT='45410',LOCAL_IDENTITY_PORT='45411',LOCAL_OBJECT_PORT='45412');id=json.loads((out/'evidence/walkthrough.json').read_text())['ready']['videoId']
for name,service in [('count','app-view-counter'),('cache','app-watch')]:
 r=subprocess.run(['docker','compose','-p','jeeves-yv2-23-independent','--profile','*','exec','-T','-e','VIDEO_ID='+id,service,'node','--input-type=module'],cwd=out/'independent-app',env=env,input=(out/(name+'-probe.mjs')).read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);j=json.loads(r.stdout);(out/'evidence'/(name+'-state.json')).write_bytes(r.stdout)
 if name=='count':assert len(j['receipts'])==2 and str(j['totals'][0]['total'])=='2'
print('Two actual transactional receipts/total2 and separate cached metadata verified.')
