from pathlib import Path
import subprocess,os,json,urllib.request,urllib.error
out=Path('/tmp/jeeves-yv2-23');app=out/'independent-app';r=json.loads((out/'evidence/walkthrough.json').read_text());ready=r['ready'];env=dict(os.environ,COMPOSE_PROJECT_NAME='jeeves-yv2-23-independent',LOCAL_HTTP_PORT='45410',LOCAL_IDENTITY_PORT='45411',LOCAL_OBJECT_PORT='45412')
base=['docker','compose','-p','jeeves-yv2-23-independent','--profile','*','exec','-T']
def probe(name,service,extra):
 cmd=base+sum([['-e',k+'='+v] for k,v in extra.items()],[])+[service,'node','--input-type=module'];result=subprocess.run(cmd,cwd=app,env=env,input=(out/(name+'-probe.mjs')).read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);json.loads(result.stdout);(out/'evidence'/(name+'s.json' if name=='original' else name+'.json')).write_bytes(result.stdout);(out/(name+'-probe.log')).write_bytes(result.stderr)
if not (out/'evidence/originals.json').exists():probe('original','app-upload',{'VIDEO_ID':ready['videoId']})
public=r['publicReady']['body'];print('public paths',public['manifest'],public['thumbnail'])
prefix=public['manifest'].removesuffix('master.m3u8');assert prefix.startswith('videos/')
probe('media','app-transcoder',{'PREFIX':prefix})
original=json.loads((out/'evidence/originals.json').read_text())['original'];url='http://127.0.0.1:45412/originals/'+original['original_key']
try:
 with urllib.request.urlopen(url) as response:status=response.status
except urllib.error.HTTPError as e:status=e.code
assert status==403
(out/'evidence/private-original.json').write_text(json.dumps({'anonymousStatus':status,'originalKey':original['original_key'],'endpointPort':45412},indent=2)+'\n')
print('Actual original fingerprint, HLS inventory/probes and anonymous403 verified.')
