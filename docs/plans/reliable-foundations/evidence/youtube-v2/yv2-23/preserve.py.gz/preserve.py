from pathlib import Path
import subprocess,json,hashlib,stat,urllib.request,gzip
root=Path('/home/ash/github/jeeves');out=Path('/tmp/jeeves-yv2-23');dst=root/'docs/plans/reliable-foundations/evidence/youtube-v2/yv2-23'
original=set(x for x in (out/'status-before.txt').read_bytes().split(b'\0') if x);current=set(x for x in subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=root).split(b'\0') if x);assert original<=current
protected=json.loads((out/'protected-before.json').read_text())
for name,v in protected.items():
 f=root/name;assert f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(f.stat().st_mode)==v['mode'],name
subprocess.run(['python3',str(out/'owner-snapshot.py'),'after'],check=True)
a=json.loads((out/'evidence/owners-before.json').read_text());b=json.loads((out/'evidence/owners-after.json').read_text());assert a==b
assert [len(r['services']) for r in b]==[14,14] and [len(r['volumes']) for r in b]==[6,5]
assert all(s['health']=='healthy' for r in b for s in r['services'])
previous={(r['Repository'],r['Tag']):r['ID'] for r in json.loads((out/'docker-before.json').read_text())['images'] if r['Repository']!='<none>' and r['Tag']!='<none>'}
current={(r['Repository'],r['Tag']):r['ID'] for r in map(json.loads,subprocess.check_output(['docker','image','ls','--format','json']).decode().splitlines()) if r['Repository']!='<none>' and r['Tag']!='<none>'}
assert all(current.get(k)==v for k,v in previous.items())
ffmpeg=json.loads(subprocess.check_output(['docker','image','inspect','jeeves-youtube-v1-ffmpeg:latest']))[0]['Id'];assert ffmpeg=='sha256:1792f4e0fb15896196cf9e3ba3d32ab2804ec27f4f7ab04c62ce050a102d8585'
for f in json.loads((out/'evidence/copy.json').read_text())['files']:
 p=root/'field-projects/youtube/v2/app'/f['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
for p,sha in json.loads((out/'evidence/provenance.json').read_text())['v1HistoricalReportHashes'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==sha
id='2c7c8b08-4633-4a97-8794-672a777f1d3a';project=json.load(urllib.request.urlopen('http://127.0.0.1:4300/api/projects/'+id))['project'];design=json.load(urllib.request.urlopen('http://127.0.0.1:4300/api/projects/'+id+'/design'))['design'];assert project['revision']==design['revision']==2
source=hashlib.sha256(json.dumps(design,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest();assert source=='e118df2fdb6a4f1d05d1ef24962a926eb8c75e4219d45c9a6eccdfe87030a87b'
(dst/'owners-after.json.gz').write_bytes(gzip.compress((out/'evidence/owners-after.json').read_bytes(),mtime=0))
(dst/'preservation.md').write_text(f'''# Final preservation

- All **{len(protected)}** protected owner/v1 path hashes and modes match the pre-unit baseline,
  including dirty owner README/feedback/Unicode deletions/colon variants and e2e-docker mode.
- Owner v1 **14 healthy /6 volumes**, owner v2 **14 healthy /5 volumes**. Before/after credential
  digests, exact volume identities, container IDs, image IDs, fixture SHA/size/mtime and runtime
  permissions match. [Before](owners-before.json), [raw after](owners-after.json.gz),
  [operator source](preserve.py.gz). No owner stop/reset/bootstrap occurred.
- All **{len(previous)}** pre-existing named Docker image tag→ID mappings remain intact. Only two
  independent tags were removed; no force-by-ID delete or global prune.
- Retained FFmpeg image `{ffmpeg}` unchanged; fixture **15,584,953 B** /
  SHA256`1658728175f3a431c9c93107582ad14d4286d6fb3c5253c61f4731d3668aebf9`, mtime unchanged.
- All **102** actual completion app tracked file hashes match08699b2 after checks. All frozen v1
  protected inputs/assets/app and historical benchmark hashes remain unchanged.
- Saved studio project `{id}` retains revision **2** and exact canonical sourceSHA`{source}`.
- Independent exact-project cleanup finished before root check; own outside copy/runtime/media/
  secrets/dependencies/build removed. [Cleanup](cleanup.json).
''')
print('Final preservation:',len(protected),'protected files;',len(previous),'preexisting image tags; owner28services healthy,11volumes unchanged; studio r2/exactsource retained.')
