import {createClient} from 'redis';
import {readSecret} from './dist/runtime/local.js';
const c=createClient({password:readSecret('cache-metadata-cache'),socket:{host:'cache-metadata-cache',port:6379}});await c.connect();
try{const key='ready-video:v1:'+process.env.VIDEO_ID,metadata=JSON.parse(await c.get(key));if('views' in metadata||'total' in metadata)throw Error('Counts cached');console.log(JSON.stringify({key,metadata,ttlSeconds:await c.ttl(key),countsAbsentFromMetadataCache:true},null,2));}finally{c.destroy();}
