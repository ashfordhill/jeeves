from pathlib import Path
import subprocess,json,hashlib,tarfile,io,socket,stat
root=Path('/home/ash/github/jeeves'); out=Path('/tmp/jeeves-yv2-23');app=out/'independent-app';commit='08699b2dc631709bff12fb25914e0d2681b6b535';prefix='field-projects/youtube/v2/app';p='jeeves-yv2-23-independent'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==commit
assert not app.exists()
protected=json.loads(Path('/tmp/jeeves-yv2-22/protected-before.json').read_text())
for name,v in protected.items():
 f=root/name;assert f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==v['sha256'] and stat.S_IMODE(f.stat().st_mode)==v['mode'],name
(out/'protected-before.json').write_text(json.dumps(protected,indent=2)+'\n')
(out/'status-before.txt').write_bytes(subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=root))
containers=json.loads(subprocess.check_output(['docker','inspect',*subprocess.check_output(['docker','ps','-aq']).decode().split()]))
volnames=subprocess.check_output(['docker','volume','ls','-q']).decode().split();volumes=json.loads(subprocess.check_output(['docker','volume','inspect',*volnames]))
netnames=subprocess.check_output(['docker','network','ls','-q']).decode().split();nets=json.loads(subprocess.check_output(['docker','network','inspect',*netnames]))
assert not any(c['Config']['Labels'].get('com.docker.compose.project')==p for c in containers)
assert not any(v['Name'].startswith(p+'_') for v in volumes)
assert not any(n['Name'].startswith(p+'_') for n in nets)
for port in [45410,45411,45412]:
 with socket.socket() as s:s.bind(('127.0.0.1',port))
images=[json.loads(x) for x in subprocess.check_output(['docker','image','ls','--format','json']).decode().splitlines()]
(out/'docker-before.json').write_text(json.dumps({'containers':containers,'volumes':volumes,'networks':nets,'images':images},indent=2)+'\n')
app.mkdir();archive=subprocess.check_output(['git','archive',commit,prefix],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
 for m in t.getmembers():
  if m.isfile():
   rel=m.name[len(prefix)+1:];f=app/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(t.extractfile(m).read());f.chmod(m.mode)
records=[]
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'--',prefix],cwd=root).decode().splitlines():
 rel=path[len(prefix)+1:];b=subprocess.check_output(['git','show',commit+':'+path],cwd=root);f=app/rel;assert f.read_bytes()==b and not f.is_symlink();records.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'evidence/copy.json').write_text(json.dumps({'commit':commit,'method':'git archive tracked files only; each compared to git show','files':records},indent=2)+'\n')
(out/'evidence/allocation.json').write_text(json.dumps({'checkedAt':subprocess.check_output(['date','-u','+%FT%TZ']).decode().strip(),'project':p,'ports':[45410,45411,45412],'app':str(app),'runtime':str(app/'.runtime'),'portsFree':True,'namespaceFree':True,'sourceFiles':len(records),'runtimeCopied':False,'finalOwnerStackUntouched':True},indent=2)+'\n')
print('Protected',len(protected),'files; copied',len(records),'exact tracked files; project and ports free.')
