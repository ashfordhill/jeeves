import {selected,objects} from './dist/features/service-resources.js';
import {GetObjectCommand,ListObjectsV2Command} from '@aws-sdk/client-s3';
import {createHash} from 'node:crypto';
import {mkdtemp,writeFile,rm,mkdir} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {execFileSync} from 'node:child_process';
const client=objects(selected('video-hls')),prefix=process.env.PREFIX,tmp=await mkdtemp('/tmp/yv2-23-media-');
const bytes=async key=>{const r=await client.send(new GetObjectCommand({Bucket:'transcoded',Key:key}));return Buffer.from(await r.Body.transformToByteArray());};
try{
 const marker=JSON.parse(await bytes(prefix+'_complete.json'));
 const objects=(await client.send(new ListObjectsV2Command({Bucket:'transcoded',Prefix:prefix}))).Contents.map(o=>({key:o.Key,size:o.Size,etag:o.ETag}));
 const files=[];
 for(const f of marker.inventory){const b=await bytes(prefix+f.path),sha256=createHash('sha256').update(b).digest('hex');if(b.length!==f.size||sha256!==f.sha256)throw Error('Output inventory differs');const file=join(tmp,f.path);await mkdir(dirname(file),{recursive:true});await writeFile(file,b);files.push({path:f.path,size:b.length,sha256,contentType:f.contentType,...(f.path.endsWith('.m3u8')?{playlist:b.toString()}: {})});}
 const probes={};for(const path of ['360/index.m3u8','720/index.m3u8','thumbnail.jpg'])probes[path]=JSON.parse(execFileSync('ffprobe',['-v','error','-show_streams','-show_format','-of','json',join(tmp,path)],{encoding:'utf8'}));
 console.log(JSON.stringify({marker,objects,files,probes,ffmpegVersion:execFileSync('ffmpeg',['-version'],{encoding:'utf8'}).split('\n')[0],liveEncoderArgvRetained:false,encoderSource:'src/runtime/video-hls.ts (unchanged generated source)',successfulEncoderStderrRetained:false},null,2));
}finally{client.destroy();await rm(tmp,{recursive:true,force:true});}
