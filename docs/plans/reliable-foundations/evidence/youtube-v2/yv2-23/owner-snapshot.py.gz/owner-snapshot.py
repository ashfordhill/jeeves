from pathlib import Path
import hashlib,json,subprocess,sys
records=[]
for version,project in [('v1','jeeves-youtube-v1'),('v2','jeeves-youtube-v2')]:
 app=Path('/home/ash/github/jeeves/field-projects/youtube')/version/'app'
 secret=[(f.name,hashlib.sha256(f.read_bytes()).hexdigest(),f.stat().st_mode&0o777) for f in sorted((app/'.runtime/secrets').glob('*')) if f.is_file()]
 vols=subprocess.check_output(['docker','volume','ls','-q','--filter','label=com.docker.compose.project='+project]).decode().split()
 v=json.loads(subprocess.check_output(['docker','volume','inspect',*vols]))
 cs=subprocess.check_output(['docker','ps','-q','--filter','label=com.docker.compose.project='+project]).decode().split();containers=json.loads(subprocess.check_output(['docker','inspect',*cs]))
 fixture=app/'.runtime/media/youtube-v1-fixture.mp4';data=fixture.read_bytes()
 records.append({'project':project,'credentialSetSha256':hashlib.sha256(json.dumps(secret).encode()).hexdigest(),'volumes':[{k:x[k] for k in ['Name','CreatedAt','Driver','Labels']} for x in v],'services':sorted([{'service':c['Config']['Labels']['com.docker.compose.service'],'health':c['State']['Health']['Status'],'image':c['Image'],'container':c['Id']} for c in containers],key=lambda c:c['service']),'fixture':{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mtimeNs':fixture.stat().st_mtime_ns},'runtimeMode':(app/'.runtime').stat().st_mode&0o777})
Path('/tmp/jeeves-yv2-23/evidence/owners-'+sys.argv[1]+'.json').write_text(json.dumps(records,indent=2)+'\n');print([(r['project'],len(r['services']),len(r['volumes'])) for r in records])
