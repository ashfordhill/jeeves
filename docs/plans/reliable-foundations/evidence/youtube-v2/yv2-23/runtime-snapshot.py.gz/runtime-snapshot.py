from pathlib import Path
import json,subprocess,hashlib,sys
app=Path('/tmp/jeeves-yv2-23/independent-app');p='jeeves-yv2-23-independent'
raw=[]
for f in sorted((app/'.runtime/secrets').glob('*')):
 raw.append([f.name,hashlib.sha256(f.read_bytes()).hexdigest(),f.stat().st_mode&0o777])
volumes=json.loads(subprocess.check_output(['docker','volume','inspect',*subprocess.check_output(['docker','volume','ls','-q','--filter',f'label=com.docker.compose.project={p}']).decode().split()]))
v=[{k:r[k] for k in ['Name','CreatedAt','Driver','Labels']} for r in volumes]
cs=subprocess.check_output(['docker','ps','-q','--filter',f'label=com.docker.compose.project={p}']).decode().split()
containers=json.loads(subprocess.check_output(['docker','inspect',*cs])) if cs else []
s=[{'service':c['Config']['Labels']['com.docker.compose.service'],'health':c['State'].get('Health',{}).get('Status'),'imageId':c['Image']} for c in containers]
r={'credentialSetSha256':hashlib.sha256(json.dumps(raw).encode()).hexdigest(),'credentialFiles':len(raw),'privateParentModes':[(x,(app/x).stat().st_mode&0o777) for x in ['.runtime','.runtime/secrets']],'reviewPasswordModes':[(x,(app/'.runtime/secrets'/x).stat().st_mode&0o777) for x in ['creator_password','other_creator_password']],'volumes':v,'services':sorted(s,key=lambda x:x['service'])}
Path('/tmp/jeeves-yv2-23/evidence/runtime-'+sys.argv[1]+'.json').write_text(json.dumps(r,indent=2)+'\n')
print(sys.argv[1],len(s),'services',len(v),'volumes')
