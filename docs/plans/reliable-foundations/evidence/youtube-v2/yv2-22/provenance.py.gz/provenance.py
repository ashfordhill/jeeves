from pathlib import Path
import json,hashlib,subprocess
r=Path('/home/ash/github/jeeves');a=r/'field-projects/youtube/v2/app';prefix='field-projects/youtube/v2/app/';baseline='695addeb3ac4a77c3a6fbfd2f68d901fced3619f'
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((a.parent/'inputs/output-path-hashes.json').read_text());records=[]
for p in pins:
 original=subprocess.check_output(['git','show',baseline+':'+prefix+p['path']],cwd=r)
 assert len(original)==p['bytes'] and sha(original)==p['sha256'],p['path']
 current=(a/p['path']).read_bytes()
 records.append({'path':p['path'],'baselineSha256':p['sha256'],'finalSha256':sha(current),'status':'unchanged' if current==original else 'modified'})
metadata=[x for x in records if x['path'].startswith('.jeeves/')]
assert all(x['status']=='unchanged' for x in metadata)
assert all(x['status']=='unchanged' for x in records if x['path'].startswith('src/'))
# Include untracked unit sources while refusing ignored dependencies/build/runtime.
allpaths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard',prefix],cwd=r).decode().split('\0')
paths=sorted({x[len(prefix):] for x in allpaths if x})
changed=[]
origins={
 'browser/auth.ts':'browser/auth.ts','browser/main.ts':'browser/main.ts','browser/playback-policy.ts':'browser/playback-policy.ts','browser/search.ts':'browser/search.ts','browser/watch.ts':'browser/watch.ts',
 'public/index.html':'public/index.html','public/style.css':'public/style.css','scripts/build-browser.mjs':'scripts/build-browser.mjs','tsconfig.browser.json':'tsconfig.browser.json','infra/edge/nginx.conf':'infra/edge/nginx.conf'}
old={x['path']:x for x in records}
for path in paths:
 if path in old and old[path]['status']=='unchanged':continue
 value={'path':path,'status':'modified-generated' if path in old else 'new-post-baseline','classification':'reused-ui' if path.startswith(('browser/','public/')) else 'integration','sha256':sha((a/path).read_bytes())}
 if path in old:value['baselineSha256']=old[path]['baselineSha256']
 if path in origins:
  origin='field-projects/youtube/v1/app/'+origins[path];data=(r/origin).read_bytes()
  value.update({'sourceOrigin':origin,'sourceOriginCommit':subprocess.check_output(['git','log','-1','--format=%H','--',origin],cwd=r).decode().strip(),'sourceOriginSha256':sha(data),'exactOriginBytes':data==(a/path).read_bytes()})
 if path in ['browser/auth.ts','public/index.html']:value['additionalClassification']='integration'
 changed.append(value)
res={'format':'jeeves-yv2-22-custom-completion-v1','untouchedBaselineCommit':baseline,'baselineFilesVerifiedAgainstGitAndPins':len(records),'baselineBytes':sum(p['bytes'] for p in pins),'baselineManifestSha256':sha((a/'.jeeves/manifest.json').read_bytes()),'baselineMetadata':metadata,'unchangedGeneratedPaths':[x['path'] for x in records if x['status']=='unchanged'],'modifiedGeneratedPaths':[x['path'] for x in records if x['status']=='modified'],'customBackendPaths':[],'generatedFileRepairPaths':[],'allGeneratedBackendSourceUnchanged':True,'changes':changed,'backendScope':'notes/benchmarks/backend-scope.json','uiScope':['browser/'],'noUIUnderSrc':True,'benchmarkNotRunUntilYV2_23':True}
Path('/tmp/jeeves-yv2-22/evidence/provenance.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({'baseline93GitPinsMatch':True,'metadataUnchanged':len(metadata),'generatedBackendSourceUnchanged':True,'unchangedGeneratedFiles':len(res['unchangedGeneratedPaths']),'modifiedGeneratedFiles':len(res['modifiedGeneratedPaths']),'postBaselineAppChanges':len(changed),'customBackendPaths':[],'generatedFileRepairPaths':[]},indent=2))
