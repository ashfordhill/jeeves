import {readFileSync,writeFileSync,cpSync,mkdirSync,chmodSync} from 'node:fs';
import {randomBytes,createHash} from 'node:crypto';
const app='/home/ash/github/jeeves/field-projects/youtube/v2/app',idp='http://127.0.0.1:45401';
const request=async(path,options={})=>{const r=await fetch(idp+path,options);if(!r.ok)throw Error(`Provision HTTP ${r.status}`);return r.status===204?undefined:await r.json();};
const admin=await request('/realms/master/protocol/openid-connect/token',{method:'POST',body:new URLSearchParams({client_id:'admin-cli',grant_type:'password',username:'admin',password:readFileSync(app+'/.runtime/secrets/identity-admin-identity','utf8').trim()})});
const headers={Authorization:'Bearer '+admin.access_token,'Content-Type':'application/json'};
const role=await request('/admin/realms/identity/roles/creator',{headers});
const users=[];
for(const [name,file] of [['creator','creator_password'],['other-creator','other_creator_password']]){
 const password=randomBytes(24).toString('hex');writeFileSync(app+'/.runtime/secrets/'+file,password,{mode:0o600,flag:'wx'});
 const r=await fetch(idp+'/admin/realms/identity/users',{method:'POST',headers,body:JSON.stringify({username:name,enabled:true,emailVerified:true,firstName:'Local',lastName:'Creator',email:name+'@example.invalid',credentials:[{type:'password',value:password,temporary:false}]})});
 if(r.status!==201)throw Error(`Create ${name}: ${r.status}`);
 const url=r.headers.get('location');const assigned=await fetch(url+'/role-mappings/realm',{method:'POST',headers,body:JSON.stringify([role])});if(!assigned.ok)throw Error('Role assignment failed');users.push({username:name,passwordPath:'.runtime/secrets/'+file,subject:url.split('/').at(-1)});
}
mkdirSync(app+'/.runtime/media',{mode:0o700});
cpSync('/home/ash/github/jeeves/field-projects/youtube/v1/app/.runtime/media/youtube-v1-fixture.mp4',app+'/.runtime/media/youtube-v1-fixture.mp4',{preserveTimestamps:true});
const fixture=readFileSync(app+'/.runtime/media/youtube-v1-fixture.mp4');if(createHash('sha256').update(fixture).digest('hex')!=='1658728175f3a431c9c93107582ad14d4286d6fb3c5253c61f4731d3668aebf9')throw Error('Fixture changed');
writeFileSync('/tmp/jeeves-yv2-22/provision.json',JSON.stringify({users,fixtureBytes:fixture.length},null,2));console.log('Two creator accounts provisioned; passwords private0600; exact retained fixture copied with mtime.');
