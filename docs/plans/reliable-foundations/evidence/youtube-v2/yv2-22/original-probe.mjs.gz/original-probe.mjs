import {selected,objects,pool} from './dist/features/service-resources.js';
import {GetObjectCommand} from '@aws-sdk/client-s3';
import {createHash} from 'node:crypto';
const disposers=[];const s=selected('owned-multipart'),db=pool({own:f=>disposers.push(f)},s,'state'),client=objects(s);
try{
 const row=(await db.query('SELECT upload_id,asset_id,original_key,size,sha256,original_etag FROM asset_private.uploads WHERE asset_id=$1',[process.env.VIDEO_ID])).rows[0];
 const response=await client.send(new GetObjectCommand({Bucket:'originals',Key:row.original_key}));let size=0;const hash=createHash('sha256');for await(const chunk of response.Body){size+=chunk.length;hash.update(chunk);}const sha256=hash.digest('hex');if(size!==15584953||sha256!==row.sha256)throw Error('Original fingerprint differs');
 const assets=(await db.query('SELECT asset_id,state,job_id,attempt_id,queued_at,started_at,ready_at,failure_code,publication_version FROM asset_private.assets ORDER BY created_at')).rows;
 const outbox=(await db.query('SELECT destination,event_id,sent_at,attempts FROM asset_private.outbox ORDER BY created_at')).rows;
 console.log(JSON.stringify({original:{...row,actualBytes:size,actualSha256:sha256,metadata:response.Metadata},assets,outbox},null,2));
}finally{client.destroy();for(const f of disposers.reverse())await f();}
