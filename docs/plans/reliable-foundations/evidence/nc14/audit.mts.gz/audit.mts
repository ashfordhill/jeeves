import {writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {toOpenAITool} from '/home/ash/github/jeeves/packages/providers/src/index.ts';
import {toolDefinitions,INSTRUCTIONS,turnContext} from '/home/ash/github/jeeves/apps/server/src/chat/tools.ts';
import {studioArchitectureExample,validateDesign} from '/home/ash/github/jeeves/packages/spec/src/index.ts';
const result=[];
for(const t of toolDefinitions()){
 const wire=toOpenAITool(t);let properties=0,enums=0,depth=0;
 function walk(s,d){depth=Math.max(depth,d);if(s.type==='object'){properties+=Object.keys(s.properties).length;for(const v of Object.values(s.properties))walk(v,d+1)}if(s.type==='array')walk(s.items,d+1);for(const v of s.anyOf??[])walk(v,d);enums+=(s.enum??[]).length}
 walk(wire.parameters,1);result.push({tool:t.name,properties,enums,depth,bytes:Buffer.byteLength(JSON.stringify(wire))});
}
const hash=x=>createHash('sha256').update(x).digest('hex');
const design=studioArchitectureExample('studio-tinyurl').design;
const beforeSource=execFileSync('git',['show','HEAD:apps/server/src/chat/tools.ts'],{cwd:'/home/ash/github/jeeves',encoding:'utf8'});
const priorInstructions=beforeSource.slice(beforeSource.indexOf('export const INSTRUCTIONS = `')+'export const INSTRUCTIONS = `'.length,beforeSource.indexOf('`;\n\nconst schemas'));
const audit={version:'nc14-review-v1',tools:result,instructionsBytes:Buffer.byteLength(INSTRUCTIONS),tinyurlContextBytes:Buffer.byteLength(turnContext(design,validateDesign(design),[])),toolsHash:hash(JSON.stringify(toolDefinitions())),instructionsHash:hash(INSTRUCTIONS),priorRF06ToolsHash:'170213ff1ad633d3bd139a2ae05d884643ed4551f1b1a269c9314841b0a6ec1d',note:'No live calls. Independent NC14 review leaves instructions/tool schemas and both comparable contexts unchanged. Bytes are not tokens, cost or model quality. Suite execution bundle identity is host-only trust plumbing, not a tool-schema change.'};
const strictTools=toolDefinitions().map(toOpenAITool);const prior=JSON.parse(execFileSync('git',['show','HEAD:docs/plans/reliable-foundations/evidence/nc06/audit.json'],{cwd:'/home/ash/github/jeeves',encoding:'utf8'}));audit.requestComparison={baseline:prior.requestComparison.current,current:{instructions:audit.instructionsBytes,tinyurlContext:audit.tinyurlContextBytes,strictTools:Buffer.byteLength(JSON.stringify(strictTools))},note:'Same retained schema2 TinyURL; actual provider strict wire schemas. UTF-8 bytes, not tokens/cost/quality.'};audit.requestComparison.delta=Object.fromEntries(Object.keys(audit.requestComparison.current).map(k=>[k,audit.requestComparison.current[k]-audit.requestComparison.baseline[k]]));audit.strictToolsHash=hash(JSON.stringify(strictTools));const foundation=studioArchitectureExample('studio-tinyurl-foundation').design;audit.foundation={contextBytes:Buffer.byteLength(turnContext(foundation,validateDesign(foundation),[])),note:'Changed product default, so this v3 contract context is separate from the comparable retained schema2 request.'};
writeFileSync('/tmp/jeeves-nc14-browser/audit.json',JSON.stringify(audit,null,2)+'\n');console.log(JSON.stringify(audit,null,2));
