import { chromium, expect } from '/home/ash/github/jeeves/node_modules/@playwright/test/index.mjs';
import { createStudy, ready, tile } from '/home/ash/github/jeeves/apps/web/e2e/studio.ts';
import { writeFileSync } from 'node:fs';
const browser=await chromium.launch(); const page=await browser.newPage({baseURL:'http://127.0.0.1:4302',viewport:{width:1280,height:800}});let id;
try {
 id=await createStudy(page,'E2E NC14 early');
 await page.getByRole('button',{name:'Collapse chat',exact:true}).click();
 await tile(page,'Links database').click();
 const legacy=page.locator('.studio-legacy-access');
 await expect(legacy.locator('> summary')).toHaveText('Legacy inferred access & writer');
 await expect(legacy).not.toHaveAttribute('open');
 await page.waitForTimeout(400); await page.screenshot({path:'/tmp/jeeves-nc14-browser/1280-source-collapsed-early.png'});
 await legacy.locator('> summary').click(); await expect(page.getByLabel('Legacy inferred writer',{exact:true})).toBeVisible();
 await page.screenshot({path:'/tmp/jeeves-nc14-browser/1280-source-legacy-early.png'});
 await page.getByRole('button',{name:'Expand roles',exact:true}).click(); await ready(page);
 await tile(page,'Create link').click(); await expect(page.locator('.lane-inspector-kind')).toHaveText('API role');
 await page.screenshot({path:'/tmp/jeeves-nc14-browser/1280-api-role-early.png'});
} finally {
 if(id) console.log('cleanup',id,(await page.request.delete(`/api/projects/${id}`)).status());
 await browser.close();
}
