import { narrowReadinessDesign } from '/home/ash/github/jeeves/packages/spec/src/fixtures/nc05-narrow.ts';
import { applyOperations } from '/home/ash/github/jeeves/packages/spec/src/apply.ts';
const d=narrowReadinessDesign(); console.log(JSON.stringify(applyOperations(d,[{op:'updatePlannedConnection',id:'create-store',protocol:'custom-source'}])));
