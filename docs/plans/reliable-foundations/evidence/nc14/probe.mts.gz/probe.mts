import { narrowReadinessDesign } from '/home/ash/github/jeeves/packages/spec/src/fixtures/nc05-narrow.ts';
import { designReadiness } from '/home/ash/github/jeeves/packages/spec/src/design-readiness.ts';
for (const mode of ['protocol','interaction','security','retry','timeout','channel']) {
 const d=narrowReadinessDesign(); const link=d.connections.find(x=>x.id==='create-store')!;
 if(mode==='protocol')link.planned.protocol='Redis';
 if(mode==='interaction')link.planned.interaction='Fire and forget';
 if(mode==='security')link.planned.security='Public';
 if(mode==='timeout')d.architecture!.studio!.connections=[{connection:link.id,settings:{timeoutMs:20000}}];
 if(mode==='retry')d.architecture!.studio!.connections=[{connection:link.id,settings:{retry:{mode:'fixed',attempts:10,delayMs:1000}}}];
 if(mode==='channel')d.architecture!.studio!.connections=[{connection:link.id,settings:{channelUse:'publish'}}];
 const r=designReadiness(d); console.log(JSON.stringify({mode,valid:r.designValidity,contracts:r.contractCompleteness}));
}
