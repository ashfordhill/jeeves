import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const require=createRequire('/home/ash/github/jeeves/package.json');
const {chromium}=require('@playwright/test');
const dir='/tmp/jeeves-fp00/manual'; await fs.mkdir(dir,{recursive:true});
const browser=await chromium.launch({headless:true});
const context=await browser.newContext({viewport:{width:1280,height:800},baseURL:'http://127.0.0.1:4300'});
const page=await context.newPage(); const errors=[];
page.on('pageerror',e=>errors.push({kind:'page',message:String(e)}));
page.on('console',m=>{if(m.type()==='error')errors.push({kind:'console',message:m.text()})});
const json=async path=>{const res=await page.request.get(path);assert.equal(res.ok(),true,path);return res.json()};
const listedBefore=await json('/api/projects');
const before={};
for(const project of listedBefore.projects){before[project.id]={project,design:await json(`/api/projects/${project.id}/design`),blueprint:await json(`/api/projects/${project.id}/blueprint`)}}
await fs.writeFile(`${dir}/owner-before.json`,JSON.stringify({listedBefore,before},null,2));
const ready=()=>page.locator('.lane-canvas .board[data-layout="ready"][data-board="ready"]').waitFor();
const view=()=>page.locator('.lane-canvas .board').evaluate(board=>({camera:board.querySelector('.react-flow__viewport')?.style.transform,mode:board.dataset.mode,tiles:[...board.querySelectorAll('.react-flow__node')].map(el=>({id:el.dataset.id,style:el.getAttribute('style'),class:el.getAttribute('class')})),lines:[...board.querySelectorAll('.react-flow__edge')].map(el=>({id:el.dataset.id,class:el.getAttribute('class'),path:el.querySelector('.react-flow__edge-path')?.getAttribute('d')})),focus:document.querySelector('.lane-focus-status')?.textContent??null}));
const capture=async(name,dialogShot=false)=>{
 const before=await view();
 await page.getByRole('button',{name:'Export diagram',exact:true}).click();
 if(dialogShot)await page.screenshot({path:`${dir}/studio-export-dialog.png`});
 let event=page.waitForEvent('download');await page.getByRole('button',{name:'PNG',exact:true}).click();const png=await event;await png.saveAs(`${dir}/${name}.png`);
 event=page.waitForEvent('download');await page.getByRole('button',{name:'Download capture details'}).click();const detailsDownload=await event;await detailsDownload.saveAs(`${dir}/${name}-capture.json`);
 const details=JSON.parse(await fs.readFile(`${dir}/${name}-capture.json`,'utf8'));
 assert.equal(createHash('sha256').update(await fs.readFile(`${dir}/${name}.png`)).digest('hex'),details.image.sha256);
 await page.getByRole('button',{name:'Close export diagram'}).click();
 assert.deepEqual(await view(),before,`${name} preserved view`);
 assert.equal(await page.locator('.diagram-capture-host').count(),0);
 return {name,filename:png.suggestedFilename(),width:details.image.width,height:details.image.height,sha256:details.image.sha256,tiles:details.tiles.length,lines:details.lines.length,view:before,owners:details.view.owners};
};
const results=[];let scratchId;
try{
 for(const [find,base,focusName] of [['YouTube','youtube','Transcoder'],['TinyURL','tinyurl','Redirect service']]){
  const project=listedBefore.projects.find(p=>p.name.includes(find));assert.ok(project);
  await page.goto(`/?project=${project.id}`);await ready();
  await page.getByRole('button',{name:'Fit',exact:true}).click();await page.waitForTimeout(250);
  await page.locator('.lane-line-legend summary').click();
  await page.screenshot({path:`${dir}/studio-${base}-line-guide.png`});
  await page.locator('.lane-line-legend summary').click();
  await page.screenshot({path:`${dir}/studio-${base}-fit.png`});
  const initial=await capture(base,true);results.push(initial);
  await page.locator('.lane-canvas .board').getByRole('group',{name:focusName,exact:true}).click();
  await page.getByRole('button',{name:'Focus relationships',exact:true}).click();
  await page.getByRole('button',{name:'Fit focus',exact:true}).click();await page.waitForTimeout(250);
  await page.getByRole('button',{name:'Hand',exact:true}).click();const box=await page.locator('.lane-canvas').boundingBox();assert.ok(box);
  await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2-130,box.y+box.height/2+45,{steps:6});await page.mouse.up();await page.mouse.wheel(0,-350);await page.waitForTimeout(150);
  await page.getByRole('button',{name:'Dark mode',exact:true}).click();
  await page.screenshot({path:`${dir}/studio-${base}-focused.png`});
  const after=await capture(`${base}-focused`);results.push(after);assert.equal(after.sha256,initial.sha256,`${base} PNG unchanged by view/theme`);
  await page.getByRole('button',{name:'Dark mode',exact:true}).click();
 }
 // Temporary study for explicit owner projection checks, created and removed by this walkthrough.
 await page.getByRole('button',{name:/^Project:/}).click();await page.getByRole('menuitem',{name:'New project'}).click();await page.getByRole('button',{name:'Choose Architecture study'}).click();await page.getByLabel('Project name').fill('FP00 export evidence (temporary)');await page.getByRole('button',{name:'Create project',exact:true}).click();
 await page.waitForURL(url=>!listedBefore.projects.some(p=>url.searchParams.get('project')===p.id));scratchId=new URL(page.url()).searchParams.get('project');assert.ok(scratchId);await ready();
 const scratchBefore=await json(`/api/projects/${scratchId}/design`);
 await page.screenshot({path:`${dir}/studio-owner-collapsed.png`});results.push(await capture('owner-collapsed'));
 await page.getByRole('button',{name:'Expand roles',exact:true}).click();await ready();await page.waitForTimeout(250);
 await page.screenshot({path:`${dir}/studio-owner-expanded.png`});results.push(await capture('owner-expanded'));
 assert.deepEqual(await json(`/api/projects/${scratchId}/design`),scratchBefore);
}finally{
 if(scratchId){const response=await page.request.delete(`/api/projects/${scratchId}`);assert.equal(response.status(),204)}
 const listedAfter=await json('/api/projects');assert.deepEqual(listedAfter,listedBefore);
 for(const project of listedAfter.projects){assert.deepEqual(await json(`/api/projects/${project.id}/design`),before[project.id].design);assert.deepEqual(await json(`/api/projects/${project.id}/blueprint`),before[project.id].blueprint)}
 assert.deepEqual(errors,[]);
 await fs.writeFile(`${dir}/results.json`,JSON.stringify({viewport:{width:1280,height:800},browser:browser.version(),results,errors,ownerListingUnchanged:true,ownerDesignHistoryBlueprintUnchanged:true,scratchDeleted:scratchId},null,2));
 await fs.writeFile(`${dir}/owner-after.json`,JSON.stringify(listedAfter,null,2));
 await browser.close();
}
console.log(results.map(x=>({name:x.name,size:`${x.width}x${x.height}`,tiles:x.tiles,lines:x.lines,hash:x.sha256})));console.log('Owner sources/history/blueprints/list unchanged; zero errors; scratch deleted');
