# Inventory reuse study — implementation brief

Schema: jeeves.architecture-handoff v1. Project: 681356e6-222b-41bd-acc2-6a59b207b072. Revision: 5.

Design fingerprint: d9f4d9daf386cd06b8ad8d7af10ec90d6f3c10dabd97bd7665bd2e1ad7e48ce1

**Ready for implementation review**

Architecture intent and implementation review only. Objectives are unverified targets. Approval of partial scope never activates partial generation. No runtime verification is inherited from patterns, templates or source projects.
Portable definitions omit opaque runtime configuration, local paths and example/default values. Pinned source hashes identify the original manifests, before sanitization.

[Portable definitions and exact identities](./architecture-handoff.json)

[Selected diagram](./architecture-diagram.svg)

View: Inventory reuse study. Layout fingerprint: 37e35527fddad90f0f71a0d54adc7c8c72eae5f67bbef509574e8716b7dba3f4.

<a id="scope"></a>
## Scope and actors

Functional contracts and component implementation
Editable architecture intent. No implementation or verification is inherited.
- member: Inventory operator — Acts inside an authorized tenant workspace.
Excluded scope: Production sizing, SLO, recovery and commercial acceptance
Explicit approval: Approve functional scope; production objectives remain excluded and assigned.

<a id="coverage"></a>
## Implementation coverage

| Identity | Category | Version | Available | Boundary | Behavior |
| --- | --- | --- | --- | --- | --- |
| api | planned | — | no | application-api | A cohesive application boundary for domain operations and access rules. |
| worker | planned | — | no | background-worker | Consumes jobs or events outside the request path. |
| db | planned | — | no | relational-store | Transactional records with explicit consistency, ownership and recovery goals. |
| delivery-channel | planned | — | no | job-queue | A named logical work queue. Broker instances and clusters belong in deployment. |
| web | planned | — | no | browser-client | Browser experience connected to your application APIs. |
| tenant-workspace | planned | — | no | organizations-module | Workspace membership |
| tenant-access | planned | — | no | domain-module | Tenant access checks Resolves authenticated session or API-key principal, reads current tenant membership/key status and authorizes each API, persistence, job and export action. Network privacy supplies no authorization. |
| delivery-producer | planned | — | no | domain-module | Domain change |
| delivery-handler | planned | — | no | event-handlers-module | Idempotent work handler |
| delivery-atomic-writer | planned | — | no | domain-module | Atomic domain and event writer |
| delivery-delivery | planned | — | no | domain-module | Outbox delivery responsibility |
| library | planned | — | no | screen-group | Creation, editing, version history and explicit loading, success, denial and failure states. |
| report-screens | planned | — | no | screen-group | Authorized reporting, deletion requests and expiring export downloads. |
| settings-screens | planned | — | no | screen-group | Tenant membership, principal revocation and export access decisions. |
| records | planned | — | no | domain-module | Tenant-owned stock changes and durable event intent. |
| reporting | planned | — | no | data-lifecycle-module | Tenant-authorized queries, exports, deletion, retention and recovery coordination. |
| audit | planned | — | no | audit-log-module | Records staff and tenant security changes without storing API keys or raw IP addresses. |
| export-jobs | planned | — | no | reports-module | Recheck tenant access and revocation at execution and download; cancel revoked jobs and expire export objects. |
| container:api | custom | — | no | tenant-access-contract@v1, tenant-access-contract@v1, tenant-workspace-records@v1, delivery-atomic-commit@v2, delivery-atomic-commit@v2, delivery-domain-records@v1, delivery-outbox-records@v2, manage-records@v1, tenant-access-contract@v1, tenant-access-contract@v1, delivery-atomic-commit@v2, delivery-atomic-commit@v2, report-contract@v1, tenant-access-contract@v1, tenant-access-contract@v1, remote-access@v1, audit-records@v1, reports-records@v1, member-command@v1, job-command@v1, remote-access@v1, reports-records@v1 | Owns tenant-authorized product operations and authoritative state. |
| container:worker | custom | — | no | delivery-outbox-records@v2, delivery-outbox-records@v2, delivery-work-event@v2, delivery-work-event@v2, remote-access@v1, job-command@v1, export-records@v1, remote-access@v1, reports-records@v1, reports-records@v1 | Checks tenant scope again before reports, exports and delivery. |
| container:db | custom | — | no | tenant-workspace-records@v1, delivery-domain-records@v1, delivery-outbox-records@v2, delivery-outbox-records@v2, delivery-outbox-records@v2, audit-records@v1, reports-records@v1, export-records@v1, reports-records@v1, reports-records@v1, reports-records@v1 | Authoritative tenant records and product data; shared scoped storage. |
| container:delivery-channel | custom | — | no | delivery-work-event@v2, delivery-work-event@v2 | Logical job-queue with explicit responsibility and editable policies. |
| container:web | custom | — | no | manage-records@v1, report-contract@v1, member-command@v1 | Signed-in feature areas using exact tenant-scoped API contracts. |
| responsibility:tenant-workspace | custom | — | no | tenant-access-contract@v1, tenant-workspace-records@v1, member-command@v1 | Workspace membership |
| responsibility:tenant-access | custom | — | no | tenant-access-contract@v1, tenant-access-contract@v1, tenant-access-contract@v1, remote-access@v1, remote-access@v1 | Tenant access checks Resolves authenticated session or API-key principal, reads current tenant membership/key status and authorizes each API, persistence, job and export action. Network privacy supplies no authorization. |
| responsibility:delivery-producer | custom | — | no | delivery-atomic-commit@v2 | Domain change |
| responsibility:delivery-atomic-writer | custom | — | no | delivery-atomic-commit@v2, delivery-domain-records@v1, delivery-outbox-records@v2, delivery-atomic-commit@v2 | Atomic domain and event writer |
| responsibility:records | custom | — | no | manage-records@v1, tenant-access-contract@v1, delivery-atomic-commit@v2 | Tenant-owned stock changes and durable event intent. |
| responsibility:reporting | custom | — | no | report-contract@v1, tenant-access-contract@v1, reports-records@v1, job-command@v1, reports-records@v1 | Tenant-authorized queries, exports, deletion, retention and recovery coordination. |
| responsibility:audit | custom | — | no | audit-records@v1 | Records staff and tenant security changes without storing API keys or raw IP addresses. |
| responsibility:delivery-handler | custom | — | no | delivery-work-event@v2, remote-access@v1, reports-records@v1 | Idempotent work handler |
| responsibility:delivery-delivery | custom | — | no | delivery-outbox-records@v2, delivery-outbox-records@v2, delivery-work-event@v2 | Outbox delivery responsibility |
| responsibility:export-jobs | custom | — | no | remote-access@v1, job-command@v1, export-records@v1, reports-records@v1 | Recheck tenant access and revocation at execution and download; cancel revoked jobs and expire export objects. |
| responsibility:library | custom | — | no | manage-records@v1 | Creation, editing, version history and explicit loading, success, denial and failure states. |
| responsibility:report-screens | custom | — | no | report-contract@v1 | Authorized reporting, deletion requests and expiring export downloads. |
| responsibility:settings-screens | custom | — | no | member-command@v1 | Tenant membership, principal revocation and export access decisions. |

<a id="responsibilities"></a>
## C2 and C3 responsibilities

- api: Application API (Application) — Owns tenant-authorized product operations and authoritative state.
- worker: Background worker (Application) — Checks tenant scope again before reports, exports and delivery.
- db: Primary data (Data store) — Authoritative tenant records and product data; shared scoped storage.
- delivery-channel: Stock delivery: Stock changes (Data store) — Logical job-queue with explicit responsibility and editable policies.
- web: Inventory workspace (Application) — Signed-in feature areas using exact tenant-scoped API contracts.
- tenant-workspace inside api: Tenant access: Workspace membership — Workspace membership
- tenant-access inside api: Tenant access: Tenant access checks — Tenant access checks Resolves authenticated session or API-key principal, reads current tenant membership/key status and authorizes each API, persistence, job and export action. Network privacy supplies no authorization.
- delivery-producer inside api: Stock delivery: Domain change — Domain change
- delivery-handler inside worker: Stock delivery: Idempotent work handler — Idempotent work handler
- delivery-atomic-writer inside api: Stock delivery: Atomic domain and event writer — Atomic domain and event writer
- delivery-delivery inside worker: Stock delivery: Outbox delivery responsibility — Outbox delivery responsibility
- library inside web: Stock workspace — Creation, editing, version history and explicit loading, success, denial and failure states.
- report-screens inside web: Analytics and exports — Authorized reporting, deletion requests and expiring export downloads.
- settings-screens inside web: Team and access settings — Tenant membership, principal revocation and export access decisions.
- records inside api: Stock commands — Tenant-owned stock changes and durable event intent.
- reporting inside api: Reporting and data lifecycle — Tenant-authorized queries, exports, deletion, retention and recovery coordination.
- audit inside api: Security audit — Records staff and tenant security changes without storing API keys or raw IP addresses.
- export-jobs inside worker: Authorized exports and recovery — Recheck tenant access and revocation at execution and download; cancel revoked jobs and expire export objects.

<a id="relationships"></a>
## Authored relationships

- C1 member-system: member → system — Manages tenant-owned records; container web.
- C2 tenant-save-membership: api → db — Reads / writes authoritative data; SQL; planned.
- C2 delivery-read-intent: worker → db — Reads / writes authoritative data; SQL; planned.
- C2 delivery-publish-work: worker → delivery-channel — Publishes durable event intent; Channel protocol; planned.
- C2 manage-edge: web → api — Uses tenant product APIs; HTTPS/JSON; planned.
- C2 export-access-edge: worker → api — Check current tenant and principal remotely; HTTPS/JSON; planned.
- C2 export-job-edge: api → worker — Authorize export execution; HTTPS/JSON; planned.
- C3 tenant-check-access: tenant-workspace → tenant-access — Checks tenant and principal access; In process.
- C3 delivery-commit-domain-event: delivery-producer → delivery-atomic-writer — Commits domain change and event intent atomically; In process.
- C3 record-access-edge: records → tenant-access — Tenant access: Check workspace access; In process.
- C3 stock-commit-edge: records → delivery-atomic-writer — Stock delivery: Commit domain change and event intent atomically; In process.
- C3 report-access-edge: reporting → tenant-access — Tenant access: Check workspace access; In process.

<a id="contracts"></a>
## Contracts, interfaces and bindings

- tenant-access-contract@v1: Tenant access: Check workspace access (in-process, resolved); resolved shape in [JSON](./architecture-handoff.json).
- tenant-workspace-records@v1: Tenant access: Workspace membership records (data, resolved); resolved shape in [JSON](./architecture-handoff.json).
- delivery-domain-records@v1: Stock delivery: Domain state (data, resolved); resolved shape in [JSON](./architecture-handoff.json).
- delivery-work-event@v2: Stock delivery: Stock changes event (event, resolved); resolved shape in [JSON](./architecture-handoff.json).
- delivery-atomic-commit@v2: Stock delivery: Commit domain change and event intent atomically (in-process, resolved); resolved shape in [JSON](./architecture-handoff.json).
- delivery-outbox-records@v2: Stock delivery: Durable event intent (data, resolved); resolved shape in [JSON](./architecture-handoff.json).
- manage-records@v1: Change stock (api, resolved); resolved shape in [JSON](./architecture-handoff.json).
- report-contract@v1: Query, export or delete tenant analytics (api, resolved); resolved shape in [JSON](./architecture-handoff.json).
- remote-access@v1: Check current tenant and principal remotely (api, resolved); resolved shape in [JSON](./architecture-handoff.json).
- audit-records@v1: Redacted security audit (data, resolved); resolved shape in [JSON](./architecture-handoff.json).
- reports-records@v1: Tenant reporting and deletion state (data, resolved); resolved shape in [JSON](./architecture-handoff.json).
- member-command@v1: Invite, restrict or revoke access (api, resolved); resolved shape in [JSON](./architecture-handoff.json).
- job-command@v1: Authorize export execution (api, resolved); resolved shape in [JSON](./architecture-handoff.json).
- export-records@v1: Expiring authorized exports (data, resolved); resolved shape in [JSON](./architecture-handoff.json).
- tenant-check-access-provided: provided/required, owner tenant-access, tenant-access-contract@v1
- tenant-check-access-required: required/required, owner tenant-workspace, tenant-access-contract@v1
- tenant-save-membership-provided: provided/required, owner db, tenant-workspace-records@v1
- tenant-save-membership-required: required/required, owner tenant-workspace, tenant-workspace-records@v1
- delivery-commit-domain-event-provided: provided/required, owner delivery-atomic-writer, delivery-atomic-commit@v2
- delivery-commit-domain-event-required: required/required, owner delivery-producer, delivery-atomic-commit@v2
- delivery-persist-domain-provided: provided/required, owner db, delivery-domain-records@v1
- delivery-persist-domain-required: required/required, owner delivery-atomic-writer, delivery-domain-records@v1
- delivery-persist-intent-provided: provided/required, owner db, delivery-outbox-records@v2
- delivery-persist-intent-required: required/required, owner delivery-atomic-writer, delivery-outbox-records@v2
- delivery-read-intent-provided: provided/required, owner db, delivery-outbox-records@v2
- delivery-read-intent-required: required/required, owner delivery-delivery, delivery-outbox-records@v2
- delivery-record-progress-provided: provided/required, owner db, delivery-outbox-records@v2
- delivery-record-progress-required: required/required, owner delivery-delivery, delivery-outbox-records@v2
- delivery-publish-work-provided: provided/required, owner delivery-delivery, delivery-work-event@v2
- delivery-publish-work-required: required/required, owner delivery-channel, delivery-work-event@v2
- delivery-consume-work-provided: provided/required, owner delivery-channel, delivery-work-event@v2
- delivery-consume-work-required: required/required, owner delivery-handler, delivery-work-event@v2
- manage-provided: provided/required, owner records, manage-records@v1
- manage-required: required/required, owner library, manage-records@v1
- record-access-provided: provided/required, owner tenant-access, tenant-access-contract@v1
- record-access-required: required/required, owner records, tenant-access-contract@v1
- stock-commit-provided: provided/required, owner delivery-atomic-writer, delivery-atomic-commit@v2
- stock-commit-required: required/required, owner records, delivery-atomic-commit@v2
- reports-provided: provided/required, owner reporting, report-contract@v1
- reports-required: required/required, owner report-screens, report-contract@v1
- report-access-provided: provided/required, owner tenant-access, tenant-access-contract@v1
- report-access-required: required/required, owner reporting, tenant-access-contract@v1
- export-access-provided: provided/required, owner tenant-access, remote-access@v1
- export-access-required: required/required, owner export-jobs, remote-access@v1
- audit-write-provided: provided/required, owner db, audit-records@v1
- audit-write-required: required/required, owner audit, audit-records@v1
- reports-write-provided: provided/required, owner db, reports-records@v1
- reports-write-required: required/required, owner reporting, reports-records@v1
- members-provided: provided/required, owner tenant-workspace, member-command@v1
- members-required: required/required, owner settings-screens, member-command@v1
- export-job-provided: provided/required, owner export-jobs, job-command@v1
- export-job-required: required/required, owner reporting, job-command@v1
- export-write-provided: provided/required, owner db, export-records@v1
- export-write-required: required/required, owner export-jobs, export-records@v1
- worker-access-provided: provided/required, owner tenant-access, remote-access@v1
- worker-access-required: required/required, owner delivery-handler, remote-access@v1
- aggregate-write-provided: provided/required, owner db, reports-records@v1
- aggregate-write-required: required/required, owner delivery-handler, reports-records@v1
- aggregate-query-provided: provided/required, owner db, reports-records@v1
- aggregate-query-required: required/required, owner reporting, reports-records@v1
- aggregate-export-provided: provided/required, owner db, reports-records@v1
- aggregate-export-required: required/required, owner export-jobs, reports-records@v1
- tenant-check-access-binding: Tenant access: Checks tenant and principal access, tenant-check-access-provided → tenant-check-access-required, tenant-access-contract@v1, tenant-check-access; request/Synchronous; operation whole contract; transport In process. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"}}
- tenant-save-membership-binding: Tenant access: Persists workspace membership, tenant-save-membership-provided → tenant-save-membership-required, tenant-workspace-records@v1, tenant-save-membership; write/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"}}
- delivery-commit-domain-event-binding: Stock delivery: Commits domain change and event intent atomically, delivery-commit-domain-event-provided → delivery-commit-domain-event-required, delivery-atomic-commit@v2, delivery-commit-domain-event; request/Synchronous; operation whole contract; transport In process. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"}}
- delivery-persist-domain-binding: Stock delivery: Writes domain state in shared transaction, delivery-persist-domain-provided → delivery-persist-domain-required, delivery-domain-records@v1, tenant-save-membership; write/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"}}
- delivery-persist-intent-binding: Stock delivery: Writes event intent in same transaction, delivery-persist-intent-provided → delivery-persist-intent-required, delivery-outbox-records@v2, tenant-save-membership; write/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"}}
- delivery-read-intent-binding: Stock delivery: Reads undelivered event intent, delivery-read-intent-provided → delivery-read-intent-required, delivery-outbox-records@v2, delivery-read-intent; read/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"}}
- delivery-record-progress-binding: Stock delivery: Records delivery progress after acknowledgement, delivery-record-progress-provided → delivery-record-progress-required, delivery-outbox-records@v2, delivery-read-intent; write/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"}}
- delivery-publish-work-binding: Stock delivery: Publishes durable event intent, delivery-publish-work-provided → delivery-publish-work-required, delivery-work-event@v2, delivery-publish-work; publish/Asynchronous; operation whole contract; transport Channel protocol. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"delivery":{"acknowledgement":"Persisted","guarantee":"At least once","ordering":"Per key"},"failure":{"detail":"Retain undelivered intent for explicit retry/recovery; no atomicity is inferred from the queue.","outcome":"Buffer","timeoutMs":5000},"retry":{"idempotency":"Required","key":"tenantId + eventId","maxAttempts":5}}
- delivery-consume-work-binding: Stock delivery: Consumes named work channel, delivery-consume-work-provided → delivery-consume-work-required, delivery-work-event@v2, delivery-publish-work; consume/Asynchronous; operation whole contract; transport Channel protocol. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"delivery":{"acknowledgement":"Persisted","guarantee":"At least once","ordering":"Per key"},"failure":{"detail":"Retain undelivered intent for explicit retry/recovery; no atomicity is inferred from the queue.","outcome":"Buffer","timeoutMs":5000},"retry":{"idempotency":"Required","key":"tenantId + eventId","maxAttempts":5}}
- manage: Change stock, manage-provided → manage-required, manage-records@v1, manage-edge; request/Synchronous; operation manage-records-operation; transport HTTPS/JSON. Policies: {"access":{"identity":"User","network":"Public","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- record-access: Tenant access: Check workspace access, record-access-provided → record-access-required, tenant-access-contract@v1, record-access-edge; request/Synchronous; operation check-access; transport In process. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- stock-commit: Stock delivery: Commit domain change and event intent atomically, stock-commit-provided → stock-commit-required, delivery-atomic-commit@v2, stock-commit-edge; request/Synchronous; operation commit-domain-event; transport In process. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- reports: Query, export or delete tenant analytics, reports-provided → reports-required, report-contract@v1, manage-edge; request/Synchronous; operation report-contract-operation; transport HTTPS/JSON. Policies: {"access":{"identity":"User","network":"Public","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- report-access: Tenant access: Check workspace access, report-access-provided → report-access-required, tenant-access-contract@v1, report-access-edge; request/Synchronous; operation check-access; transport In process. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- export-access: Check current tenant and principal remotely, export-access-provided → export-access-required, remote-access@v1, export-access-edge; request/Synchronous; operation remote-access-operation; transport HTTPS/JSON. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- audit-write: Redacted security audit, audit-write-provided → audit-write-required, audit-records@v1, tenant-save-membership; write/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- reports-write: Tenant reporting and deletion state, reports-write-provided → reports-write-required, reports-records@v1, tenant-save-membership; write/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- members: Invite, restrict or revoke access, members-provided → members-required, member-command@v1, manage-edge; request/Synchronous; operation member-command-operation; transport HTTPS/JSON. Policies: {"access":{"identity":"User","network":"Public","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- export-job: Authorize export execution, export-job-provided → export-job-required, job-command@v1, export-job-edge; request/Synchronous; operation job-command-operation; transport HTTPS/JSON. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- export-write: Expiring authorized exports, export-write-provided → export-write-required, export-records@v1, delivery-read-intent; write/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- worker-access: Check current tenant and principal remotely, worker-access-provided → worker-access-required, remote-access@v1, export-access-edge; request/Synchronous; operation remote-access-operation; transport HTTPS/JSON. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- aggregate-write: Tenant reporting and deletion state, aggregate-write-provided → aggregate-write-required, reports-records@v1, delivery-read-intent; write/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- aggregate-query: Tenant reporting and deletion state, aggregate-query-provided → aggregate-query-required, reports-records@v1, tenant-save-membership; read/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}
- aggregate-export: Tenant reporting and deletion state, aggregate-export-provided → aggregate-export-required, reports-records@v1, delivery-read-intent; read/Synchronous; operation whole contract; transport SQL. Policies: {"access":{"identity":"Service","network":"Private","tenant":"Tenant scoped"},"failure":{"detail":"Fail closed, expose a retryable error, and never return another tenant's data. Illustrative timeout only.","outcome":"Fail request","timeoutMs":500}}

<a id="data"></a>
## Data ownership, policies and unverified objectives

- Requirement tenant-access-required: {"binding":"worker-access","id":"tenant-access-required","identity":"Service","kind":"access","name":"Worker authorization is tenant scoped","tenant":"Tenant scoped"}
- Requirement delivery-required: {"binding":"delivery-consume-work-binding","channel":"delivery-channel","id":"delivery-required","kind":"delivery","name":"Named work handler owns delivery","responsible":{"id":"delivery-handler","kind":"component"},"trigger":"Channel"}
- Requirement owner-access-required: {"binding":"manage","id":"owner-access-required","identity":"User","kind":"access","name":"Owner operations require tenant authorization","tenant":"Tenant scoped"}
- tenant-workspaces: Tenant access: Workspace authority, authority tenant-workspace, store db, tenant-workspace-records@v1; {"contract":{"id":"tenant-workspace-records","version":"v1"},"deletion":"Delete","exportAccess":"Tenant admin","id":"tenant-workspaces","name":"Tenant access: Workspace authority","owners":&#91;{"id":"tenant-workspace","kind":"component"}&#93;,"ownershipDecision":"","readers":&#91;{"id":"tenant-workspace","kind":"component"}&#93;,"retentionDays":90,"store":"db","tenant":"Tenant scoped","writers":&#91;{"id":"tenant-workspace","kind":"component"}&#93;}
- delivery-domain-state: Stock delivery: Domain authority, authority delivery-atomic-writer, store db, delivery-domain-records@v1; {"contract":{"id":"delivery-domain-records","version":"v1"},"deletion":"Delete","exportAccess":"Tenant admin","id":"delivery-domain-state","name":"Stock delivery: Domain authority","owners":&#91;{"id":"delivery-atomic-writer","kind":"component"}&#93;,"ownershipDecision":"","readers":&#91;{"id":"delivery-atomic-writer","kind":"component"}&#93;,"retentionDays":90,"store":"db","tenant":"Tenant scoped","writers":&#91;{"id":"delivery-atomic-writer","kind":"component"}&#93;}
- delivery-event-intent: Stock delivery: Outbox event intent, authority delivery-atomic-writer, store db, delivery-outbox-records@v2; {"contract":{"id":"delivery-outbox-records","version":"v2"},"deletion":"Delete","exportAccess":"Tenant admin","id":"delivery-event-intent","name":"Stock delivery: Outbox event intent","owners":&#91;{"id":"delivery-atomic-writer","kind":"component"}&#93;,"ownershipDecision":"","readers":&#91;{"id":"delivery-atomic-writer","kind":"component"},{"id":"delivery-delivery","kind":"component"}&#93;,"retentionDays":90,"store":"db","tenant":"Tenant scoped","writers":&#91;{"id":"delivery-atomic-writer","kind":"component"},{"id":"delivery-delivery","kind":"component"}&#93;}
- audit-dataset: Redacted security audit, authority audit, store db, audit-records@v1; {"contract":{"id":"audit-records","version":"v1"},"deletion":"Delete","exportAccess":"Tenant admin","id":"audit-dataset","name":"Redacted security audit","owners":&#91;{"id":"audit","kind":"component"}&#93;,"ownershipDecision":"This responsibility owns writes; other access requires an explicit binding and tenant check.","readers":&#91;{"id":"audit","kind":"component"}&#93;,"retentionDays":365,"store":"db","tenant":"Tenant scoped","writers":&#91;{"id":"audit","kind":"component"}&#93;}
- reports-dataset: Tenant reporting and deletion state, authority reporting, store db, reports-records@v1; {"contract":{"id":"reports-records","version":"v1"},"deletion":"Delete","exportAccess":"Tenant admin","id":"reports-dataset","name":"Tenant reporting and deletion state","owners":&#91;{"id":"reporting","kind":"component"}&#93;,"ownershipDecision":"This responsibility owns writes; other access requires an explicit binding and tenant check.","readers":&#91;{"id":"reporting","kind":"component"},{"id":"export-jobs","kind":"component"}&#93;,"retentionDays":90,"store":"db","tenant":"Tenant scoped","writers":&#91;{"id":"reporting","kind":"component"},{"id":"delivery-handler","kind":"component"}&#93;}
- export-dataset: Expiring authorized exports, authority export-jobs, store db, export-records@v1; {"contract":{"id":"export-records","version":"v1"},"deletion":"Delete","exportAccess":"Tenant admin","id":"export-dataset","name":"Expiring authorized exports","owners":&#91;{"id":"export-jobs","kind":"component"}&#93;,"ownershipDecision":"This responsibility owns writes; other access requires an explicit binding and tenant check.","readers":&#91;{"id":"export-jobs","kind":"component"}&#93;,"retentionDays":7,"store":"db","tenant":"Tenant scoped","writers":&#91;{"id":"export-jobs","kind":"component"}&#93;}
- production-recovery: Unspecified production recovery objective — UNVERIFIED TARGET undecided ; Authoritative store restored, deletion tombstones reapplied, tenant access re-enabled; owner: operations; Production value and measurement window require owner decision

<a id="scenarios"></a>
## Scenarios and acceptance expectations

### create-edit: Commit stock change

Actor: member. Start: Authorized owner edits a versioned record.. Review: Needs review.
- Main path
  - submit: Submit tenant-owned revision (manage-edge, binding manage)
  - authorize: Check tenant and principal (manage-edge, binding manage)
  - persist: Atomic writer persists stock state and matching event intent (tenant-save-membership, binding delivery-persist-domain-binding)
  - atomic: Commit stock state and event intent atomically (tenant-save-membership, binding delivery-persist-domain-binding)
  - response: Return committed identity and version (manage-edge, binding manage)
- Denied or dependency unavailable
  - denied: Deny revoked or foreign tenant access (manage-edge, binding manage)
- Expected success: Stock and event intent commit together; downstream delivery can recover.; invariants: Authored expectation only; no execution evidence.; decisions stable-identity, tenant-revocation; requirements 
- Expected failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; invariants: Do not cross tenant boundaries or invent success.; decisions stable-identity, tenant-revocation; requirements 
### membership: Invite, restrict a member or revoke an API key

Actor: member. Start: Tenant administrator changes membership or API-key status.. Review: Needs review.
- Main path
  - invite: Check administrator and persist membership revision (manage-edge, binding members)
  - worker: Recheck access on worker job execution (export-access-edge, binding worker-access)
  - export: Recheck access at export execution and download (export-access-edge, binding export-access)
- Denied or dependency unavailable
  - deny: Deny unauthorized membership change (manage-edge, binding members)
- Expected success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; invariants: Authored expectation only; no execution evidence.; decisions tenant-revocation; requirements tenant-access-required
- Expected failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; invariants: Do not cross tenant boundaries or invent success.; decisions tenant-revocation; requirements tenant-access-required
### analytics-lifecycle: Query, export, delete analytics and recover

Actor: member. Start: Authorized tenant requests reporting or deletion; operations may restore state.. Review: Needs review.
- Main path
  - query: Authorize tenant report request (manage-edge, binding reports)
  - access: Check current access before data selection (manage-edge, binding reports)
  - job: Run authorized export or deletion job (export-job-edge, binding export-job)
  - recheck: Recheck authorization before download (export-access-edge, binding export-access)
  - objects: Expire export objects or apply deletion tombstones (delivery-read-intent, binding export-write)
  - result: Return freshness and authorized expiring result (manage-edge, binding reports)
- Denied or dependency unavailable
  - fail: Expose incomplete report or denied access (manage-edge, binding reports)
- Delete tenant analytics
  - delete-access: Recheck authorization; cancel pending exports (export-access-edge, binding export-access)
  - delete-data: Persist deletion tombstone and delete/anonymize tenant reporting data (tenant-save-membership, binding reports-write)
  - delete-objects: Delete objects and invalidate all download references (delivery-read-intent, binding export-write)
- Restore and reconcile
  - restore: Operations restores tenant authority and reapplies deletion tombstones before access (tenant-save-membership, binding reports-write)
  - reconcile: Reconcile retained events and expose unrecoverable visit gaps (tenant-save-membership, binding aggregate-query)
  - authorize-restored: Recheck current tenant authorization before restored data is accessible (export-access-edge, binding export-access)
- Expected success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; invariants: Authored expectation only; no execution evidence.; decisions report-lifecycle, production-objectives, tenant-revocation; requirements 
- Expected failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery.; invariants: Do not cross tenant boundaries or invent success.; decisions report-lifecycle, production-objectives, tenant-revocation; requirements 

<a id="decisions"></a>
## Decisions and unresolved work

- hosted-first (Accepted): Hosted first; growth remains optional — Illustrative architecture study; product owner and implementation review must confirm this choice. Decision: One hosted modular management API, separate redirect for public availability, one worker and relational authority. Cache and visit channel isolate derived work. Analytics stays relational initially; analytical storage/private delivery require a future justified decision. Consequence: Required acceptance expectation; no runtime or verification is supplied. Links: system:system
- production-objectives (Unresolved): Production workload, SLO and recovery remain open — Illustrative architecture study; product owner and implementation review must confirm this choice. Decision: Production traffic, SLO, RPO/RTO, analytics freshness and commercial retention are unspecified. Values in binding policies are illustrative examples only. Recovery owner: operations; product owner approves loss and retention. Restore authority first, invalidate caches, replay retained durable work and reconcile billing with provider. Consequence: Owner: product owner with operations lead. Blocks production implementation sizing and recovery approval; design exploration can continue. Links: system:system
- tenant-revocation (Accepted): Tenant access and revocation — Illustrative architecture study; product owner and implementation review must confirm this choice. Decision: Check principal, tenant and current membership/API-key state on every API, database operation, job start and export download. Revocation takes effect on the next authorization check; cancel queued jobs and deny old downloads. Public lookup discloses no tenant-private data. Consequence: Required acceptance expectation; no runtime or verification is supplied. Links: component:tenant-access, binding:worker-access, binding:export-access
- stable-identity (Accepted): Stock identity and atomic changes — Illustrative architecture study; product owner and implementation review must confirm this choice. Decision: Stock changes and event intent commit in one transaction through the atomic writer; delivery records acknowledged progress and handler deduplicates tenantId/eventId. Consequence: Required acceptance expectation; no runtime or verification is supplied. Links: component:records, dataset:delivery-domain-state
- report-lifecycle (Accepted): Analytics meaning, retention and recovery — Illustrative architecture study; product owner and implementation review must confirm this choice. Decision: A stock event is a committed quantity mutation at a recorded revision. Reports and exports require current tenant authorization and label freshness. Illustrative event retention is 90 days and exports 7 days. Deletion covers reports and objects; restore reapplies tombstones before access. Operations owns reconciliation; production RPO/RTO remain open. Consequence: Required acceptance expectation; no runtime or verification is supplied. Links: component:reporting, dataset:reports-dataset, dataset:export-dataset
- decision:production-objectives — outside approved scope: Production workload, SLO and recovery remain open: Illustrative architecture study; product owner and implementation review must confirm this choice. Owner: product owner with operations lead. Blocks production implementation sizing and recovery approval; design exploration can continue. Owner: Product owner and operations. Blocks: Production approval and capacity sizing.
- objective:production-recovery — outside approved scope: Unspecified production recovery objective: incomplete unverified runtime target. Owner: Product owner and operations. Blocks: Production approval and capacity sizing.

<a id="obligations"></a>
## Missing implementation responsibilities

- container:api inside api: Owns tenant-authorized product operations and authoritative state.
  - Contract boundaries: tenant-access-contract@v1, tenant-workspace-records@v1, delivery-atomic-commit@v2, delivery-domain-records@v1, delivery-outbox-records@v2, manage-records@v1, report-contract@v1, remote-access@v1, audit-records@v1, reports-records@v1, member-command@v1, job-command@v1; bindings: tenant-check-access-binding, tenant-save-membership-binding, delivery-commit-domain-event-binding, delivery-persist-domain-binding, delivery-persist-intent-binding, manage, record-access, stock-commit, reports, report-access, export-access, audit-write, reports-write, members, export-job, worker-access, aggregate-query.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- container:worker inside worker: Checks tenant scope again before reports, exports and delivery.
  - Contract boundaries: delivery-outbox-records@v2, delivery-work-event@v2, remote-access@v1, job-command@v1, export-records@v1, reports-records@v1; bindings: delivery-read-intent-binding, delivery-record-progress-binding, delivery-publish-work-binding, delivery-consume-work-binding, export-access, export-job, export-write, worker-access, aggregate-write, aggregate-export.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- container:db inside db: Authoritative tenant records and product data; shared scoped storage.
  - Contract boundaries: tenant-workspace-records@v1, delivery-domain-records@v1, delivery-outbox-records@v2, audit-records@v1, reports-records@v1, export-records@v1; bindings: tenant-save-membership-binding, delivery-persist-domain-binding, delivery-persist-intent-binding, delivery-read-intent-binding, delivery-record-progress-binding, audit-write, reports-write, export-write, aggregate-write, aggregate-query, aggregate-export.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- container:delivery-channel inside delivery-channel: Logical job-queue with explicit responsibility and editable policies.
  - Contract boundaries: delivery-work-event@v2; bindings: delivery-publish-work-binding, delivery-consume-work-binding.
  - Acceptance IDs: none; expectations: pattern:delivery/invariant-1: REQUIRED: one atomic transaction persists domain-state and event-intent in the selected store through atomic-writer. Neither may commit alone.; pattern:delivery/invariant-2: REQUIRED: delivery reads retained intent, publishes with retry, and records delivery progress safely. Handler deduplicates tenantId + eventId. A queue plus handler cannot satisfy transactional outbox intent.; pattern:delivery/invariant-3: Logical channel “Stock changes” is distinct from other business channels even when a later deployment shares a broker. Carry tenant context into background work.; pattern:delivery/invariant-4: Design intent only: no runtime is attached, atomicity verified or delivery measured. Resolve lifecycle and domain payload decisions before implementation..
- container:web inside web: Signed-in feature areas using exact tenant-scoped API contracts.
  - Contract boundaries: manage-records@v1, report-contract@v1, member-command@v1; bindings: manage, reports, members.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:tenant-workspace inside api: Workspace membership
  - Contract boundaries: tenant-access-contract@v1, tenant-workspace-records@v1, member-command@v1; bindings: tenant-check-access-binding, tenant-save-membership-binding, members.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:tenant-access inside api: Tenant access checks Resolves authenticated session or API-key principal, reads current tenant membership/key status and authorizes each API, persistence, job and export action. Network privacy supplies no authorization.
  - Contract boundaries: tenant-access-contract@v1, remote-access@v1; bindings: tenant-check-access-binding, record-access, report-access, export-access, worker-access.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:delivery-producer inside api: Domain change
  - Contract boundaries: delivery-atomic-commit@v2; bindings: delivery-commit-domain-event-binding.
  - Acceptance IDs: none; expectations: pattern:delivery/invariant-1: REQUIRED: one atomic transaction persists domain-state and event-intent in the selected store through atomic-writer. Neither may commit alone.; pattern:delivery/invariant-2: REQUIRED: delivery reads retained intent, publishes with retry, and records delivery progress safely. Handler deduplicates tenantId + eventId. A queue plus handler cannot satisfy transactional outbox intent.; pattern:delivery/invariant-3: Logical channel “Stock changes” is distinct from other business channels even when a later deployment shares a broker. Carry tenant context into background work.; pattern:delivery/invariant-4: Design intent only: no runtime is attached, atomicity verified or delivery measured. Resolve lifecycle and domain payload decisions before implementation..
- responsibility:delivery-atomic-writer inside api: Atomic domain and event writer
  - Contract boundaries: delivery-atomic-commit@v2, delivery-domain-records@v1, delivery-outbox-records@v2; bindings: delivery-commit-domain-event-binding, delivery-persist-domain-binding, delivery-persist-intent-binding, stock-commit.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:records inside api: Tenant-owned stock changes and durable event intent.
  - Contract boundaries: manage-records@v1, tenant-access-contract@v1, delivery-atomic-commit@v2; bindings: manage, record-access, stock-commit.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:reporting inside api: Tenant-authorized queries, exports, deletion, retention and recovery coordination.
  - Contract boundaries: report-contract@v1, tenant-access-contract@v1, reports-records@v1, job-command@v1; bindings: reports, report-access, reports-write, export-job, aggregate-query.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:audit inside api: Records staff and tenant security changes without storing API keys or raw IP addresses.
  - Contract boundaries: audit-records@v1; bindings: audit-write.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:delivery-handler inside worker: Idempotent work handler
  - Contract boundaries: delivery-work-event@v2, remote-access@v1, reports-records@v1; bindings: delivery-consume-work-binding, worker-access, aggregate-write.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:delivery-delivery inside worker: Outbox delivery responsibility
  - Contract boundaries: delivery-outbox-records@v2, delivery-work-event@v2; bindings: delivery-read-intent-binding, delivery-record-progress-binding, delivery-publish-work-binding.
  - Acceptance IDs: none; expectations: scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:export-jobs inside worker: Recheck tenant access and revocation at execution and download; cancel revoked jobs and expire export objects.
  - Contract boundaries: remote-access@v1, job-command@v1, export-records@v1, reports-records@v1; bindings: export-access, export-job, export-write, aggregate-export.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:library inside web: Creation, editing, version history and explicit loading, success, denial and failure states.
  - Contract boundaries: manage-records@v1; bindings: manage.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:report-screens inside web: Authorized reporting, deletion requests and expiring export downloads.
  - Contract boundaries: report-contract@v1; bindings: reports.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..
- responsibility:settings-screens inside web: Tenant membership, principal revocation and export access decisions.
  - Contract boundaries: member-command@v1; bindings: members.
  - Acceptance IDs: none; expectations: scenario:create-edit/success: Stock and event intent commit together; downstream delivery can recover.; scenario:create-edit/failure: Unauthorized edits fail closed; version conflicts preserve previous committed state.; scenario:membership/success: Revocation denies the next API/data/job/download authorization check; old jobs cancel and links disclose no private tenant data.; scenario:membership/failure: Foreign tenant or revoked credentials cannot mutate membership or read exports.; scenario:analytics-lifecycle/success: Report labels event meaning, gaps and freshness. Deletion covers aggregates and objects; restore reapplies tombstones before reads. Production RPO/RTO remain assigned open decisions.; scenario:analytics-lifecycle/failure: No cross-tenant download, silent stale report or resurrection of deleted data after recovery..

<a id="deployment"></a>
## Deployment intent and reusable provenance

- hosted-study: Hosted first — illustrative placement (Hosted) — Placement intent only; replicas, regions and recovery capacity require production decisions.. Exact placement: [JSON](./architecture-handoff.json).
- tenant: tenant-workspace-access@1.0.0 (resolved); editable architecture only, no inherited passes.
- delivery: asynchronous-work-delivery@1.0.0 (resolved); editable architecture only, no inherited passes.

<a id="evidence"></a>
## Recorded evidence

Only the recorded project, revision and environment; no inherited passes or production certification.
Project 681356e6-222b-41bd-acc2-6a59b207b072; revision 5; environment unrecorded.
Infrastructure, template and application check results retain their recorded identities in [JSON](./architecture-handoff.json).
Required interfaces: 24/24 bound.
