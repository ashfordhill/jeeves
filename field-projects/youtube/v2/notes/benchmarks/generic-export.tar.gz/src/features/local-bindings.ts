// Foundation-owned exact contributed runtime logins.
export const localLogins: {resource:string;host:string;database:string;user:string;secret:string}[] = [];
