import subprocess,json,concurrent.futures,os,datetime
images=['postgres:17.11-alpine3.23','valkey/valkey:8.1.10-alpine','rabbitmq:4.4.0-management-alpine','opensearchproject/opensearch:3.9.0','quay.io/keycloak/keycloak:26.8.1','dxflrs/garage:v2.4.1','nginx:1.28.0-alpine','node:24.21.0-bookworm-slim']
os.makedirs('/tmp/jeeves-fp01/images',exist_ok=True)
def run(img):
 p=subprocess.run(['docker','buildx','imagetools','inspect',img,'--format','{{json .Manifest}}'],capture_output=True,text=True,timeout=50)
 fn=img.replace('/','_').replace(':','_')+'.json'
 open('/tmp/jeeves-fp01/images/'+fn,'w').write(p.stdout or p.stderr)
 try:
  j=json.loads(p.stdout);amd=next((x for x in j.get('manifests',[]) if x.get('platform',{}).get('architecture')=='amd64'),None)
  return {'image':img,'indexDigest':j.get('digest'),'linuxAmd64':amd,'status':p.returncode,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evidence':fn}
 except:return {'image':img,'status':p.returncode,'error':p.stderr.strip(),'evidence':fn}
rows=list(concurrent.futures.ThreadPoolExecutor(max_workers=4).map(run,images));open('/tmp/jeeves-fp01/image-availability.json','w').write(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
