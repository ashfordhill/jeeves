import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { assembleExperimental, localV1Templates, loadYoutubeLocalInput, sha256 } from '/home/ash/github/jeeves/jeeves-generator/src/index.ts';
const one=assembleExperimental(loadYoutubeLocalInput(),localV1Templates);
const two=assembleExperimental(loadYoutubeLocalInput(),localV1Templates);
assert.equal(one.files.length,108);assert.equal(two.files.length,108);
for (let i=0;i<one.files.length;i++) {assert.equal(one.files[i].path,two.files[i].path);assert.equal(Buffer.from(one.files[i].bytes).equals(Buffer.from(two.files[i].bytes)),true)}
const payloads=one.files.map(f=>({path:f.path,bytes:f.bytes.length,sha256:sha256(f.bytes)}));
await fs.writeFile('/tmp/jeeves-fp04/expected-payloads.json',JSON.stringify(payloads,null,2)+'\n');
await fs.writeFile('/tmp/jeeves-fp04/assembler-bytes.json',JSON.stringify(Object.fromEntries(one.files.map(f=>[f.path,Buffer.from(f.bytes).toString('base64')]))));
console.log(JSON.stringify({generator:one.manifest.generator,profile:one.manifest.profile,templates:one.manifest.templates,files:payloads.length,payloadBytes:payloads.reduce((n,p)=>n+p.bytes,0),manifestSha256:sha256(one.files.find(f=>f.path==='.jeeves/manifest.json')!.bytes),repeatedAssemblyByteEqual:true},null,2));
