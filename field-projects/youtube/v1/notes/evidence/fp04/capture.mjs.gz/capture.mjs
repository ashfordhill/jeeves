import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='/home/ash/github/jeeves',out='/tmp/jeeves-fp04';
const require=createRequire(`${root}/package.json`),{chromium}=require('@playwright/test');
const hash=b=>createHash('sha256').update(b).digest('hex');
const stable=v=>Array.isArray(v)?v.map(stable):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):v;
const canonical=v=>JSON.stringify(stable(v));
const browser=await chromium.launch({headless:true});
try {
 const page=await browser.newPage({viewport:{width:1280,height:800},baseURL:'http://127.0.0.1:4300'});
 const errors=[],consoleErrors=[];page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text())});
 const get=async path=>{const r=await page.request.get(`/api${path}`);assert.equal(r.ok(),true,`${path} ${r.status()}`);return r.json()};
 const listing=await get('/projects'),ids=listing.projects.map(p=>p.id),before={};
 for(const id of ids)before[id]={project:await get(`/projects/${id}`),design:await get(`/projects/${id}/design`),layout:await get(`/projects/${id}/layout`),blueprint:await get(`/projects/${id}/blueprint?version=3`)};
 await fs.writeFile(`${out}/owner-before.json`,JSON.stringify({listing,projects:before},null,2)+'\n');
 const id='293b4a2d-e25b-4a5b-83da-b27de7876f02',source=before[id].design.design;
 assert.equal(source.revision,3);assert.equal(hash(canonical(source)),'7d1874a1e74c6bf53df9058a9b2f826b4d83def2aaddb328022747355979cc93');
 await page.goto(`/?project=${id}`);
 await page.locator('.lane-canvas .board[data-layout="ready"][data-board="ready"]').waitFor();
 await page.getByRole('button',{name:'Fit',exact:true}).click();await page.waitForTimeout(350);
 assert.equal(await page.locator('.board .react-flow__node').count(),21);assert.equal(await page.locator('.board .react-flow__edge').count(),25);
 const view=()=>page.locator('.lane-canvas .board').evaluate(b=>({camera:b.querySelector('.react-flow__viewport')?.style.transform,tiles:[...b.querySelectorAll('.react-flow__node')].map(x=>({id:x.dataset.id,style:x.getAttribute('style'),class:x.getAttribute('class')})),lines:[...b.querySelectorAll('.react-flow__edge')].map(x=>({id:x.dataset.id,path:x.querySelector('.react-flow__edge-path')?.getAttribute('d')}))}));
 const viewBefore=await view();
 await page.getByRole('button',{name:'Generate project',exact:true}).click();
 const previewEvent=page.waitForResponse(r=>r.url().endsWith('/experimental-generation/preview'));
 await page.getByRole('button',{name:'Preview scaffold',exact:true}).click();
 const preview=await(await previewEvent).json();assert.equal(preview.archive.files,108);assert.equal(preview.settings.unsupported,25);
 await page.getByText('Ready: 108 files',{exact:false}).waitFor();
 await fs.writeFile(`${out}/browser-preview.json`,JSON.stringify(preview,null,2)+'\n');
 await page.screenshot({path:`${out}/generation.png`});
 for(const name of ['mouse-download.zip','mouse-repeat.zip']) {
  const zipEvent=page.waitForEvent('download');await page.getByRole('button',{name:'Download project ZIP',exact:true}).click();await(await zipEvent).saveAs(`${out}/${name}`);
  const zip=await fs.readFile(`${out}/${name}`);assert.equal(hash(zip),preview.archive.sha256);assert.equal(zip.length,946247);
 }
 assert.equal((await fs.readFile(`${out}/mouse-download.zip`)).equals(await fs.readFile(`${out}/mouse-repeat.zip`)),true);
 await page.getByRole('button',{name:'Close generate experimental project'}).click();assert.deepEqual(await view(),viewBefore);
 const tiny=listing.projects.find(p=>p.name.startsWith('TinyURL'));assert.ok(tiny);
 await page.getByRole('button',{name:/^Project:/}).click();await page.getByRole('menuitem',{name:tiny.name,exact:true}).click();
 await page.locator('.lane-canvas .board[data-layout="ready"][data-board="ready"]').waitFor();await page.getByRole('button',{name:'Fit',exact:true}).click();await page.waitForTimeout(350);
 assert.equal(await page.locator('.board .react-flow__node').count(),12);assert.equal(await page.locator('.board .react-flow__edge').count(),13);
 await page.screenshot({path:`${out}/studio-tinyurl.png`});
 const after={};for(const id of ids)after[id]={project:await get(`/projects/${id}`),design:await get(`/projects/${id}/design`),layout:await get(`/projects/${id}/layout`),blueprint:await get(`/projects/${id}/blueprint?version=3`)};
 assert.deepEqual(after,before);assert.deepEqual(await get('/projects'),listing);assert.deepEqual(errors,[]);assert.deepEqual(consoleErrors,[]);
 await fs.writeFile(`${out}/browser-result.json`,JSON.stringify({capturedAt:new Date().toISOString(),url:'http://127.0.0.1:4300',browser:browser.version(),viewport:{width:1280,height:800},mouseFlow:['Generate project','Preview scaffold','Download project ZIP','Download project ZIP (repeat)'],projects:ids.map(id=>({id,name:before[id].project.project.name,revision:before[id].design.design.revision,beforeSha256:hash(canonical(before[id])),afterSha256:hash(canonical(after[id]))})),projectListingPreserved:true,completeProjectDesignHistoryLayoutBlueprintResponsesPreserved:true,viewPreserved:true,errors,consoleErrors,tinyurl:{tiles:12,lines:13,mouseFit:true},v1:{tiles:21,lines:25,sourceSha256:hash(canonical(source)),archive:preview.archive,repeatedActualMouseDownloadsByteEqual:true}},null,2)+'\n');
 console.log(JSON.stringify({archive:preview.archive,projects:ids.length,tinyurl:'12/13',errors,consoleErrors}));
} finally {await browser.close()}
