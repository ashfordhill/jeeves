import pathlib,json,hashlib,os,subprocess,re
root=pathlib.Path('/home/ash/github/jeeves');out=pathlib.Path('/tmp/jeeves-fp04')
expected=json.loads((out/'expected-payloads.json').read_text());results=[]
for app in [root/'field-projects/youtube/v1/app',out/'independent-app']:
 for item in expected:
  p=app/item['path'];b=p.read_bytes();assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'],str(p)
 pkg=json.loads((app/'package.json').read_text())
 assert all('workspace:' not in v and not v.startswith(('file:','link:')) for d in ['dependencies','devDependencies'] for v in pkg[d].values())
 for p in (app/'src').rglob('*.ts'):
  text=p.read_text();assert '@jeeves/' not in text and '/home/ash/github/jeeves' not in text
  for spec in re.findall(r'from\s+[\'\"]([^\'\"]+)',text):
   if spec.startswith('.'): assert (p.parent/spec).resolve().is_relative_to(app.resolve()),str(p)
 source=[]
 for parent,dirs,files in os.walk(app):
  dirs[:]=[d for d in dirs if d not in ['node_modules','dist']]
  source.extend((pathlib.Path(parent)/n).relative_to(app).as_posix() for n in files)
 assert sorted(source)==[i['path'] for i in expected]
 root_modules=subprocess.check_output(['/home/ash/.local/bin/pnpm','root'],cwd=app,env={**os.environ,'PATH':'/home/ash/.nvm/versions/node/v24.21.0/bin:/home/ash/.local/bin:/usr/bin:/bin'},text=True).strip()
 assert root_modules==str(app/'node_modules')
 local_ts=(app/'node_modules/typescript').resolve();assert local_ts.is_relative_to(app/'node_modules')
 results.append(dict(path=str(app),all108SourceFilesUnchangedAfterFrozenInstallAndBuild=True,ownNodeModules=root_modules,ownTypescript=str(local_ts),noWorkspaceOrJeevesImports=True,allRelativeImportsStayInsideProject=True,lockfileSha256=hashlib.sha256((app/'pnpm-lock.yaml').read_bytes()).hexdigest()))
lock=hashlib.sha256((root/'pnpm-lock.yaml').read_bytes()).hexdigest();assert lock=='2b769e7f39fa244c500dbda9c5a9fc7a949dc3bf2e87fd5194f4be6d21bfa60f'
base='aedbd606342c5a369142b10cf127fc7130d50671'
git=lambda *args:subprocess.check_output(['git',*args],cwd=root)
paths=git('ls-tree','-r','--name-only',base,'field-projects/youtube/v1/inputs','field-projects/youtube/v1/diagrams','jeeves-generator','apps','packages').decode().splitlines()
protected=[p for p in paths if p not in ['jeeves-generator/README.md','field-projects/youtube/v1/diagrams/index.md']]
for p in protected: assert (root/p).read_bytes()==git('show',f'{base}:{p}'),p
append_paths=['docs/handoff.md','field-projects/youtube/v1/notes/work-log.md','field-projects/youtube/v1/notes/ledger.md','field-projects/youtube/v1/diagrams/index.md']
for p in append_paths: assert (root/p).read_bytes().startswith(git('show',f'{base}:{p}')),p
print(json.dumps(dict(node='24.21.0',pnpm='12.16.1',commands=['pnpm install --frozen-lockfile','pnpm build'],locations=results,rootLockfileUnchanged=True,rootLockfileSha256=lock,baseCommit=base,protectedSourceTemplateInputAndDiagramFilesUnchanged=len(protected),historicalEntryPrefixesPreserved=append_paths),indent=2))
