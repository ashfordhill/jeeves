import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const names=(await fs.readdir('dist/extensions')).filter(n=>n.endsWith('.js')).sort();
assert.equal(names.length,7);
const results=[];
for(const name of names){const module=await import(new URL(`./dist/extensions/${name}`,`file://${process.cwd()}/`));let error;try{await module.handle({})}catch(e){error=e}assert.equal(error?.code,'CUSTOM_IMPLEMENTATION_REQUIRED');assert.equal(error?.statusCode,501);results.push({file:`src/extensions/${name.replace(/\.js$/,'.ts')}`,error:error.code,statusCode:error.statusCode,message:error.message})}
const typescript=await import(new URL('./node_modules/typescript/package.json',`file://${process.cwd()}/`),{with:{type:'json'}});
console.log(JSON.stringify({note:'Bounded failure observation only; no S01-S08 acceptance run or real business completion.',node:process.version,typescript:typescript.default.version,typescriptResolvedUnderIndependentProject:await fs.realpath('node_modules/typescript'),extensions:results},null,2));
