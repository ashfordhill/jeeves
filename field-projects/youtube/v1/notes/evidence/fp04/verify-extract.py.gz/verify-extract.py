import base64, hashlib, json, os, pathlib, re, stat, zipfile
root=pathlib.Path('/home/ash/github/jeeves')
out=pathlib.Path('/tmp/jeeves-fp04')
expected=json.loads((out/'expected-payloads.json').read_text())
actual_bytes={p:base64.b64decode(b,validate=True) for p,b in json.loads((out/'assembler-bytes.json').read_text()).items()}
expected_paths=[p['path'] for p in expected]
hash=lambda b:hashlib.sha256(b).hexdigest()
results=[]
for name in ['mouse-download.zip','mouse-repeat.zip']:
 data=(out/name).read_bytes()
 assert len(data)==946247 and hash(data)=='c885dd34e323c1102447587db25d68d273c5897826c240db31a9c222b8269c86'
 with zipfile.ZipFile(out/name) as archive:
  assert not archive.comment and archive.testzip() is None
  infos=archive.infolist(); names=[i.filename for i in infos]
  assert names==expected_paths==sorted(expected_paths) and len(names)==108
  assert len(set(n.lower() for n in names))==len(names)
  for info, item in zip(infos,expected):
   path=info.filename
   assert 0<len(path)<=240 and re.fullmatch(r'[A-Za-z0-9._/-]+',path)
   parts=path.split('/')
   assert all(p and p not in ['.','..'] and not p.endswith('.') and p.lower()!='.git' and not re.match(r'^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\.|$)',p,re.I) for p in parts)
   assert not pathlib.PurePosixPath(path).is_absolute()
   assert all('/'.join(parts[:i]).lower() not in set(n.lower() for n in names) for i in range(1,len(parts)))
   assert not info.is_dir() and info.external_attr==0 and info.create_system==0 and info.flag_bits==0
   assert info.compress_type==zipfile.ZIP_STORED and info.date_time==(1980,1,1,0,0,0)
   assert not info.extra and not info.comment and info.file_size<=8*1024*1024
   payload=archive.read(info)
   assert payload==actual_bytes[path],path
   assert len(payload)==item['bytes'] and hash(payload)==item['sha256'],path
  manifest_data=archive.read('.jeeves/manifest.json'); manifest=json.loads(manifest_data)
  assert len(manifest_data)==80362 and hash(manifest_data)=='5098707958077ea90b4ad36118f987069351ace61b6f33251d347144f764e21f'
  assert [i['path'] for i in manifest['files']]==[p for p in names if p!='.jeeves/manifest.json']
  for item in manifest['files']:
   payload=archive.read(item['path'])
   assert len(payload)==item['bytes'] and hash(payload)==item['sha256'],item['path']
  assert sum(i['bytes'] for i in manifest['files'])==851637
  assert sum(i.file_size for i in infos)==931999
  for p in ['manifest.json','design.json','blueprint.json','local-bindings.json','runtime-pins.json']:
   assert archive.read('.jeeves/inputs/'+p)==(root/'field-projects/youtube/v1/inputs'/p).read_bytes()
  assert archive.read('.jeeves/inputs/diagram.png')==(root/'field-projects/youtube/v1/diagrams/005-local-intent-aligned/diagram.png').read_bytes()
  assert manifest['source']['canonicalSha256']=='7d1874a1e74c6bf53df9058a9b2f826b4d83def2aaddb328022747355979cc93'
  assert manifest['generator']['version']=='0.1.0-experimental.2' and len(manifest['templates'])==19
  assert all(t['version']=='0.1.0-experimental.1' for t in manifest['templates'])
  report=json.loads(archive.read('.jeeves/report.json'))
  assert report['strictReadiness']['generationEligible'] is False
  assert report['applicationComplete'] is False
  assert len(report['gaps'])==8 and len(report['extensionTasks'])==7
  assert len([s for s in report['settings'] if s['status']=='unsupported'])==25
  assert all(s['status']=='not-run' for s in report['scenarios'])
  results.append(dict(archive=name,sha256=hash(data),archiveBytes=len(data),files=len(infos),payloadBytes=sum(i.file_size for i in infos),manifestSha256=hash(manifest_data),manifestBytes=len(manifest_data),hashedPayloads=len(manifest['files']),hashedPayloadBytes=851637,everyPayloadByteEqualsActualAssembler=True,everyManifestHashMatches=True,allCrcsVerified=True,portableRegularPathsOnly=True,symlinksExecutablesEncryptionDuplicatesTraversalRefused=True,dotfilesIncluded=True,frozenInputAndDiagramBytesEqual=True))
# No archive-driven extraction: all members have passed the complete allowlist/byte preflight.
# Trusted local parents are checked against symlinks; every directory/file is exclusively new.
def extract_new(dest):
 for parent in reversed([dest.parent,*dest.parents]):
  assert stat.S_ISDIR(parent.lstat().st_mode) and not parent.is_symlink(),str(parent)
 assert not dest.exists() and not dest.is_symlink(),str(dest)
 dest.mkdir(mode=0o755); dest.chmod(0o755)
 with zipfile.ZipFile(out/'mouse-download.zip') as archive:
  for path in expected_paths:
   target=dest/path
   for parent in reversed(target.parents):
    if parent==dest or dest in parent.parents:
     if not parent.exists(): parent.mkdir(mode=0o755);parent.chmod(0o755)
     assert stat.S_ISDIR(parent.lstat().st_mode) and not parent.is_symlink()
   fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o644)
   with os.fdopen(fd,'wb') as output: output.write(archive.read(path))
   target.chmod(0o644)
 files=[]
 for parent,dirs,names in os.walk(dest):
  assert stat.S_IMODE(pathlib.Path(parent).stat().st_mode)==0o755
  for name in dirs: assert not (pathlib.Path(parent)/name).is_symlink()
  for name in names:
   path=pathlib.Path(parent)/name; rel=path.relative_to(dest).as_posix();files.append(rel)
   assert stat.S_ISREG(path.lstat().st_mode) and stat.S_IMODE(path.stat().st_mode)==0o644
   assert path.read_bytes()==actual_bytes[rel],rel
 assert sorted(files)==expected_paths
 return dict(path=str(dest),files=len(files),allBytesVerifiedAfterExtraction=True,directoryMode='0755',fileMode='0644',exclusiveCreation=True)
extractions=[extract_new(root/'field-projects/youtube/v1/app'),extract_new(out/'independent-app')]
print(json.dumps(dict(reader='Python standard-library zipfile, independent of generator archive writer',verifiedBeforeAnyExtraction=True,archives=results,extractions=extractions),indent=2))
