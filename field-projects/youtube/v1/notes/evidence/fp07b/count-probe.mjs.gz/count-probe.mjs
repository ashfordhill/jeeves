// Run via stdin inside scratch view-counter. Read-only receipt/total evidence; no writes.
import {connect} from './dist/clients/counter-writer.js';
const pool=connect();try{console.log(JSON.stringify({checkedAt:new Date().toISOString(),receipts:(await pool.query('SELECT video_id,event_id,accepted_at FROM count_private.receipts ORDER BY accepted_at')).rows,totals:(await pool.query('SELECT * FROM count_private.totals ORDER BY video_id')).rows},null,2));}finally{await pool.end();}
