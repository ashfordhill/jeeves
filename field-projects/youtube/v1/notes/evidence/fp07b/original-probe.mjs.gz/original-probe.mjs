// Run by stdin in scratch upload container; see replay instructions.
import {createHash} from 'node:crypto';
import {objects} from './dist/lib/objects.js';
import {connect} from './dist/clients/upload-state-writer.js';
import {GetObjectCommand} from '@aws-sdk/client-s3';
const pool=connect(),s3=objects();
try{const rows=(await pool.query(`SELECT v.video_id,v.state,v.job_id,v.attempt_id,v.title,v.expected_size,v.expected_sha256,v.media,v.published_at,u.upload_id,u.original_key FROM video_private.videos v JOIN video_private.uploads u USING(video_id) ORDER BY v.created_at`)).rows;for(const row of rows){if(row.state!=='ready')continue;const r=await s3.send(new GetObjectCommand({Bucket:'youtube-v1-originals',Key:row.original_key}));const h=createHash('sha256');let size=0;for await(const b of r.Body){size+=b.length;h.update(b);}row.streamedOriginal={size,sha256:h.digest('hex')};if(size!==Number(row.expected_size)||row.streamedOriginal.sha256!==row.expected_sha256)throw Error('Actual original differs');}console.log(JSON.stringify({checkedAt:new Date().toISOString(),rows},null,2));}finally{await pool.end();s3.destroy();}
