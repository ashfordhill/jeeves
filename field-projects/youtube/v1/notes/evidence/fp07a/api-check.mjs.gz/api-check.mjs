import assert from 'node:assert/strict';import fs from 'node:fs/promises';
const base='http://127.0.0.1:4400/api',id='fdd51924-5a94-4e45-be02-a77b3c82d1a7',invalid='023291a9-47ba-4955-ba42-7e9787a63baa',out=[];
const current=async()=>(await(await fetch(base+'/watch/videos/'+id)).json()).views;
const before=await current();for(const [path,body,expected] of [
 ['/search/videos?q=',null,400],['/search/videos?q=fixture&page=101',null,400],['/search/videos?q=fixture&page=1.5',null,400],['/search/videos?q=fixture&size=500',null,400],
 ['/watch/videos/bad/views',{eventId:crypto.randomUUID()},400],['/watch/videos/'+invalid+'/views',{eventId:crypto.randomUUID()},404],['/watch/videos/'+id+'/views',{eventId:crypto.randomUUID(),publicationVersion:1},400],
 ['/watch/unknown',null,404],['/search/unknown',null,404],['/upload/unknown',null,404]]){
 const r=await fetch(base+path,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{}),d=await r.json();assert.equal(r.status,expected);out.push({path,status:r.status,body:d});}
const after=await current();assert.equal(before,after);await fs.writeFile('/home/ash/github/jeeves/field-projects/youtube/v1/notes/evidence/fp07a/api-boundaries.json',JSON.stringify({before,after,checks:out},null,2)+'\n');
