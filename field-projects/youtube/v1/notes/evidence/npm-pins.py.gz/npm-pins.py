import json,urllib.request,concurrent.futures,datetime,re
names=['@aws-sdk/client-s3','@aws-sdk/s3-request-presigner','amqplib','jose','redis','@opensearch-project/opensearch','hls.js']
cutoff='2026-10-24T00:00:00'
def run(name):
 u='https://registry.npmjs.org/'+name
 j=json.load(urllib.request.urlopen(u,timeout=30));vs=[(t,v) for v,t in j['time'].items()if re.fullmatch(r'\d+\.\d+\.\d+',v) and t[:19]<=cutoff];t,v=max(vs);d=j['versions'][v]['dist'];return {'name':name,'version':v,'publishedAt':t,'registry':u,'tarball':d['tarball'],'integrity':d.get('integrity'),'sha1':d.get('shasum')}
rows=list(concurrent.futures.ThreadPoolExecutor().map(run,names));print(json.dumps(rows,indent=2));open('/tmp/jeeves-fp01/npm-availability.json','w').write(json.dumps(rows,indent=2)+'\n')
