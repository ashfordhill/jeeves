import urllib.request,json,concurrent.futures
repos=['keycloak/keycloak','opensearch-project/OpenSearch','valkey-io/valkey','FFmpeg/FFmpeg']
def run(repo):
 try:
  req=urllib.request.Request('https://api.github.com/repos/'+repo+'/releases?per_page=10',headers={'User-Agent':'Jeeves-FP01'})
  rows=json.load(urllib.request.urlopen(req,timeout=20))
  return {'repo':repo,'releases':[{k:r[k]for k in ['tag_name','published_at','html_url','prerelease']}for r in rows]}
 except Exception as e:return {'repo':repo,'error':str(e)}
print(json.dumps(list(concurrent.futures.ThreadPoolExecutor().map(run,repos)),indent=2))
