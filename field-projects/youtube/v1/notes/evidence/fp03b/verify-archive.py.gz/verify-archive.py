import hashlib,json,zipfile,pathlib
root=pathlib.Path('/home/ash/github/jeeves')
expected=json.load(open('/tmp/jeeves-fp03b/expected-payloads.json'))
results=[]
for name in ['production-download.zip','mouse-download.zip']:
 path=pathlib.Path('/tmp/jeeves-fp03b')/name
 with zipfile.ZipFile(path) as archive:
  assert archive.testzip() is None
  assert archive.namelist()==sorted(item['path'] for item in expected)
  for item in expected:
   info=archive.getinfo(item['path']);payload=archive.read(item['path'])
   assert len(payload)==item['bytes']
   assert hashlib.sha256(payload).hexdigest()==item['sha256'],item['path']
   assert info.compress_type==zipfile.ZIP_STORED
   assert info.date_time==(1980,1,1,0,0,0)
   assert not info.extra and not info.comment and not info.is_dir()
  assert archive.read('.jeeves/inputs/diagram.png')==(root/'field-projects/youtube/v1/diagrams/005-local-intent-aligned/diagram.png').read_bytes()
  report=json.loads(archive.read('.jeeves/report.json'))
  assert len([s for s in report['settings'] if s['status']=='unsupported'])==25
  assert report['strictReadiness']['generationEligible'] is False
  assert all(s['status']=='not-run' for s in report['scenarios'])
  assert len(report['gaps'])==8
  results.append(dict(archive=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),archiveBytes=path.stat().st_size,files=len(expected),payloadBytes=sum(s['bytes'] for s in expected),manifestSha256=hashlib.sha256(archive.read('.jeeves/manifest.json')).hexdigest(),everyAssemblerPayloadAndCrcMatched=True,dotfilesIncluded=[n for n in archive.namelist() if n.startswith('.')],diagramBytesMatchFrozen005=True,strictEligibility=False,unsupportedPaths=25))
assert results[0]['sha256']==results[1]['sha256']
print(json.dumps(dict(reader='Python standard-library zipfile (independent of stored-ZIP writer)',results=results),indent=2))
