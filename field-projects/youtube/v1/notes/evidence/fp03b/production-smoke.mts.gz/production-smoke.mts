import {writeFile} from 'node:fs/promises';
import {assembleExperimental,loadYoutubeLocalInput,localV1Templates,sha256,canonicalJson,youtubeLocalProfile} from '/home/ash/github/jeeves/jeeves-generator/src/index.ts';
import {studioStudySeedOperations} from '/home/ash/github/jeeves/packages/spec/src/index.ts';
const origin='http://'+(await (await import('node:fs/promises')).readFile('/tmp/jeeves-fp03b/production-port.txt','utf8')).trim()+'/api';
for(let i=0;i<60;i++){const r=await fetch(`${origin}/health`).catch(()=>null);if(r?.ok)break;if(i===59)throw new Error('production health timeout');await new Promise(r=>setTimeout(r,500));}
const input=loadYoutubeLocalInput(),bundle=assembleExperimental(input,localV1Templates),frozen=JSON.parse(input.artifacts['design.json']);
const request=async(path,body?,method=body?'POST':'GET')=>{const r=await fetch(`${origin}${path}`,{method,headers:body?{'content-type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined});if(!r.ok)throw new Error(`${r.status} ${await r.text()}`);return r;};
const {project}=await(await request('/projects',{name:'FP03b production exact copy'})).json();
try{
for(const[baseRevision,ops]of[studioStudySeedOperations(frozen),[{op:'updateArchitectureSystem',name:'Temporary'}],[{op:'updateArchitectureSystem',name:frozen.architecture.system.name,description:frozen.architecture.system.description}]].entries())await request(`/projects/${project.id}/operations`,{baseRevision,source:'api',ops});
const before=await(await request(`/projects/${project.id}/design`)).json();
const body={profileId:youtubeLocalProfile.id,baseRevision:before.design.revision,sourceSha256:sha256(canonicalJson(before.design))};
const preview=await(await request(`/projects/${project.id}/experimental-generation/preview`,body)).json();
await writeFile('/tmp/jeeves-fp03b/production-preview.json',JSON.stringify(preview,null,2)+'\n');
const download=await request(`/projects/${project.id}/experimental-generation/download`,{...body,archiveSha256:preview.archive.sha256});
const bytes=new Uint8Array(await download.arrayBuffer());if(sha256(bytes)!==preview.archive.sha256)throw new Error('ZIP SHA mismatch');
await writeFile('/tmp/jeeves-fp03b/production-download.zip',bytes);
await writeFile('/tmp/jeeves-fp03b/expected-payloads.json',JSON.stringify(bundle.files.map(f=>({path:f.path,bytes:f.bytes.length,sha256:sha256(f.bytes)})),null,2)+'\n');
const after=await(await request(`/projects/${project.id}/design`)).json();if(canonicalJson(before)!==canonicalJson(after))throw new Error('state changed');
console.log(JSON.stringify({health:'ok',selectedProject:project.id,sourceSha256:body.sourceSha256,archive:preview.archive,designAndHistoryPreserved:true,previewAndDownloadPassed:true}));
}finally{await request(`/projects/${project.id}`,undefined,'DELETE');}
