import hashlib,json,pathlib,subprocess,urllib.request
root=pathlib.Path('/home/ash/github/jeeves')
canonical=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
hash=lambda b:hashlib.sha256(b).hexdigest()
audit=json.loads((root/'field-projects/youtube/v1/diagrams/007-generation-draft-guard/renderer-audit.json').read_text())
documentationOnlyAfterCapture=[]
for name,record in audit['files'].items():
 b=(root/name).read_bytes()
 if hash(b)!=record['sha256']:
  assert name=='jeeves-generator/README.md',name
  documentationOnlyAfterCapture.append(dict(path=name,captureSha256=record['sha256'],finalSha256=hash(b),reason='Qualify eager template startup failure versus in-request503; no executable/template changes'))
for slug in ['006-generation-ui','007-generation-draft-guard']:
 folder=root/'field-projects/youtube/v1/diagrams'/slug
 snapshot=json.loads((folder/'snapshot.json').read_text())
 for name,record in snapshot['files'].items():
  b=(folder/name).read_bytes();assert len(b)==record['bytes'] and hash(b)==record['sha256'],name
browser=json.load(open('/tmp/jeeves-fp03b/browser-result.json'))
get=lambda path:json.load(urllib.request.urlopen('http://127.0.0.1:4310'+path))
for project in browser['projects']:
 id=project['id'];current=dict(project=get('/projects/'+id),design=get('/projects/'+id+'/design'),layout=get('/projects/'+id+'/layout'),blueprint=get('/projects/'+id+'/blueprint?version=3'))
 assert hash(canonical(current))==project['beforeSha256'],id
assert not subprocess.check_output(['git','diff','--name-only','--','field-projects/youtube/v1/inputs','field-projects/youtube/v1/diagrams/001-owner-original','field-projects/youtube/v1/diagrams/002-postgresql-baseline','field-projects/youtube/v1/diagrams/003-v1-copy','field-projects/youtube/v1/diagrams/004-local-generation-baseline','field-projects/youtube/v1/diagrams/005-local-intent-aligned','jeeves-generator/src','jeeves-generator/templates'],cwd=root)
assert not (root/'field-projects/youtube/v1/app').exists()
print(json.dumps(dict(finalRuntimeSourceFilesMatch007Audit=True,sourceFilesChecked=len(audit['files']),documentationOnlyAfterCapture=documentationOnlyAfterCapture,all006And007ArtifactHashesMatch=True,allFourOwnerProjectResponsesStillEqual=True,frozenInputs005GeneratorCodeAndTemplateBytesUnchanged=True,noFieldApp=True,baselineCommit=audit['parentCommit']),indent=2))
