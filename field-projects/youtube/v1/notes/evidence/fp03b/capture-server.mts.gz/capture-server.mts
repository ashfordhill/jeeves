import {buildApp} from '/home/ash/github/jeeves/apps/server/src/app.ts';
import {connectDb} from '/home/ash/github/jeeves/apps/server/src/db/client.ts';
import {Settings} from '/home/ash/github/jeeves/apps/server/src/settings.ts';
const db=connectDb('postgres://jeeves:jeeves@127.0.0.1:54329/jeeves');
const app=buildApp({db:db.db,pingDb:db.ping,version:'0.1.0-fp03b-capture',settings:new Settings('/tmp/jeeves-fp03b/settings',{},true),models:()=>{throw new Error('Live models disabled for capture');}});
const stop=async()=>{await app.close();await db.close();process.exit(0);};
process.on('SIGINT',stop);process.on('SIGTERM',stop);
await app.listen({host:'127.0.0.1',port:4312});console.log('FP03b owned API 4312; no migrations/startup mutations');
