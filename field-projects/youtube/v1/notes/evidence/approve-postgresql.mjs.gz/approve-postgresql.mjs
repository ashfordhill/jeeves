import fs from'node:fs/promises';import assert from'node:assert/strict';
const root='/home/ash/github/jeeves/field-projects/youtube/v1/diagrams';const id='0a12f132-b0f4-400d-9b94-51546911bb6b';const url=`http://127.0.0.1:4310/projects/${id}`;
const archived=JSON.parse(await fs.readFile(`${root}/001-owner-original/design-response.json`,'utf8'));
const current=await(await fetch(`${url}/design`)).json();assert.deepEqual(current,archived);
const studio=structuredClone(current.design.architecture.studio);
for(const id of ['metadata-db','view-counts']){const s=studio.elements.find(e=>e.element===id).settings;assert.equal(s.engine,'mysql');s.engine='postgresql'}
const body={baseRevision:current.design.revision,ops:[{op:'setStudio',studio}],source:'api'};
const dir=`${root}/002-postgresql-baseline`;await fs.mkdir(dir,{recursive:true});await fs.writeFile(`${dir}/operation-request.json`,JSON.stringify(body,null,2)+'\n');
const r=await fetch(`${url}/operations`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});const bytes=await r.text();await fs.writeFile(`${dir}/operation-response.json`,bytes);assert.equal(r.status,200,bytes);
const after=JSON.parse(bytes),expected=structuredClone(current.design);expected.revision++;for(const id of ['metadata-db','view-counts'])expected.architecture.studio.elements.find(e=>e.element===id).settings.engine='postgresql';assert.deepEqual(after.design,expected);console.log(JSON.stringify({revision:after.design.revision,operationId:after.operationId,onlyTwoEnginesChanged:true}));
