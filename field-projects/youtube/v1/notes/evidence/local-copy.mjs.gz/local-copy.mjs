import fs from'node:fs/promises';import assert from'node:assert/strict';
const root='/home/ash/github/jeeves/field-projects/youtube/v1/diagrams';const id=(await fs.readFile('/tmp/jeeves-fp01/v1-project-id','utf8')).trim();const url=`http://127.0.0.1:4310/projects/${id}`;const before=await(await fetch(`${url}/design`)).json();const archived=JSON.parse(await fs.readFile(`${root}/003-v1-copy/design.json`,'utf8'));assert.deepEqual(before.design,archived);
const studio=structuredClone(before.design.architecture.studio);const changes=[];
const set=(entry,path,value)=>{const obj=entry.settings;const old=obj[path];if(value===undefined)delete obj[path];else obj[path]=value;if(old!==value)changes.push({target:entry.element?{kind:'element',id:entry.element}:{kind:'component',id:entry.id},path:`settings.${path}`,before:old??null,after:value??null})};
for(const e of studio.elements){const s=e.settings;
 if(['service','uploads','identity','worker'].includes(s.kind)){set(e,'minReplicas',1);set(e,'maxReplicas',1);set(e,'autoscaleOn',undefined)}
 if(s.kind==='database'){set(e,'readReplicas',0);set(e,'partitionKey',undefined)}
 if(s.kind==='cache')set(e,'topology','standalone');
 if(s.kind==='queue'){set(e,'partitions',undefined);set(e,'retentionSeconds',undefined)}
 if(s.kind==='object-store')set(e,'provider','self-hosted');
 if(s.kind==='cdn'){set(e,'provider','external');set(e,'imageResizing','disabled')}
}
const reader=studio.components.find(c=>c.id==='watch-details');assert.equal(reader.settings.readRouting,'replica');set(reader,'readRouting','primary');
const body={baseRevision:before.design.revision,ops:[{op:'setStudio',studio}],source:'api'};
const dir=`${root}/004-local-generation-baseline`;await fs.mkdir(dir,{recursive:true});await fs.writeFile(`${dir}/intentional-changes.json`,JSON.stringify(changes,null,2)+'\n');await fs.writeFile(`${dir}/operation-request.json`,JSON.stringify(body,null,2)+'\n');
const r=await fetch(`${url}/operations`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});const text=await r.text();await fs.writeFile(`${dir}/operation-response.json`,text);assert.equal(r.status,200,text);const expected=structuredClone(before.design);expected.revision++;expected.architecture.studio=studio;assert.deepEqual(JSON.parse(text).design,expected);console.log(JSON.stringify({id,revision:expected.revision,operationId:JSON.parse(text).operationId,changes:changes.length}));
