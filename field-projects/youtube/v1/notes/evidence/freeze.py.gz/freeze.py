import json,pathlib,hashlib,shutil,datetime,gzip
root=pathlib.Path('/home/ash/github/jeeves');v=root/'field-projects/youtube/v1';snap=v/'diagrams/005-local-intent-aligned';inp=v/'inputs'
load=lambda p:json.loads(pathlib.Path(p).read_text())
write=lambda p,x:pathlib.Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
hash=lambda b:hashlib.sha256(b).hexdigest()
design=load(snap/'design.json');studio=design['architecture']['studio'];capture=load(snap/'capture.json');blueprint=load(snap/'blueprint.json')
assert blueprint['blueprint']==3 and blueprint['sourceSchemaVersion']==2 and blueprint['readiness']['generationEligible']==False
for f in ['design.json','blueprint.json']:shutil.copyfile(snap/f,inp/f)
images=load('/tmp/jeeves-fp01/image-availability.json');selected=[]
release={
'postgres:17.11-alpine3.23':('2026-08-13','https://www.postgresql.org/docs/release/17.11/'),
'valkey/valkey:8.1.10-alpine':('2026-08-31','https://github.com/valkey-io/valkey/releases/tag/8.1.10'),
'rabbitmq:4.4.0-management-alpine':('2026-10-20','https://www.rabbitmq.com/release-information'),
'opensearchproject/opensearch:3.9.0':('2026-09-29','https://github.com/opensearch-project/OpenSearch/releases/tag/3.9.0'),
'quay.io/keycloak/keycloak:26.8.1':('2026-10-13','https://github.com/keycloak/keycloak/releases/tag/26.8.1'),
'dxflrs/garage:v2.4.1':('2026-09-08','https://garagehq.deuxfleurs.fr/_releases.html'),
'nginx:1.28.3-alpine':('2026-03-24','https://nginx.org/en/CHANGES-1.28'),
'node:24.21.0-bookworm-slim':(None,'https://github.com/nodejs/docker-node')}
for r in images:
 assert r['status']==0
 name=r['image'];selected.append({'image':name,'pinnedReference':name+'@'+r['indexDigest'],'indexDigest':r['indexDigest'],'linuxAmd64Digest':r['linuxAmd64']['digest'],'upstreamReleaseDate':release[name][0],'releaseSource':release[name][1],'availabilityCheckedAt':r['recordedAt'],'registryInspection':'docker buildx imagetools inspect; metadata only; not pulled or run','rawEvidence':'../notes/evidence/image-manifests/'+r['evidence']+'.gz'})
packages=load('/tmp/jeeves-fp01/npm-availability.json')
repoPackages={'fastify':'5.12.7','pg':'8.23.1','tsx':'4.23.15','typescript':'7.0.2','zod':'4.5.4','@types/node':'24.19.2','@types/pg':'8.23.1'}
pins={'format':'youtube-v1-runtime-pins-proposal-v1','status':'selected for experimental generation; compatibility unverified','selectedOn':'2026-11-07','targetPlatform':'linux/amd64','repositoryBaseCommit':'a98bf70','toolchain':{'node':'24.21.0','pnpm':'12.16.1','reason':'Reuse Jeeves installed toolchain; automation-pitch has Node 22-alpine only, not a more precise compatible pin.'},'images':selected,'repositoryNpmPins':repoPackages,'newNpmPins':packages,'ffmpeg':{'distribution':'Debian bookworm-security','upstreamVersion':'5.1.9','packageVersion':'7:5.1.9-0+deb12u1','architecture':'amd64','packageUrl':'https://deb.debian.org/debian-security/pool/updates/main/f/ffmpeg/ffmpeg_5.1.9-0+deb12u1_amd64.deb','packageSha256':'2ba8ead87657c123ce6de2de5ecdbc1fb4ead9a4b317b85b8ec41e16c890fe01','releasedOn':'2026-05-13','primarySource':'https://packages.debian.org/bookworm/ffmpeg','availability':'downloaded exact deb and matched Packages.xz SHA256; not installed/run','transitiveOsClosure':'not frozen in FP01; FP03 must lock the apt snapshot and resolved OS package versions before committing an independent build; no bit-identical container claim'},'pinPolicy':{'newPackageCutoff':'2026-10-24T00:00:00Z','minimumAge':'14 days on 2026-11-07','reuseExistingVersionsFirst':True,'mutableImageTags':'do not use alone; use the recorded tag@digest','imageRebuildDates':'may be newer than the upstream release; exact new bytes are recorded, not claimed aged 14 days','newVersionChanges':'record reason and source in an append-only decision/work-log entry before baseline generation; never silently substitute','platformsOtherThanLinuxAmd64':'unverified; do not claim support'},'notChecked':['Container startup and interoperability','Browser CORS / SigV4 against Garage 2.4.1','Actual FFmpeg codec and HLS playback in exported runtime','Cross-platform images / codecs','Production suitability or security certification']}
write(inp/'runtime-pins.json',pins)
# Exact IDs form a closed proposal. These IDs name desired FP02/03 template families, not installed templates.
choices={
'watch':('typescript.http-shell','node','Watch handlers and counts publication remain custom'),
'search':('typescript.http-shell','node','Search query and public-only responses remain custom'),
'upload':('typescript.signed-multipart-shell','node','JWT creator checks, multipart ownership/resume/completion and job publication remain custom'),
'view-counter':('typescript.worker-shell','node','Event receipts, batching, transactional count increments remain custom'),
'completion-handler':('typescript.worker-shell','node','Playable metadata publication and idempotence remain custom'),
'search-indexer':('typescript.worker-shell','node','Committed-publication ordering and index projection remain custom'),
'transcoder':('typescript.ffmpeg-worker-shell','node+ffmpeg','Real encode, packaging, thumbnails, idempotence and failure state remain custom'),
'identity':('local.oidc','keycloak','OIDC container/config; source language cannot be honored by this vendor adapter'),
'metadata-db':('local.postgresql','postgresql','Logical metadata database owned by completion-handler; no application tables yet'),
'view-counts':('local.postgresql','postgresql','Separate logical counts database owned by view-counter; no application tables yet'),
'metadata-cache':('local.redis-compatible','valkey','Standalone GET/SET cache; cache-aside behavior remains custom'),
'search-index':('local.opensearch','opensearch','Single-node resource; index schema/projection remains custom'),
'originals':('local.s3-bucket','garage','Private bucket; upload write, transcoder read'),
'transcoded':('local.s3-bucket','garage','Public website bucket through local edge; transcoder write'),
'video-cdn':('local.edge-proxy','nginx','Local proxy/cache substitute; no global distribution or resizing'),
'upload-queue':('local.amqp-work-queue','rabbitmq','Durable single queue; no log replay/partitions/retention claim'),
'completion-events':('local.amqp-fanout','rabbitmq','One durable queue per handler/indexer subscription; no ordering between subscribers'),
'view-events':('local.amqp-fanout','rabbitmq','One durable queue for view-counter; no sharding/replay claim')}
assert set(choices)=={e['element']for e in studio['elements']}
el=[]
for i,e in enumerate(studio['elements']):
 template,runtime,gap=choices[e['element']]
 el.append({'elementId':e['element'],'sourcePath':f'/architecture/studio/elements/{i}','definition':e['definition'],'requiredSettings':e['settings'],'owner':e.get('owner'),'proposedTemplateId':template,'templateVersion':None,'runtime':runtime,'availability':'not implemented','functionalCoverage':'unmeasured; no output exists','gap':gap})
# Per-component mapping is config/scaffold only; prose is excluded from selection.
components=[]
for i,c in enumerate(studio['components']):
 kind=c['settings']['kind'];family={'data-access':'typescript.pg-client-config','auth-guard':'typescript.jwt-guard-config','event-publisher':'typescript.amqp-publisher-config','event-consumer':'typescript.amqp-consumer-config','cache-reader':'typescript.cache-client-config','custom':'explicit-custom-extension'}[kind]
 components.append({'componentId':c['id'],'hostId':c['host'],'sourcePath':f'/architecture/studio/components/{i}','requiredSettings':c['settings'],'proposedTemplateId':family,'templateVersion':None,'availability':'not implemented','behavior':'custom until a real versioned template demonstrably emits it','links':[l for l in studio['componentConnections']if l['from']==c['id']]})
# Explicit endpoints/resources, not label parsing or inferred code.
wires={
'watch-cache':('valkey','read-write-cache-fill'),'watch-metadata':('postgresql.metadata','read-primary'),'watch-counts-read':('postgresql.counts','read-primary'),'counter-write':('postgresql.counts','write-owner'),
'watch-views-publish':('amqp.view-events','publish'),'views-counter':('amqp.view-counter','consume'),'search-read':('opensearch.videos','read'),'indexer-write':('opensearch.videos','write-owner'),
'cdn-transcoded':('garage.transcoded.website','public-read'),'upload-originals':('garage.originals.s3','multipart-owner'),'transcoder-read':('garage.originals.s3','read'),'transcoder-write':('garage.transcoded.s3','write-owner'),
'upload-publish':('amqp.upload-jobs','publish'),'jobs-transcoder':('amqp.upload-jobs','consume'),'transcoder-publish':('amqp.completion-events','publish'),'completions-handler':('amqp.completion-handler','consume'),'completions-indexer':('amqp.search-indexer','consume'),'handler-metadata':('postgresql.metadata','write-owner')}
assert set(wires)=={c['id']for c in design['connections']}
connections=[];overrides=[]
for i,c in enumerate(design['connections']):
 resource,access=wires[c['id']];connections.append({'connectionId':c['id'],'fromId':c['from']['element'],'toId':c['to']['element'],'sourcePath':f'/connections/{i}','declaredProtocol':c['planned'].get('protocol'),'declaredSecurity':c['planned'].get('security'),'localResource':resource,'access':access,'proposedOnly':True})
 for k in ['protocol','security']:
  value=c['planned'].get(k)
  if k=='security' or value=='HTTPS':
   overrides.append({'target':{'connectionId':c['id']},'sourcePath':f'/connections/{i}/planned/{k}','declared':value,'classification':'explicit local override; declared intent unsupported','localBinding':('Plain HTTP on isolated Compose network / loopback; no HTTPS/TLS implementation claimed'if k=='protocol'else'Dedicated local resource credentials where supported; no mTLS/workload/service identity implementation claimed'),'generatorMustReport':True})
idx=next(i for i,e in enumerate(studio['elements'])if e['element']=='identity')
overrides.append({'target':{'elementId':'identity'},'sourcePath':f'/architecture/studio/elements/{idx}/settings/language','declared':'typescript','classification':'explicit vendor substitution; declared language unsupported','localBinding':'Keycloak vendor runtime; Java, not generated TypeScript identity server','generatorMustReport':True})
bindings={'format':'youtube-v1-local-bindings-proposal-v1','status':'proposed finite mapping for FP02/FP03; zero available templates or functional coverage','sourceSnapshot':'../diagrams/005-local-intent-aligned','sourceCanonicalSha256':capture['source']['designSha256'],'sourceSchemaVersion':2,'blueprintVersion':3,'selectionRules':['Match canonical element/component/connection IDs plus exact definition versions and required settings','Never infer algorithms, endpoint schemas, resource ownership or template selection from labels, descriptions or module prose','Refuse source hash/ID/definition mismatches; report every unknown meaningful setting','Report all explicit overrides and named custom gaps; preserve strict readiness separately','Template IDs here are proposals, not registry entries or claims of availability'],'runtimePins':'runtime-pins.json','elements':el,'components':components,'connections':connections,'explicitUnsupportedIntent':overrides,'localConfig':{'publicWebOrigin':'http://127.0.0.1:4400','publicOidcIssuer':'http://127.0.0.1:4401/realms/youtube-v1','oidcInternalJwksUrl':'http://identity:8080/realms/youtube-v1/protocol/openid-connect/certs','oidcPublicClientId':'youtube-v1-web','oidcApiAudience':'youtube-v1-api','oidcCreatorRole':'creator','oidcFlow':'authorization-code + PKCE S256; no browser secret','publicS3Endpoint':'http://127.0.0.1:4402','internalS3Endpoint':'http://objects:3900','s3Region':'garage','s3Addressing':'path-style; separate internal control client and public presigning client; preserve signed host','originalsBucket':'youtube-v1-originals','transcodedBucket':'youtube-v1-transcoded','publicMediaPrefix':'/media/','garageWebsiteHost':'youtube-v1-transcoded.web.garage.localhost','broker':'one RabbitMQ node; persistent messages, publisher confirms, manual acknowledgements after side effects','topicSemantics':'fanout exchange with a durable queue per subscriber; no historical replay, ordering between subscribers, or partitioned-log semantics','applicationDatabaseIsolation':'one PostgreSQL instance; separate logical databases and users for metadata, counts and Keycloak; owner write/read-only grants','secrets':'generated/provisioned locally at setup; never part of source hashes or committed .env','hostPublishing':'loopback only; infrastructure ports internal except identity/S3 browser endpoints; optional management ports must remain loopback'},'customGapReferences':'../notes/mapping-and-gaps.md','immutableInputs':'design.json and blueprint.json are exact snapshot005 bytes; do not format/rewrite'}
write(inp/'local-bindings.json',bindings)
files={f:{'bytes':(inp/f).stat().st_size,'sha256':hash((inp/f).read_bytes())}for f in ['design.json','blueprint.json','local-bindings.json','runtime-pins.json']}
manifest={'format':'youtube-v1-input-freeze-v1','preparedOn':'2026-11-07','project':load(snap/'project.json'),'sourceSnapshot':'../diagrams/005-local-intent-aligned','sourceCanonicalSha256':capture['source']['designSha256'],'canonicalHashEncoding':capture['source']['hashEncoding'],'sourceSchemaVersion':2,'blueprintVersion':3,'diagram':{'path':'../diagrams/005-local-intent-aligned/diagram.png','sha256':capture['image']['sha256']},'rendererCommit':capture['renderer']['commit'],'generator':{'version':None,'templateVersions':None,'status':'not implemented; no generated output'},'strictReadiness':{'generationEligible':False,'templateAvailability':blueprint['templateAvailability'],'runtimeVerification':blueprint['runtimeVerification'],'note':'Preserved actual v3 report; this proposal grants no readiness/verification credit'},'files':files,'nextUnit':'FP02; implement generator only; preserve these frozen inputs; record containing FP01 commit in a later entry'}
write(inp/'manifest.json',manifest)
# Retain exact primary registry metadata losslessly without committing downloaded packages.
evidence=v/'notes/evidence';(evidence/'image-manifests').mkdir(exist_ok=True)
for r in images:
 p=pathlib.Path('/tmp/jeeves-fp01/images')/r['evidence'];(evidence/'image-manifests'/ (p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for name in ['image-availability.json','npm-availability.json','ffmpeg-package.txt','ffmpeg-debian-changelog.txt','ffmpeg.dsc','capture.mjs','approve-postgresql.mjs','create-copy.mts','local-copy.mjs','align-copy.mjs']:
 p=pathlib.Path('/tmp/jeeves-fp01')/name;(evidence/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
print(json.dumps({'inputFiles':files,'source':capture['source']['designSha256'],'image':capture['image']['sha256'],'elements':len(el),'components':len(components),'connections':len(connections),'explicitUnsupportedPaths':len(overrides)},indent=2))
